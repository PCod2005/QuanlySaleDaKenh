document.addEventListener("DOMContentLoaded", function() {
    // 1. Tự động active menu sidebar dựa trên URL hiện tại
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.sidebar-menu li a');
    
    menuItems.forEach(item => {
        if (item.getAttribute('href') && currentPath.includes(item.getAttribute('href'))) {
            item.classList.add('active');
        }
    });

    // 2. Kích hoạt Toast Notification nếu có message từ Server (JSP)
    const serverSuccessMsg = document.getElementById('server-success-msg');
    const serverErrorMsg = document.getElementById('server-error-msg');

    if (serverSuccessMsg && serverSuccessMsg.value.trim() !== "") {
        showToast('success', serverSuccessMsg.value);
    }
    
    if (serverErrorMsg && serverErrorMsg.value.trim() !== "") {
        showToast('error', serverErrorMsg.value);
    }
});

// Hàm tạo và hiển thị Toast toàn cục
function showToast(type, message) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span>${message}</span>
        <span style="cursor:pointer; color:#999; margin-left:15px;" onclick="this.parentElement.remove()">&times;</span>
    `;
    
    container.appendChild(toast);

    // Tự động xóa khỏi DOM sau 3.3s (3s hiển thị + 0.3s animation fadeOut)
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 3300);
}