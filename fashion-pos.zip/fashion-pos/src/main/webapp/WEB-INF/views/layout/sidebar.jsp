<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<div class="sidebar">
    <div class="sidebar-brand">
        FASHION POS
    </div>
    <ul class="sidebar-menu">
        <li><a href="${pageContext.request.contextPath}/dashboard">Tổng quan</a></li>
        <li><a href="${pageContext.request.contextPath}/sale">Bán hàng (POS)</a></li>
        <li><a href="${pageContext.request.contextPath}/order">Đơn hàng</a></li>
        <li><a href="${pageContext.request.contextPath}/product">Sản phẩm</a></li>
        <li><a href="${pageContext.request.contextPath}/category">Danh mục</a></li>
        <li><a href="${pageContext.request.contextPath}/inventory">Nhập kho</a></li>
        
        <!-- Chỉ ADMIN mới thấy Quản lý tài khoản -->
        <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
            <li><a href="${pageContext.request.contextPath}/account">Tài khoản</a></li>
        </c:if>
        
        <li><a href="${pageContext.request.contextPath}/report">Báo cáo</a></li>
        <li><a href="${pageContext.request.contextPath}/profile">Cá nhân</a></li>
    </ul>
</div>