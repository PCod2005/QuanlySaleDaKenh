<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<div class="topbar">
    <div class="topbar-title">
        Hệ Thống Quản Lý Bán Lẻ
    </div>
    <div class="topbar-right">
        <div class="user-info">
            Xin chào, <b>${sessionScope.currentUser.hoTen}</b> 
            (<span style="color: #4e73df;">${sessionScope.currentUser.role}</span>)
        </div>
        <a href="${pageContext.request.contextPath}/logout" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn đăng xuất?');">
            Đăng xuất
        </a>
    </div>
</div>