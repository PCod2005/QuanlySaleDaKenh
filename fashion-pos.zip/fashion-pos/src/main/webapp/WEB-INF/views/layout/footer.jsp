<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

        </div> <!-- End Content -->
    </div> <!-- End Main Wrapper -->

    <!-- Toast Notification Container -->
    <div id="toast-container"></div>

    <!-- Hidden inputs for JS to read Session Messages -->
    <c:if test="${not empty sessionScope.successMsg}">
        <input type="hidden" id="server-success-msg" value="${sessionScope.successMsg}">
        <c:remove var="successMsg" scope="session"/>
    </c:if>

    <c:if test="${not empty sessionScope.errorMsg}">
        <input type="hidden" id="server-error-msg" value="${sessionScope.errorMsg}">
        <c:remove var="errorMsg" scope="session"/>
    </c:if>

    <script src="${pageContext.request.contextPath}/assets/js/main.js"></script>
</body>
</html>