<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Tài Khoản - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .table-custom { border-collapse: separate; border-spacing: 0 10px; margin-top: 10px; width: 100%; }
        .table-custom th { background: transparent; color: var(--dark); text-transform: uppercase; font-size: 13px; border: none; padding-bottom: 5px; }
        .table-custom td { background: #fff; padding: 15px; vertical-align: middle; border-top: 1px solid #f1f3f5; border-bottom: 1px solid #f1f3f5; }
        .table-custom td:first-child { border-left: 1px solid #f1f3f5; border-radius: 8px 0 0 8px; }
        .table-custom td:last-child { border-right: 1px solid #f1f3f5; border-radius: 0 8px 8px 0; }
        .table-custom tr:hover td { box-shadow: 0 4px 15px rgba(0,0,0,0.05); transform: translateY(-1px); transition: all 0.2s; }
        
        .btn-gradient { border: none; border-radius: 6px; padding: 8px 14px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-size: 13px; transition: 0.3s; text-decoration: none;}
        .btn-gradient-primary { background: linear-gradient(45deg, #4e73df, #224abe); color: white;}
        .btn-gradient-warning { background: linear-gradient(45deg, #f6c23e, #d49a15); color: white;}
        .btn-gradient-danger { background: linear-gradient(45deg, #e74a3b, #be2617); color: white;}
        .btn-gradient-success { background: linear-gradient(45deg, #1cc88a, #13855c); color: white;}
        .btn-gradient:hover { transform: translateY(-2px); filter: brightness(1.1); }
        
        .status-pill { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; text-align: center; min-width: 80px;}
        .status-active { background-color: #e3fbed; color: #1cc88a; }
        .status-inactive { background-color: #fdeaea; color: #e74a3b; }
        
        .role-pill { padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: bold; display: inline-block; text-align: center;}
        .role-admin { background: linear-gradient(45deg, #e74a3b, #be2617); color: white;}
        .role-staff { background: linear-gradient(45deg, #36b9cc, #1e8a99); color: white;}

        .tab-btn { background: transparent; padding: 10px 20px; font-size: 15px; font-weight: bold; border-radius: 0; outline: none;}
        .tab-active { color: #4e73df; border-bottom: 3px solid #4e73df; }
        .tab-inactive { color: gray; border-bottom: 3px solid transparent; }
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; }
        .modal-content { background: #fff; border-radius: 12px; width: 500px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; }
        .modal-header { background: linear-gradient(45deg, #4e73df, #224abe); color: white; padding: 18px 25px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 24px; cursor: pointer; }
        .modal-body { padding: 25px; overflow-y: auto; }
        
        .filter-box { display: flex; gap: 10px; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 15px; align-items: center;}
        
        /* Cấu trúc ép Phân trang luôn nằm đáy */
        .card-sticky-pagination { display: flex; flex-direction: column; min-height: calc(100vh - 350px); background: transparent; border: none; box-shadow: none; padding: 0;}
        .table-wrapper { flex-grow: 1; }
        .pagination-container { display: flex; justify-content: center; gap: 8px; margin-top: auto; padding-top: 20px; padding-bottom: 10px;}
        .page-btn { padding: 8px 14px; border: 1px solid #d1d3e2; background: #fff; border-radius: 6px; cursor: pointer; font-weight: bold; color: var(--primary); transition: 0.2s;}
        .page-btn.active { background: #4e73df; color: white; border-color: #4e73df; }
        
        .log-time { font-size: 12px; color: gray; font-weight: bold;}
        .log-user { font-size: 13px; color: var(--dark); font-weight: bold;}
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        <div class="content">
            <!-- THÔNG BÁO -->
            <c:if test="${not empty sessionScope.successMsg}">
                <div style="background: #e3fbed; color: #1cc88a; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; border-left: 5px solid #1cc88a;" id="alertMsg">
                    <i class="fa-solid fa-circle-check"></i> ${sessionScope.successMsg}
                </div>
                <c:remove var="successMsg" scope="session"/>
            </c:if>
            <c:if test="${not empty sessionScope.errorMsg}">
                <div style="background: #fdeaea; color: #e74a3b; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; border-left: 5px solid #e74a3b;" id="alertMsg">
                    <i class="fa-solid fa-triangle-exclamation"></i> ${sessionScope.errorMsg}
                </div>
                <c:remove var="errorMsg" scope="session"/>
            </c:if>

            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: var(--dark); font-size: 24px; margin: 0;"><i class="fa-solid fa-users-gear" style="color: #4e73df; margin-right: 10px;"></i>Quản lý Tài Khoản</h2>
                    <hr style="height: 3px; background: linear-gradient(90deg, #4e73df, transparent); border: none; margin: 15px 0 20px 0; border-radius: 5px; width: 100px;">
                </div>
                <button class="btn-gradient btn-gradient-primary" onclick="openAddModal()">
                    <i class="fa-solid fa-user-plus"></i> + Thêm Tài Khoản
                </button>
            </div>

            <!-- TABS -->
            <div style="margin-bottom: 20px; border-bottom: 2px solid #eaecf4;">
                <button id="btnTab1" class="btn-gradient tab-btn ${activeTab == 'tai-khoan' ? 'tab-active' : 'tab-inactive'}" onclick="switchTab('tai-khoan')">Danh sách Nhân viên</button>
                <button id="btnTab2" class="btn-gradient tab-btn ${activeTab == 'lich-su-admin' ? 'tab-active' : 'tab-inactive'}" onclick="switchTab('lich-su-admin')">Lịch sử Quản trị (ADMIN)</button>
                <button id="btnTab3" class="btn-gradient tab-btn ${activeTab == 'lich-su-staff' ? 'tab-active' : 'tab-inactive'}" onclick="switchTab('lich-su-staff')">Lịch sử Bán hàng (STAFF)</button>
            </div>

            <!-- BỘ LỌC CHO 2 TAB LỊCH SỬ -->
            <div id="filterLogContainer" style="display: ${activeTab != 'tai-khoan' ? 'block' : 'none'};">
                <form class="filter-box" action="${pageContext.request.contextPath}/account" method="get">
                    <input type="hidden" id="logTabParam" name="tab" value="${activeTab}">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-weight:bold; font-size:13px; color:gray;">Từ ngày:</span>
                        <input type="date" name="fromDate" class="form-control" value="${fromDate}">
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-weight:bold; font-size:13px; color:gray;">Đến:</span>
                        <input type="date" name="toDate" class="form-control" value="${toDate}">
                    </div>
                    <input type="text" name="searchLog" class="form-control" style="flex-grow: 1;" placeholder="Tìm theo hành động, chi tiết..." value="${searchLog}">
                    <button type="submit" class="btn-gradient btn-gradient-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
                    <a href="${pageContext.request.contextPath}/account?tab=${activeTab}" class="btn-gradient" style="background:#858796;">Xóa lọc</a>
                </form>
            </div>

            <!-- TAB 1: TÀI KHOẢN -->
            <div id="tab-tai-khoan" style="display: ${activeTab == 'tai-khoan' ? 'block' : 'none'};">
                <div class="card card-sticky-pagination">
                    <div class="table-wrapper">
                        <table class="table table-custom">
                            <thead>
                                <tr>
                                    <th style="width: 80px;">Mã NV</th>
                                    <th>Tên Đăng Nhập</th>
                                    <th>Họ và Tên</th>
                                    <th>Thông tin liên hệ</th>
                                    <th style="text-align: center;">Quyền</th>
                                    <th style="text-align: center;">Trạng thái</th>
                                    <th style="text-align: center;">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="u" items="${users}">
                                    <tr class="account-row">
                                        <td><b style="color: gray;">NV${String.format("%03d", u.maNV)}</b></td>
                                        <td><b style="color: #4e73df; font-size: 15px;">${u.username}</b></td>
                                        <td style="font-weight: bold;">${u.hoTen}</td>
                                        <td style="font-size: 13px; color: #555;">
                                            <i class="fa-solid fa-phone" style="width: 15px; color:gray;"></i> ${empty u.sdt ? '-' : u.sdt}<br>
                                            <i class="fa-solid fa-envelope" style="width: 15px; color:gray;"></i> ${empty u.email ? '-' : u.email}
                                        </td>
                                        <td style="text-align: center;"><span class="role-pill ${u.role == 'ADMIN' ? 'role-admin' : 'role-staff'}">${u.role}</span></td>
                                        <td style="text-align: center;">
                                            <span class="status-pill ${u.trangThai ? 'status-active' : 'status-inactive'}">${u.trangThai ? 'Hoạt động' : 'Bị khóa'}</span>
                                        </td>
                                        <td style="text-align: center;">
                                            <button class="btn-gradient btn-gradient-warning" style="padding: 4px 10px; font-size:11px;" 
                                                    onclick="openEditModal(${u.maNV}, '${u.username}', '${u.hoTen}', '${u.sdt}', '${u.email}', '${u.role}', ${u.trangThai})">
                                                <i class="fa-solid fa-pen"></i> Sửa
                                            </button>
                                            <c:if test="${u.maNV != sessionScope.currentUser.maNV}">
                                                <form action="${pageContext.request.contextPath}/account" method="post" style="display:inline;" onsubmit="return confirm('Xác nhận đổi trạng thái tài khoản này?');">
                                                    <input type="hidden" name="action" value="toggleStatus">
                                                    <input type="hidden" name="maNV" value="${u.maNV}">
                                                    <input type="hidden" name="status" value="${u.trangThai}">
                                                    <button type="submit" class="btn-gradient ${u.trangThai ? 'btn-gradient-danger' : 'btn-gradient-success'}" style="padding: 4px 10px; font-size:11px;">
                                                        <i class="fa-solid ${u.trangThai ? 'fa-lock' : 'fa-unlock'}"></i> ${u.trangThai ? 'Khóa' : 'Mở khóa'}
                                                    </button>
                                                </form>
                                            </c:if>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                    <!-- Thanh phân trang luôn nằm đáy -->
                    <div class="pagination-container" id="pagination-account"></div>
                </div>
            </div>

            <!-- TAB 2: LỊCH SỬ ADMIN -->
            <div id="tab-lich-su-admin" style="display: ${activeTab == 'lich-su-admin' ? 'block' : 'none'};">
                <div class="card card-sticky-pagination">
                    <div class="table-wrapper">
                        <table class="table table-custom">
                            <thead>
                                <tr>
                                    <th style="width: 150px;">Thời Gian</th>
                                    <th style="width: 180px;">Tài Khoản (ADMIN)</th>
                                    <th style="width: 200px;">Hành Động</th>
                                    <th>Chi tiết / Ghi chú Log</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="log" items="${adminLogs}">
                                    <tr class="admin-log-row">
                                        <td class="log-time"><i class="fa-regular fa-clock"></i> <fmt:formatDate value="${log.thoiGian}" pattern="dd/MM/yyyy HH:mm:ss"/></td>
                                        <td>
                                            <div class="log-user" style="color: #e74a3b;">${log.hoTen}</div>
                                            <div style="font-size: 11px; color: gray;">@${log.username}</div>
                                        </td>
                                        <td>
                                            <span style="background: #f1f3f5; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight:bold; color: var(--primary);">
                                                <i class="fa-solid fa-bolt"></i> ${log.hanhDong}
                                            </span>
                                        </td>
                                        <td style="font-size: 13px; color: #555;">${log.chiTiet}</td>
                                    </tr>
                                </c:forEach>
                                <c:if test="${empty adminLogs}">
                                    <tr><td colspan="4" style="text-align: center; padding: 50px; color: gray;"><i class="fa-solid fa-ghost fa-3x" style="color: #ccc; margin-bottom: 15px;"></i><br>Không có dữ liệu.</td></tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-container" id="pagination-admin"></div>
                </div>
            </div>

            <!-- TAB 3: LỊCH SỬ STAFF -->
            <div id="tab-lich-su-staff" style="display: ${activeTab == 'lich-su-staff' ? 'block' : 'none'};">
                <div class="card card-sticky-pagination">
                    <div class="table-wrapper">
                        <table class="table table-custom">
                            <thead>
                                <tr>
                                    <th style="width: 150px;">Thời Gian</th>
                                    <th style="width: 180px;">Tài Khoản (STAFF)</th>
                                    <th style="width: 200px;">Hành Động</th>
                                    <th>Chi tiết / Ghi chú Log</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="log" items="${staffLogs}">
                                    <tr class="staff-log-row">
                                        <td class="log-time"><i class="fa-regular fa-clock"></i> <fmt:formatDate value="${log.thoiGian}" pattern="dd/MM/yyyy HH:mm:ss"/></td>
                                        <td>
                                            <div class="log-user" style="color: #36b9cc;">${log.hoTen}</div>
                                            <div style="font-size: 11px; color: gray;">@${log.username}</div>
                                        </td>
                                        <td>
                                            <span style="background: #f1f3f5; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight:bold; color: var(--primary);">
                                                <i class="fa-solid fa-bolt"></i> ${log.hanhDong}
                                            </span>
                                        </td>
                                        <td style="font-size: 13px; color: #555;">${log.chiTiet}</td>
                                    </tr>
                                </c:forEach>
                                <c:if test="${empty staffLogs}">
                                    <tr><td colspan="4" style="text-align: center; padding: 50px; color: gray;"><i class="fa-solid fa-ghost fa-3x" style="color: #ccc; margin-bottom: 15px;"></i><br>Không có dữ liệu.</td></tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-container" id="pagination-staff"></div>
                </div>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- FORM DÙNG CHUNG THÊM/SỬA TÀI KHOẢN -->
    <div id="accountModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle" style="margin:0;"></h3>
                <span class="close-btn" onclick="closeModal('accountModal')">&times;</span>
            </div>
            <div class="modal-body">
                <form action="${pageContext.request.contextPath}/account" method="post">
                    <input type="hidden" id="action" name="action" value="add">
                    <input type="hidden" id="maNV" name="maNV">
                    
                    <div style="display: flex; gap: 15px;" id="loginGroup">
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Tên Đăng Nhập <span style="color:red;">*</span></label>
                            <input type="text" id="username" name="username" class="form-control" required>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Mật khẩu khởi tạo <span style="color:red;">*</span></label>
                            <input type="password" id="password" name="password" class="form-control" required>
                            <small style="color: gray; font-size: 11px;">Mật khẩu sẽ được mã hóa an toàn</small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Họ và Tên <span style="color:red;">*</span></label>
                        <input type="text" id="hoTen" name="hoTen" class="form-control" required>
                    </div>
                    
                    <div style="display: flex; gap: 15px;">
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Số điện thoại</label>
                            <input type="text" id="sdt" name="sdt" class="form-control">
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Email</label>
                            <input type="email" id="email" name="email" class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Phân quyền Hệ Thống <span style="color:red;">*</span></label>
                        <select id="role" name="role" class="form-control" required>
                            <option value="STAFF">Nhân viên bán hàng (STAFF)</option>
                            <option value="ADMIN">Quản Trị Viên (ADMIN)</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="statusGroup" style="display: none; background: #eaecf4; padding: 12px; border-radius: 6px;">
                        <label style="display: flex; align-items: center; cursor: pointer; margin:0;">
                            <input type="checkbox" id="trangThai" name="trangThai" value="true" style="margin-right: 10px;"> 
                            <span style="font-weight: 600; color: var(--dark);">Tài khoản hoạt động</span>
                        </label>
                    </div>
                    
                    <button type="submit" class="btn-gradient btn-gradient-primary" style="width: 100%; justify-content: center; padding: 12px; margin-top: 10px; font-size: 15px;">
                        <i class="fa-solid fa-floppy-disk"></i> <span id="submitBtnText"></span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        setTimeout(() => { let alert = document.getElementById('alertMsg'); if (alert) alert.style.display = 'none'; }, 3000);

        function switchTab(tab) {
            document.getElementById('tab-tai-khoan').style.display = (tab === 'tai-khoan') ? 'block' : 'none';
            document.getElementById('tab-lich-su-admin').style.display = (tab === 'lich-su-admin') ? 'block' : 'none';
            document.getElementById('tab-lich-su-staff').style.display = (tab === 'lich-su-staff') ? 'block' : 'none';
            
            // Hiện hộp tìm kiếm cho Lịch sử
            document.getElementById('filterLogContainer').style.display = (tab === 'tai-khoan') ? 'none' : 'block';
            document.getElementById('logTabParam').value = tab;
            
            document.getElementById('btnTab1').className = 'btn-gradient tab-btn ' + ((tab === 'tai-khoan') ? 'tab-active' : 'tab-inactive');
            document.getElementById('btnTab2').className = 'btn-gradient tab-btn ' + ((tab === 'lich-su-admin') ? 'tab-active' : 'tab-inactive');
            document.getElementById('btnTab3').className = 'btn-gradient tab-btn ' + ((tab === 'lich-su-staff') ? 'tab-active' : 'tab-inactive');
            
            const url = new URL(window.location);
            url.searchParams.set('tab', tab);
            window.history.pushState({}, '', url);
        }

        // --- HÀM TẠO PHÂN TRANG DÙNG CHUNG ---
        function initPagination(rowClass, paginationId) {
            const rowsPerPage = 7; // Hiển thị 7 dòng mỗi trang
            const rows = document.querySelectorAll('.' + rowClass);
            const container = document.getElementById(paginationId);
            container.innerHTML = ''; 
            
            let totalPages = Math.ceil(rows.length / rowsPerPage);
            if (totalPages <= 1) {
                rows.forEach(r => r.style.display = '');
                return;
            }
            
            function showPage(page) {
                rows.forEach((row, index) => {
                    row.style.display = (index >= (page - 1) * rowsPerPage && index < page * rowsPerPage) ? '' : 'none';
                });
                let btns = container.querySelectorAll('.page-btn');
                btns.forEach(btn => btn.classList.remove('active'));
                let activeBtn = document.getElementById('btn_' + paginationId + '_' + page);
                if(activeBtn) activeBtn.classList.add('active');
            }

            for (let i = 1; i <= totalPages; i++) {
                const btn = document.createElement('button');
                btn.className = 'page-btn'; 
                btn.id = 'btn_' + paginationId + '_' + i; 
                btn.innerText = i;
                btn.onclick = () => showPage(i);
                container.appendChild(btn);
            }
            showPage(1);
        }

        // Khởi tạo phân trang cho cả 3 Tab
        initPagination('account-row', 'pagination-account');
        initPagination('admin-log-row', 'pagination-admin');
        initPagination('staff-log-row', 'pagination-staff');


        // --- MODAL SỰ KIỆN ---
        function openAddModal() {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-user-plus"></i> Thêm Tài Khoản Mới';
            document.getElementById('action').value = 'add';
            document.getElementById('maNV').value = '';
            
            document.getElementById('loginGroup').style.display = 'flex';
            document.getElementById('username').readOnly = false;
            document.getElementById('username').value = '';
            document.getElementById('password').required = true;
            document.getElementById('password').value = '';
            
            document.getElementById('hoTen').value = '';
            document.getElementById('sdt').value = '';
            document.getElementById('email').value = '';
            document.getElementById('role').value = 'STAFF';
            
            document.getElementById('statusGroup').style.display = 'block';
            document.getElementById('trangThai').checked = true;
            
            document.getElementById('submitBtnText').innerText = 'TẠO TÀI KHOẢN';
            document.getElementById('accountModal').style.display = 'flex';
        }

        function openEditModal(id, username, hoTen, sdt, email, role, trangThai) {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Cập Nhật Nhân Viên';
            document.getElementById('action').value = 'edit';
            document.getElementById('maNV').value = id;
            
            document.getElementById('loginGroup').style.display = 'none';
            document.getElementById('username').readOnly = true;
            document.getElementById('password').required = false;
            
            document.getElementById('hoTen').value = hoTen;
            document.getElementById('sdt').value = (sdt !== 'null' && sdt !== '-') ? sdt : '';
            document.getElementById('email').value = (email !== 'null' && email !== '-') ? email : '';
            document.getElementById('role').value = role;
            
            document.getElementById('statusGroup').style.display = 'block';
            document.getElementById('trangThai').checked = trangThai;
            
            document.getElementById('submitBtnText').innerText = 'LƯU THÔNG TIN';
            document.getElementById('accountModal').style.display = 'flex';
        }

        function closeModal(modalId) { document.getElementById(modalId).style.display = 'none'; }
    </script>
</body>
</html>