<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thông tin cá nhân - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <style>
        .profile-card { max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <div class="profile-card">
                <h2 style="margin-bottom: 20px; color: var(--dark); border-bottom: 1px solid #eee; padding-bottom: 10px;">Hồ Sơ Cá Nhân</h2>
                
                <form action="${pageContext.request.contextPath}/profile" method="post">
                    <div class="form-group">
                        <label class="form-label">Tên đăng nhập</label>
                        <input type="text" class="form-control" value="${userProfile.username}" readonly style="background: #e9ecef;">
                        <small style="color: gray;">Tên đăng nhập không thể thay đổi.</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Quyền hạn (Role)</label>
                        <input type="text" class="form-control" value="${userProfile.role}" readonly style="background: #e9ecef;">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Họ và Tên *</label>
                        <input type="text" name="hoTen" class="form-control" value="${userProfile.hoTen}" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Số điện thoại</label>
                        <input type="text" name="sdt" class="form-control" value="${userProfile.sdt}">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="${userProfile.email}">
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; margin-top: 10px;">Lưu Thay Đổi</button>
                </form>
            </div>
        </div>
        
        <jsp:include page="../layout/footer.jsp" />
    </div>
</body>
</html>