<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hóa Đơn #${order.maDH}</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #e9ecef; margin: 0; padding: 20px; color: #333; }
        
        /* Chứa các nút chức năng, sẽ bị ẩn khi in */
        .action-bar { max-width: 800px; margin: 0 auto 20px auto; display: flex; justify-content: flex-end; gap: 10px; }
        .btn { padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer; color: white; font-size: 14px; text-decoration: none; }
        .btn-primary { background-color: #4e73df; }
        .btn-success { background-color: #1cc88a; }
        .btn-secondary { background-color: #858796; }

        /* Khung hóa đơn chính */
        .invoice-box {
            max-width: 800px; margin: auto; padding: 40px; background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15); font-size: 14px; line-height: 24px;
        }

        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
        .header-left h1 { margin: 0; color: #4e73df; font-size: 28px; text-transform: uppercase; }
        .header-left p { margin: 5px 0 0 0; color: #555; }
        .header-right { text-align: right; }
        .header-right h2 { margin: 0 0 5px 0; font-size: 20px; color: #333; }

        .info-section { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .info-block { width: 48%; }
        .info-block strong { display: inline-block; width: 100px; }

        table.items { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        table.items th, table.items td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        table.items th { background: #f8f9fc; font-weight: bold; }
        table.items td.right { text-align: right; }
        table.items th.right { text-align: right; }

        .totals { width: 50%; float: right; }
        .totals table { width: 100%; border-collapse: collapse; }
        .totals td { padding: 5px 10px; }
        .totals .bold { font-weight: bold; font-size: 16px; }
        .totals .highlight { color: #e74a3b; font-size: 18px; }

        .clearfix::after { content: ""; clear: both; display: table; }
        .footer-note { margin-top: 50px; text-align: center; font-style: italic; color: #777; border-top: 1px solid #ddd; padding-top: 20px; }

        /* Tối ưu CSS khi In bằng trình duyệt (Ctrl+P) */
        @media print {
            body { background: white; padding: 0; }
            .action-bar { display: none; }
            .invoice-box { box-shadow: none; max-width: 100%; padding: 0; margin: 0; border: none; }
        }
    </style>
</head>
<body>
    <div class="action-bar">
        <a href="${pageContext.request.contextPath}/order" class="btn btn-secondary">Quay lại</a>
        <button onclick="window.print()" class="btn btn-primary">In Hóa Đơn</button>
        <button onclick="exportPDF()" class="btn btn-success">Xuất PDF</button>
    </div>

    <!-- Vùng nội dung sẽ được xuất PDF -->
    <div class="invoice-box" id="invoiceContent">
        <div class="header">
            <div class="header-left">
                <h1>CNJ11 FASHION</h1>
                <p>Địa chỉ: Trường Đại học Công nghệ Đông Á</p>
                <p>Điện thoại: 0123.456.789</p>
            </div>
            <div class="header-right">
                <h2>HÓA ĐƠN BÁN HÀNG</h2>
                <p><strong>Mã đơn:</strong> #${order.maDH}</p>
                <p><strong>Ngày lập:</strong> <fmt:formatDate value="${order.ngayLap}" pattern="dd/MM/yyyy HH:mm" /></p>
                <p><strong>Nhân viên:</strong> ${order.tenNV}</p>
            </div>
        </div>

        <div class="info-section">
            <div class="info-block">
                <h3>Thông tin khách hàng</h3>
                <div><strong>Khách hàng:</strong> ${empty order.tenKhachHang ? 'Khách lẻ' : order.tenKhachHang}</div>
                <div><strong>Điện thoại:</strong> ${empty order.soDienThoaiKhachHang ? '-' : order.soDienThoaiKhachHang}</div>
                <div><strong>Địa chỉ:</strong> ${empty order.diaChiKhachHang ? '-' : order.diaChiKhachHang}</div>
            </div>
            <div class="info-block">
                <h3>Thông tin giao dịch</h3>
                <div><strong>Kênh bán:</strong> ${order.kenhBan}</div>
                <div><strong>Hình thức TT:</strong> ${order.tenPTTT}</div>
                <div><strong>Ghi chú:</strong> ${empty order.ghiChu ? '-' : order.ghiChu}</div>
            </div>
        </div>

        <table class="items">
            <thead>
                <tr>
                    <th style="width: 5%;">STT</th>
                    <th style="width: 45%;">Tên sản phẩm</th>
                    <th class="right" style="width: 15%;">Đơn giá</th>
                    <th class="right" style="width: 10%;">SL</th>
                    <th class="right" style="width: 25%;">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="item" items="${details}" varStatus="loop">
                    <tr>
                        <td>${loop.index + 1}</td>
                        <td>${item.tenSP}</td>
                        <td class="right"><fmt:formatNumber value="${item.giaBan}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                        <td class="right">${item.soLuong}</td>
                        <td class="right bold"><fmt:formatNumber value="${item.thanhTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>

        <div class="clearfix">
            <div class="totals">
                <table>
                    <tr>
                        <td class="bold right">TỔNG CỘNG:</td>
                        <td class="right bold highlight"><fmt:formatNumber value="${order.tongTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                    </tr>
                    <c:if test="${payment != null}">
                        <tr>
                            <td class="right">Tiền khách đưa:</td>
                            <td class="right"><fmt:formatNumber value="${payment.tienKhachDua}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                        </tr>
                        <tr>
                            <td class="right">Tiền thừa:</td>
                            <td class="right"><fmt:formatNumber value="${payment.tienThua}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                        </tr>
                    </c:if>
                </table>
            </div>
        </div>

        <div class="footer-note">
            Cảm ơn quý khách đã mua sắm tại CNJ11 Fashion!<br>
            <i>(Hàng mua rồi miễn đổi trả sau 7 ngày)</i>
        </div>
    </div>

    <!-- Script xuất PDF -->
    <script>
        function exportPDF() {
            const element = document.getElementById('invoiceContent');
            const opt = {
                margin:       10,
                filename:     'Hoa_Don_${order.maDH}.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2 },
                jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            
            // html2pdf tự động chụp phần tử HTML và lưu thành file PDF
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>