<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Đơn Hàng - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <style>
        .filter-bar { background: #f8f9fc; padding: 15px; border-radius: 5px; margin-bottom: 20px; display: flex; gap: 15px; flex-wrap: wrap; border: 1px solid #e3e6f0; }
        .filter-item { display: flex; flex-direction: column; gap: 5px; }
        .filter-item label { font-size: 13px; font-weight: bold; color: var(--dark); }
        .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; color: white; }
        .bg-Mới.tạo { background: #36b9cc; }
        .bg-Đã.thanh.toán { background: #1cc88a; }
        .bg-Đang.chuẩn.bị { background: #f6c23e; color: #333; }
        .bg-Đã.gửi, .bg-Đang.giao { background: #4e73df; }
        .bg-Đã.giao { background: #17a673; }
        .bg-Đã.hủy { background: #e74a3b; }
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); align-items: center; justify-content: center; }
        .modal-content { background-color: #fff; padding: 20px; border-radius: 8px; width: 400px; box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
        .close-btn { color: #aaa; float: right; font-size: 24px; font-weight: bold; cursor: pointer; }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <h2 style="margin-bottom: 15px; color: var(--dark);">Danh sách Đơn Hàng</h2>
            
            <form class="filter-bar" action="${pageContext.request.contextPath}/order" method="get">
                <div class="filter-item">
                    <label>Tìm kiếm (Mã/Tên KH/SĐT)</label>
                    <input type="text" name="keyword" class="form-control" value="${keyword}" style="width: 220px;">
                </div>
                <div class="filter-item">
                    <label>Từ ngày</label>
                    <input type="date" name="fromDate" class="form-control" value="${fromDate}">
                </div>
                <div class="filter-item">
                    <label>Đến ngày</label>
                    <input type="date" name="toDate" class="form-control" value="${toDate}">
                </div>
                <div class="filter-item">
                    <label>Trạng thái</label>
                    <select name="status" class="form-control">
                        <option value="All">-- Tất cả --</option>
                        <c:forEach var="s" items="${statuses}">
                            <option value="${s}" ${status == s ? 'selected' : ''}>${s}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="filter-item">
                    <label>Kênh bán</label>
                    <select name="channel" class="form-control">
                        <option value="All">-- Tất cả --</option>
                        <c:forEach var="c" items="${channels}">
                            <option value="${c}" ${channel == c ? 'selected' : ''}>${c}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="filter-item" style="justify-content: flex-end;">
                    <button type="submit" class="btn btn-primary" style="height: 35px;">Lọc / Tìm kiếm</button>
                </div>
            </form>

            <c:if test="${not empty sessionScope.successMsg}">
                <div style="background: #d4edda; color: #155724; padding: 10px; margin-bottom: 15px; border-radius: 4px;">${sessionScope.successMsg}</div>
                <c:remove var="successMsg" scope="session"/>
            </c:if>
            <c:if test="${not empty sessionScope.errorMsg}">
                <div style="background: #f8d7da; color: #721c24; padding: 10px; margin-bottom: 15px; border-radius: 4px;">${sessionScope.errorMsg}</div>
                <c:remove var="errorMsg" scope="session"/>
            </c:if>

            <div class="card">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Mã ĐH</th>
                            <th>Ngày lập</th>
                            <th>Khách hàng</th>
                            <th>Kênh bán</th>
                            <th>Nhân viên</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="o" items="${orders}">
                            <tr>
                                <td><b>#${o.maDH}</b></td>
                                <td><fmt:formatDate value="${o.ngayLap}" pattern="dd/MM/yyyy HH:mm" /></td>
                                <td>
                                    <div style="font-weight: bold;">${empty o.tenKhachHang ? 'Khách lẻ' : o.tenKhachHang}</div>
                                    <div style="font-size: 12px; color: gray;">${o.soDienThoaiKhachHang}</div>
                                </td>
                                <td>${o.kenhBan}</td>
                                <td>${o.tenNV}</td>
                                <td style="color: var(--danger); font-weight: bold;">
                                    <fmt:formatNumber value="${o.tongTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                </td>
                                <td>
                                    <%-- Handle CSS class mapping without scriptlet via simple replace trick if needed, or predefined classes --%>
                                    <span class="status-badge bg-${o.trangThai.replace(' ', '.')}">${o.trangThai}</span>
                                </td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/order?action=detail&id=${o.maDH}" class="btn btn-info" style="color: white; padding: 4px 8px; font-size: 12px;">Chi tiết</a>
                                    <button class="btn btn-secondary" style="padding: 4px 8px; font-size: 12px;" onclick="openStatusModal(${o.maDH}, '${o.trangThai}')">Đổi TT</button>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty orders}">
                            <tr><td colspan="8" style="text-align: center;">Không có dữ liệu</td></tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- Modal Cập nhật Trạng thái -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <h3 style="margin-bottom: 20px;">Cập nhật Trạng Thái Đơn Hàng</h3>
            <form action="${pageContext.request.contextPath}/order" method="post">
                <input type="hidden" name="action" value="updateStatus">
                <input type="hidden" id="modal_maDH" name="maDH">
                <div class="form-group">
                    <label class="form-label">Mã đơn hàng</label>
                    <input type="text" id="display_maDH" class="form-control" readonly style="background: #e9ecef;">
                </div>
                <div class="form-group">
                    <label class="form-label">Chọn trạng thái mới</label>
                    <select id="modal_status" name="status" class="form-control">
                        <c:forEach var="s" items="${statuses}">
                            <option value="${s}">${s}</option>
                        </c:forEach>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Lưu thay đổi</button>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('statusModal');
        function openStatusModal(maDH, currentStatus) {
            document.getElementById('modal_maDH').value = maDH;
            document.getElementById('display_maDH').value = "#" + maDH;
            document.getElementById('modal_status').value = currentStatus;
            modal.style.display = 'flex';
        }
        function closeModal() { modal.style.display = 'none'; }
        window.onclick = function(e) { if(e.target == modal) closeModal(); }
    </script>
</body>
</html>