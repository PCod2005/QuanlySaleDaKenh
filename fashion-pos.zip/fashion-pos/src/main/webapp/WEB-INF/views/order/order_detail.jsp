<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chi tiết Đơn Hàng #${order.maDH} - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <style>
        .detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .info-box { background: #f8f9fc; padding: 15px; border-radius: 5px; border: 1px solid #e3e6f0; }
        .info-box h4 { margin-bottom: 15px; color: var(--primary); border-bottom: 1px solid #ddd; padding-bottom: 5px; }
        .info-row { display: flex; margin-bottom: 8px; font-size: 14px; }
        .info-label { width: 150px; font-weight: bold; color: var(--dark); }
        .info-value { flex-grow: 1; }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="color: var(--dark);">Chi tiết Đơn Hàng #${order.maDH}</h2>
                <div>
                    <a href="${pageContext.request.contextPath}/order" class="btn btn-secondary">Quay lại</a>
                    <button class="btn btn-success" onclick="window.print()">In Hóa Đơn</button>
                </div>
            </div>

            <div class="detail-grid">
                <div class="info-box">
                    <h4>Thông tin khách hàng & Giao hàng</h4>
                    <div class="info-row"><div class="info-label">Khách hàng:</div><div class="info-value">${empty order.tenKhachHang ? 'Khách lẻ' : order.tenKhachHang}</div></div>
                    <div class="info-row"><div class="info-label">Số điện thoại:</div><div class="info-value">${empty order.soDienThoaiKhachHang ? '-' : order.soDienThoaiKhachHang}</div></div>
                    <div class="info-row"><div class="info-label">Địa chỉ:</div><div class="info-value">${empty order.diaChiKhachHang ? '-' : order.diaChiKhachHang}</div></div>
                    <div class="info-row"><div class="info-label">Kênh bán:</div><div class="info-value">${order.kenhBan}</div></div>
                    <div class="info-row"><div class="info-label">Ghi chú:</div><div class="info-value">${empty order.ghiChu ? '-' : order.ghiChu}</div></div>
                </div>

                <div class="info-box">
                    <h4>Thông tin thanh toán</h4>
                    <div class="info-row"><div class="info-label">Ngày lập:</div><div class="info-value"><fmt:formatDate value="${order.ngayLap}" pattern="dd/MM/yyyy HH:mm:ss" /></div></div>
                    <div class="info-row"><div class="info-label">Nhân viên tạo:</div><div class="info-value">${order.tenNV}</div></div>
                    <div class="info-row"><div class="info-label">Hình thức TT:</div><div class="info-value">${order.tenPTTT}</div></div>
                    <div class="info-row"><div class="info-label">Trạng thái:</div><div class="info-value"><b style="color: var(--primary);">${order.trangThai}</b></div></div>
                    <c:if test="${payment != null}">
                        <div class="info-row"><div class="info-label">Tiền khách đưa:</div><div class="info-value"><fmt:formatNumber value="${payment.tienKhachDua}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></div></div>
                        <div class="info-row"><div class="info-label">Tiền thừa:</div><div class="info-value"><fmt:formatNumber value="${payment.tienThua}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></div></div>
                    </c:if>
                </div>
            </div>

            <div class="card">
                <div class="card-header">Danh sách Sản phẩm</div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Mã SP</th>
                            <th>Tên Sản Phẩm</th>
                            <th>Đơn Giá</th>
                            <th>Số Lượng</th>
                            <th style="text-align: right;">Thành Tiền</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="item" items="${details}" varStatus="loop">
                            <tr>
                                <td>${loop.index + 1}</td>
                                <td>${item.maSP}</td>
                                <td>${item.tenSP}</td>
                                <td><fmt:formatNumber value="${item.giaBan}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                                <td>${item.soLuong}</td>
                                <td style="text-align: right; font-weight: bold;"><fmt:formatNumber value="${item.thanhTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                            </tr>
                        </c:forEach>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" style="text-align: right; font-size: 18px; font-weight: bold;">TỔNG CỘNG:</td>
                            <td style="text-align: right; font-size: 18px; font-weight: bold; color: var(--danger);">
                                <fmt:formatNumber value="${order.tongTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        
        <jsp:include page="../layout/footer.jsp" />
    </div>
</body>
</html>