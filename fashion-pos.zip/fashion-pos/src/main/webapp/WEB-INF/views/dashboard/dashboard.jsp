<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dash-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 20px; }
        .dash-card { background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 5px solid var(--primary); }
        .dash-card.success { border-left-color: var(--success); }
        .dash-card.info { border-left-color: var(--info); }
        .dash-card.warning { border-left-color: var(--warning); }
        .dash-title { font-size: 13px; font-weight: bold; color: var(--dark); text-transform: uppercase; margin-bottom: 10px; }
        .dash-value { font-size: 24px; font-weight: bold; color: #333; }
        .charts-row { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; }
        .chart-container { position: relative; height: 300px; width: 100%; }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <h2 style="margin-bottom: 20px; color: var(--dark);">Tổng quan kinh doanh</h2>
            
            <!-- Thống kê tổng quát -->
            <div class="dash-grid">
                <div class="dash-card">
                    <div class="dash-title">Tổng doanh thu</div>
                    <div class="dash-value"><fmt:formatNumber value="${stats.totalRevenue}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></div>
                </div>
                <div class="dash-card success">
                    <div class="dash-title">Đơn hàng hôm nay</div>
                    <div class="dash-value">${stats.todayOrders}</div>
                </div>
                <div class="dash-card info">
                    <div class="dash-title">Tổng sản phẩm đã bán</div>
                    <div class="dash-value">${stats.productsSold}</div>
                </div>
                <div class="dash-card warning">
                    <div class="dash-title">Sắp hết hàng</div>
                    <div class="dash-value">${stats.lowStockCount} <span style="font-size:14px; font-weight:normal;">sản phẩm</span></div>
                </div>
            </div>

            <!-- Biểu đồ & Bảng -->
            <div class="charts-row">
                <div class="card">
                    <div class="card-header">Doanh thu theo Kênh Bán</div>
                    <div class="chart-container">
                        <canvas id="channelChart"></canvas>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">Top 5 Bán chạy nhất</div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sản phẩm</th>
                                <th>Đã bán</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="item" items="${stats.bestSellingProducts}">
                                <tr>
                                    <td>${item.key}</td>
                                    <td>${item.value}</td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty stats.bestSellingProducts}">
                                <tr><td colspan="2" style="text-align: center;">Chưa có dữ liệu</td></tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <jsp:include page="../layout/footer.jsp" />
        
        <!-- Script cấu hình Chart.js lấy dữ liệu từ Backend thông qua EL -->
        <script>
            // Chuẩn bị mảng Data từ JSTL Map
            let channelLabels = [];
            let channelData = [];
            
            <c:forEach var="channel" items="${stats.revenueByChannel}">
                channelLabels.push("${channel.key}");
                channelData.push(${channel.value});
            </c:forEach>

            // Vẽ biểu đồ Doughnut
            if(channelLabels.length > 0) {
                const ctx = document.getElementById('channelChart').getContext('2d');
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: channelLabels,
                        datasets: [{
                            data: channelData,
                            backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796', '#5a5c69'],
                            hoverOffset: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'right' }
                        }
                    }
                });
            } else {
                document.getElementById('channelChart').outerHTML = "<p style='text-align:center; margin-top:100px; color:#888;'>Chưa có dữ liệu doanh thu</p>";
            }
        </script>
    </div>
</body>
</html>