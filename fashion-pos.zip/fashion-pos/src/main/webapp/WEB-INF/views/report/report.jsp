<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Báo Cáo Thống Kê - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .chart-container { position: relative; height: 320px; width: 100%; padding: 15px; background: #fff; border-radius: 5px; border: 1px solid #e3e6f0; }
        .chart-title { font-weight: bold; color: var(--primary); margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .full-width { grid-column: 1 / -1; }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <h2 style="margin-bottom: 20px; color: var(--dark);">Báo Cáo Giao Dịch & Doanh Thu</h2>

            <div class="report-grid">
                <!-- Biểu đồ Doanh thu 7 ngày qua -->
                <div class="chart-container full-width">
                    <div class="chart-title">Doanh thu 7 ngày gần nhất</div>
                    <div style="height: 250px;"><canvas id="dailyChart"></canvas></div>
                </div>

                <!-- Biểu đồ Doanh thu theo tháng -->
                <div class="chart-container">
                    <div class="chart-title">Doanh thu 6 tháng gần nhất</div>
                    <div style="height: 250px;"><canvas id="monthlyChart"></canvas></div>
                </div>

                <!-- Biểu đồ Tỷ trọng kênh bán -->
                <div class="chart-container">
                    <div class="chart-title">Cơ cấu Doanh thu theo Kênh bán</div>
                    <div style="height: 250px;"><canvas id="channelChart"></canvas></div>
                </div>
            </div>

            <!-- Bảng chi tiết Doanh thu Kênh Bán -->
            <div class="card">
                <div class="card-header">Bảng Số Liệu Kênh Bán</div>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kênh Bán</th>
                            <th style="text-align: right;">Tổng Doanh Thu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:set var="totalAll" value="0"/>
                        <c:forEach var="item" items="${channelRevenue}">
                            <c:set var="totalAll" value="${totalAll + item.value}"/>
                            <tr>
                                <td><b>${item.label}</b></td>
                                <td style="text-align: right; color: var(--danger); font-weight: bold;">
                                    <fmt:formatNumber value="${item.value}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty channelRevenue}">
                            <tr><td colspan="2" style="text-align: center;">Chưa có dữ liệu</td></tr>
                        </c:if>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td style="font-weight: bold; font-size: 16px;">TỔNG CỘNG</td>
                            <td style="text-align: right; font-weight: bold; font-size: 16px; color: var(--primary);">
                                <fmt:formatNumber value="${totalAll}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- Inject Dữ liệu vào JS -->
    <script>
        // 1. Data cho Biểu đồ Ngày (Line Chart)
        const dailyLabels = [];
        const dailyData = [];
        <c:forEach var="item" items="${dailyRevenue}">
            dailyLabels.push("${item.label}");
            dailyData.push(${item.value});
        </c:forEach>

        if(dailyLabels.length > 0) {
            new Chart(document.getElementById('dailyChart'), {
                type: 'line',
                data: {
                    labels: dailyLabels,
                    datasets: [{
                        label: 'Doanh thu (₫)',
                        data: dailyData,
                        borderColor: '#4e73df',
                        backgroundColor: 'rgba(78, 115, 223, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

        // 2. Data cho Biểu đồ Tháng (Bar Chart)
        const monthlyLabels = [];
        const monthlyData = [];
        <c:forEach var="item" items="${monthlyRevenue}">
            monthlyLabels.push("${item.label}");
            monthlyData.push(${item.value});
        </c:forEach>

        if(monthlyLabels.length > 0) {
            new Chart(document.getElementById('monthlyChart'), {
                type: 'bar',
                data: {
                    labels: monthlyLabels,
                    datasets: [{
                        label: 'Doanh thu (₫)',
                        data: monthlyData,
                        backgroundColor: '#1cc88a'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false }
            });
        }

        // 3. Data cho Biểu đồ Kênh Bán (Pie/Doughnut Chart)
        const channelLabels = [];
        const channelData = [];
        <c:forEach var="item" items="${channelRevenue}">
            channelLabels.push("${item.label}");
            channelData.push(${item.value});
        </c:forEach>

        if(channelLabels.length > 0) {
            new Chart(document.getElementById('channelChart'), {
                type: 'pie',
                data: {
                    labels: channelLabels,
                    datasets: [{
                        data: channelData,
                        backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796', '#5a5c69']
                    }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
            });
        }
    </script>
</body>
</html>