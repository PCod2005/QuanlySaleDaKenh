<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Tồn Kho - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .table-custom { border-collapse: separate; border-spacing: 0 10px; margin-top: 10px; width: 100%; }
        .table-custom th { background: transparent; color: var(--dark); text-transform: uppercase; font-size: 13px; border: none; padding-bottom: 5px; }
        .table-custom td { background: #fff; padding: 15px; vertical-align: middle; border-top: 1px solid #f1f3f5; border-bottom: 1px solid #f1f3f5; }
        .table-custom td:first-child { border-left: 1px solid #f1f3f5; border-radius: 8px 0 0 8px; }
        .table-custom td:last-child { border-right: 1px solid #f1f3f5; border-radius: 0 8px 8px 0; }
        .table-custom tr:hover td { box-shadow: 0 4px 15px rgba(0,0,0,0.05); transform: translateY(-1px); transition: all 0.2s; }
        .btn-gradient { border: none; border-radius: 6px; padding: 8px 14px; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-size: 13px; transition: 0.3s; text-decoration: none;}
        .btn-gradient-success { background: linear-gradient(45deg, #1cc88a, #13855c); color: white;}
        .btn-gradient-warning { background: linear-gradient(45deg, #f6c23e, #d49a15); color: white;}
        .btn-gradient-primary { background: linear-gradient(45deg, #4e73df, #224abe); color: white;}
        .btn-gradient:hover { transform: translateY(-2px); filter: brightness(1.1); }
        .pagination-container { display: flex; justify-content: center; gap: 8px; margin-top: 20px; margin-bottom: 15px;}
        .page-btn { padding: 8px 14px; border: 1px solid #d1d3e2; background: #fff; border-radius: 6px; cursor: pointer; font-weight: bold; color: var(--primary); transition: 0.2s;}
        .page-btn.active { background: #4e73df; color: white; border-color: #4e73df; }
        .tab-btn { background: transparent; padding: 10px 20px; font-size: 15px; font-weight: bold; border-radius: 0; outline: none;}
        .tab-active { color: #1cc88a; border-bottom: 3px solid #1cc88a; }
        .tab-inactive { color: gray; border-bottom: 3px solid transparent; }
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; overflow-y: auto;}
        .modal-content { background: #fff; border-radius: 12px; width: 650px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; margin: auto;}
        .modal-header { background: linear-gradient(45deg, #4e73df, #36b9cc); color: white; padding: 18px 25px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 24px; cursor: pointer; }
        .modal-body { padding: 25px; overflow-y: auto; }
        
        .filter-box { display: flex; gap: 10px; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 15px; align-items: center;}
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        <div class="content">
            <c:if test="${not empty sessionScope.successMsg}">
                <div style="background: #e3fbed; color: #1cc88a; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; border-left: 5px solid #1cc88a; display: flex; justify-content: space-between; align-items: center;" id="alertMsg">
                    <span><i class="fa-solid fa-circle-check"></i> ${sessionScope.successMsg}</span>
                    <i class="fa-solid fa-xmark" style="cursor:pointer; font-size: 18px;" onclick="document.getElementById('alertMsg').style.display='none'"></i>
                </div>
                <c:remove var="successMsg" scope="session"/>
            </c:if>
            <c:if test="${not empty sessionScope.errorMsg}">
                <div style="background: #fdeaea; color: #e74a3b; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; border-left: 5px solid #e74a3b; display: flex; justify-content: space-between; align-items: center;" id="alertMsg">
                    <span><i class="fa-solid fa-triangle-exclamation"></i> ${sessionScope.errorMsg}</span>
                    <i class="fa-solid fa-xmark" style="cursor:pointer; font-size: 18px;" onclick="document.getElementById('alertMsg').style.display='none'"></i>
                </div>
                <c:remove var="errorMsg" scope="session"/>
            </c:if>

            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: var(--dark); font-size: 24px; margin: 0;"><i class="fa-solid fa-boxes-stacked" style="color: #1cc88a; margin-right: 10px;"></i>Quản lý Tồn Kho</h2>
                    <hr style="height: 3px; background: linear-gradient(90deg, #1cc88a, #36b9cc, transparent); border: none; margin: 15px 0 20px 0; border-radius: 5px; width: 150px;">
                </div>
                <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                    <div style="display: flex; gap: 10px;">
                        <a href="${pageContext.request.contextPath}/inventory?action=audit" class="btn-gradient btn-gradient-warning" style="font-size: 13px; padding: 10px 15px;">
                            <i class="fa-solid fa-scale-balanced"></i> Cân bằng / Kiểm kê
                        </a>
                        <a href="${pageContext.request.contextPath}/inventory?action=create" class="btn-gradient btn-gradient-success" style="font-size: 13px; padding: 10px 15px;">
                            <i class="fa-solid fa-truck-ramp-box"></i> + Lập Phiếu Nhập
                        </a>
                    </div>
                </c:if>
            </div>

            <!-- TABS -->
            <div style="margin-bottom: 20px; border-bottom: 2px solid #eaecf4;">
                <button id="btnTab1" class="btn-gradient tab-btn ${activeTab == 'ton-kho' ? 'tab-active' : 'tab-inactive'}" onclick="switchTab('ton-kho')">Tồn kho hiện tại</button>
                <button id="btnTab2" class="btn-gradient tab-btn ${activeTab == 'lich-su-nhap' ? 'tab-active' : 'tab-inactive'}" onclick="switchTab('lich-su-nhap')">Lịch sử nhập kho</button>
                <button id="btnTab3" class="btn-gradient tab-btn ${activeTab == 'lich-su-kiem-ke' ? 'tab-active' : 'tab-inactive'}" onclick="switchTab('lich-su-kiem-ke')">Lịch sử kiểm kê</button>
            </div>

            <!-- TAB 1: TỒN KHO -->
            <div id="tab-ton-kho" style="display: ${activeTab == 'ton-kho' ? 'block' : 'none'};">
                <div class="card" style="border: none; box-shadow: none; background: transparent; padding: 0;">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th>Mẫu Sản Phẩm</th>
                                <th>Danh mục</th>
                                <th style="text-align: center;">Tổng Biến Thể</th>
                                <th style="text-align: center;">Tổng Tồn Kho</th>
                                <th style="text-align: center;">Trạng thái</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="entry" items="${groupedProducts}">
                                <c:set var="baseName" value="${entry.key}" />
                                <c:set var="variants" value="${entry.value}" />
                                <c:set var="firstVariant" value="${variants[0]}" />
                                <c:set var="totalStock" value="0" />
                                <c:forEach var="v" items="${variants}"><c:set var="totalStock" value="${totalStock + v.soLuongTon}" /></c:forEach>

                                <tr class="product-row">
                                    <td style="font-weight: bold; font-size: 15px; color: #4e73df;">
                                        <div style="display:flex; align-items:center; gap: 15px;">
                                            <img src="${firstVariant.anh != null ? firstVariant.anh : 'https://via.placeholder.com/50'}" style="width:40px; height:40px; border-radius:5px; object-fit:cover;">
                                            ${baseName}
                                        </div>
                                    </td>
                                    <td><span style="background: #f1f3f5; padding: 4px 8px; border-radius: 4px; font-size: 12px; color:var(--dark);">${firstVariant.tenDM}</span></td>
                                    <td style="text-align: center;"><span style="background: #e3fbed; color: #1cc88a; padding: 3px 10px; border-radius: 12px; font-weight: bold;">${fn:length(variants)} SKU</span></td>
                                    <td style="text-align: center;">
                                        <span style="font-weight: 900; font-size: 16px; color: ${totalStock <= 0 ? '#e74a3b' : (totalStock <= 10 ? '#f6c23e' : '#1cc88a')};">
                                            ${totalStock}
                                        </span>
                                    </td>
                                    <td style="text-align: center;"><span style="color: #1cc88a; font-weight: bold;"><i class="fa-solid fa-circle-check"></i> Đang kinh doanh</span></td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                    <div class="pagination-container" id="pagination"></div>
                </div>
            </div>

            <!-- BỘ LỌC LỊCH SỬ CHUNG CHO CẢ 2 TAB LỊCH SỬ -->
            <div id="filterHistoryContainer" style="display: ${activeTab != 'ton-kho' ? 'block' : 'none'};">
                <form class="filter-box" action="${pageContext.request.contextPath}/inventory" method="get">
                    <input type="hidden" name="action" value="list">
                    <input type="hidden" id="tabParam" name="tab" value="${activeTab}">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-weight:bold; font-size:13px; color:gray;">Từ ngày:</span>
                        <input type="date" name="fromDate" class="form-control" value="${fromDate}">
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-weight:bold; font-size:13px; color:gray;">Đến:</span>
                        <input type="date" name="toDate" class="form-control" value="${toDate}">
                    </div>
                    <input type="text" name="searchHistory" class="form-control" style="flex-grow: 1;" placeholder="Tìm theo ghi chú, mã phiếu..." value="${searchHistory}">
                    <button type="submit" class="btn-gradient btn-gradient-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
                    <a href="${pageContext.request.contextPath}/inventory?tab=${activeTab}" class="btn-gradient" style="background:#858796;">Xóa lọc</a>
                </form>
            </div>

            <!-- TAB 2: LỊCH SỬ NHẬP KHO -->
            <div id="tab-lich-su-nhap" style="display: ${activeTab == 'lich-su-nhap' ? 'block' : 'none'};">
                <div class="card" style="border: none; box-shadow: none; background: transparent; padding: 0;">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th style="width: 100px;">Mã Phiếu</th>
                                <th style="width: 180px;">Thời gian tạo</th>
                                <th>Nhà cung cấp / Ghi chú</th>
                                <th style="text-align: right; width: 150px;">Tổng tiền nhập</th>
                                <th style="text-align: center; width: 180px;">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="pn" items="${importHistory}">
                                <tr class="history-row">
                                    <td><b style="color: #4e73df; font-size: 15px;">#PN${String.format("%04d", pn.maPN)}</b></td>
                                    <td><fmt:formatDate value="${pn.ngayNhap}" pattern="dd/MM/yyyy - HH:mm"/></td>
                                    <td><span style="color: var(--dark); font-size: 13px;">${pn.ghiChu}</span></td>
                                    <td style="text-align: right; font-weight: bold; color: var(--danger); font-size: 16px;">
                                        <fmt:formatNumber value="${pn.tongTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                    </td>
                                    <td style="text-align: center;">
                                        <button class="btn-gradient btn-gradient-info" style="padding: 6px 10px; font-size:11px;" onclick="openDetailModal('detailModal_${pn.maPN}')"><i class="fa-solid fa-eye"></i> Xem</button>
                                        <button class="btn-gradient btn-gradient-primary" style="padding: 6px 10px; font-size:11px;" onclick="printReceipt('printArea_${pn.maPN}')"><i class="fa-solid fa-print"></i> In / Xuất PDF</button>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty importHistory}">
                                <tr>
                                    <td colspan="5" style="text-align: center; padding: 50px; color: gray;">
                                        <i class="fa-solid fa-magnifying-glass fa-3x" style="color: #ccc; margin-bottom: 15px;"></i><br>
                                        Không tìm thấy lịch sử nhập kho phù hợp.
                                    </td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 3: LỊCH SỬ KIỂM KÊ -->
            <div id="tab-lich-su-kiem-ke" style="display: ${activeTab == 'lich-su-kiem-ke' ? 'block' : 'none'};">
                <div class="card" style="border: none; box-shadow: none; background: transparent; padding: 0;">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th style="width: 100px;">Mã Phiếu</th>
                                <th style="width: 180px;">Thời gian tạo</th>
                                <th>Lý do kiểm kê</th>
                                <th style="text-align: center; width: 180px;">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="pn" items="${auditHistory}">
                                <tr class="history-row">
                                    <td><b style="color: #f6c23e; font-size: 15px;">#PN${String.format("%04d", pn.maPN)}</b></td>
                                    <td><fmt:formatDate value="${pn.ngayNhap}" pattern="dd/MM/yyyy - HH:mm"/></td>
                                    <td><span style="color: var(--dark); font-size: 13px;">${fn:replace(pn.ghiChu, '[KIỂM KÊ KHO] ', '')}</span></td>
                                    <td style="text-align: center;">
                                        <button class="btn-gradient btn-gradient-warning" style="padding: 6px 10px; font-size:11px;" onclick="openDetailModal('detailModal_${pn.maPN}')"><i class="fa-solid fa-eye"></i> Xem chi tiết</button>
                                        <button class="btn-gradient btn-gradient-primary" style="padding: 6px 10px; font-size:11px;" onclick="printReceipt('printArea_${pn.maPN}')"><i class="fa-solid fa-print"></i> In / Xuất PDF</button>
                                    </td>
                                </tr>
                            </c:forEach>
                            <c:if test="${empty auditHistory}">
                                <tr>
                                    <td colspan="4" style="text-align: center; padding: 50px; color: gray;">
                                        <i class="fa-solid fa-scale-balanced fa-3x" style="color: #ccc; margin-bottom: 15px;"></i><br>
                                        Chưa có phiếu kiểm kê nào được ghi nhận.
                                    </td>
                                </tr>
                            </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- TOÀN BỘ MODAL CHI TIẾT ĐÃ ĐƯỢC CHUẨN HÓA GIAO DIỆN IN -->

    <!-- Render Modal cho Nhập Kho -->
    <c:forEach var="pn" items="${importHistory}">
        <div id="detailModal_${pn.maPN}" class="modal">
            <div class="modal-content" style="width: 750px;">
                <div class="modal-header" style="background: linear-gradient(45deg, #4e73df, #36b9cc);">
                    <h3 style="margin:0;"><i class="fa-solid fa-file-invoice"></i> Chi Tiết Phiếu Nhập #PN${String.format("%04d", pn.maPN)}</h3>
                    <span class="close-btn" onclick="closeSpecificModal('detailModal_${pn.maPN}')">&times;</span>
                </div>
                
                <div class="modal-body" id="printArea_${pn.maPN}" style="padding: 40px;">
                    <!-- Header Hóa Đơn -->
                    <div style="display: flex; justify-content: space-between; border-bottom: 2px solid #333; padding-bottom: 15px; margin-bottom: 20px;">
                        <div>
                            <h2 style="margin:0; color: #4e73df; font-size: 26px; text-transform: uppercase; font-weight: 900;">FASHION POS</h2>
                            <p style="margin: 5px 0 0 0; font-size: 13px; color: #555;">Địa chỉ: 123 Đường ABC, Quận XYZ, Hà Nội</p>
                            <p style="margin: 2px 0 0 0; font-size: 13px; color: #555;">Hotline: 0123.456.789</p>
                        </div>
                        <div style="text-align: right;">
                            <h2 style="margin:0; color: #333; font-size: 22px;">PHIẾU NHẬP KHO</h2>
                            <p style="margin: 5px 0 0 0; font-size: 14px;">Mã phiếu: <b>#PN${String.format("%04d", pn.maPN)}</b></p>
                            <p style="margin: 2px 0 0 0; font-size: 14px;">Ngày lập: <fmt:formatDate value="${pn.ngayNhap}" pattern="dd/MM/yyyy HH:mm"/></p>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 25px; font-size: 14px;">
                        <p style="margin: 5px 0;"><b>Nhà cung cấp / Ghi chú:</b> ${pn.ghiChu}</p>
                        <p style="margin: 5px 0;"><b>Người lập phiếu:</b> Quản Trị Viên (ADMIN)</p>
                    </div>

                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px; border: 1px solid #ddd;">
                        <thead>
                            <tr style="background-color: #f8f9fc;">
                                <th style="text-align:center; padding: 12px; border: 1px solid #ddd; width: 50px;">STT</th>
                                <th style="text-align:left; padding: 12px; border: 1px solid #ddd;">Sản Phẩm (Phân loại)</th>
                                <th style="text-align:center; padding: 12px; border: 1px solid #ddd; width: 80px;">SL</th>
                                <th style="text-align:right; padding: 12px; border: 1px solid #ddd; width: 120px;">Đơn giá</th>
                                <th style="text-align:right; padding: 12px; border: 1px solid #ddd; width: 140px;">Thành tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="item" items="${importDetails[pn.maPN]}" varStatus="stt">
                                <tr>
                                    <td style="text-align:center; padding: 10px; border: 1px solid #ddd;">${stt.index + 1}</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold; color: #333;">${item.tenSP}</td>
                                    <td style="text-align:center; padding: 10px; border: 1px solid #ddd; font-weight: bold;">${item.soLuong}</td>
                                    <td style="text-align:right; padding: 10px; border: 1px solid #ddd;"><fmt:formatNumber value="${item.giaNhap}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                                    <td style="text-align:right; padding: 10px; border: 1px solid #ddd; font-weight: bold; color: var(--danger);"><fmt:formatNumber value="${item.thanhTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                                </tr>
                            </c:forEach>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" style="text-align: right; padding: 15px; border: 1px solid #ddd; font-size: 16px; font-weight: bold;">TỔNG TIỀN THANH TOÁN:</td>
                                <td style="text-align: right; padding: 15px; border: 1px solid #ddd; font-size: 18px; font-weight: 900; color: #e74a3b;"><fmt:formatNumber value="${pn.tongTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <div style="display: flex; justify-content: space-between; margin-top: 40px; padding: 0 40px;">
                        <div style="text-align: center;">
                            <p style="margin:0; font-weight: bold; font-size: 14px;">Người Giao Hàng</p>
                            <p style="margin:0; font-size: 12px; color: gray;">(Ký, ghi rõ họ tên)</p>
                        </div>
                        <div style="text-align: center;">
                            <p style="margin:0; font-weight: bold; font-size: 14px;">Người Lập Phiếu</p>
                            <p style="margin:0; font-size: 12px; color: gray;">(Ký, ghi rõ họ tên)</p>
                        </div>
                    </div>
                </div>
                
                <div style="padding: 15px 25px; text-align: right; background: #f8f9fc; border-top: 1px solid #eee; display: flex; justify-content: flex-end; gap: 10px;">
                    <button class="btn-gradient" style="background: #858796;" onclick="closeSpecificModal('detailModal_${pn.maPN}')">Đóng</button>
                    <button class="btn-gradient btn-gradient-primary" style="padding: 10px 20px;" onclick="printReceipt('printArea_${pn.maPN}')"><i class="fa-solid fa-print"></i> In Phiếu / Xuất PDF</button>
                </div>
            </div>
        </div>
    </c:forEach>

    <!-- Render Modal cho Kiểm Kê -->
    <c:forEach var="pn" items="${auditHistory}">
        <div id="detailModal_${pn.maPN}" class="modal">
            <div class="modal-content" style="width: 750px;">
                <div class="modal-header" style="background: linear-gradient(45deg, #f6c23e, #d49a15);">
                    <h3 style="margin:0;"><i class="fa-solid fa-file-invoice"></i> Chi Tiết Phiếu Kiểm Kê #PN${String.format("%04d", pn.maPN)}</h3>
                    <span class="close-btn" onclick="closeSpecificModal('detailModal_${pn.maPN}')">&times;</span>
                </div>
                <div class="modal-body" id="printArea_${pn.maPN}" style="padding: 40px;">
                    <div style="display: flex; justify-content: space-between; border-bottom: 2px solid #333; padding-bottom: 15px; margin-bottom: 20px;">
                        <div>
                            <h2 style="margin:0; color: #f6c23e; font-size: 26px; text-transform: uppercase; font-weight: 900;">FASHION POS</h2>
                            <p style="margin: 5px 0 0 0; font-size: 13px; color: #555;">Địa chỉ: 123 Đường ABC, Quận XYZ, Hà Nội</p>
                        </div>
                        <div style="text-align: right;">
                            <h2 style="margin:0; color: #333; font-size: 22px;">PHIẾU KIỂM KÊ KHO</h2>
                            <p style="margin: 5px 0 0 0; font-size: 14px;">Mã phiếu: <b>#PN${String.format("%04d", pn.maPN)}</b></p>
                            <p style="margin: 2px 0 0 0; font-size: 14px;">Ngày lập: <fmt:formatDate value="${pn.ngayNhap}" pattern="dd/MM/yyyy HH:mm"/></p>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 25px; font-size: 14px;">
                        <p style="margin: 5px 0;"><b>Lý do chênh lệch:</b> ${fn:replace(pn.ghiChu, '[KIỂM KÊ KHO] ', '')}</p>
                        <p style="margin: 5px 0;"><b>Người kiểm kê:</b> Quản Trị Viên (ADMIN)</p>
                    </div>

                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px; border: 1px solid #ddd;">
                        <thead>
                            <tr style="background-color: #f8f9fc;">
                                <th style="text-align:center; padding: 12px; border: 1px solid #ddd; width: 60px;">STT</th>
                                <th style="text-align:left; padding: 12px; border: 1px solid #ddd;">Sản Phẩm (Phân loại)</th>
                                <th style="text-align:center; padding: 12px; border: 1px solid #ddd;">Chênh Lệch (+/-)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="item" items="${importDetails[pn.maPN]}" varStatus="stt">
                                <tr>
                                    <td style="text-align:center; padding: 10px; border: 1px solid #ddd;">${stt.index + 1}</td>
                                    <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold; color: #333;">${item.tenSP}</td>
                                    <td style="text-align:center; padding: 10px; border: 1px solid #ddd; font-weight: bold; font-size: 16px; color:${item.soLuong < 0 ? 'red' : '#1cc88a'};">
                                        ${item.soLuong > 0 ? '+' : ''}${item.soLuong}
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                    
                    <div style="display: flex; justify-content: flex-end; margin-top: 40px; padding: 0 40px;">
                        <div style="text-align: center;">
                            <p style="margin:0; font-weight: bold; font-size: 14px;">Người Lập Phiếu Kiểm Kê</p>
                            <p style="margin:0; font-size: 12px; color: gray;">(Ký, ghi rõ họ tên)</p>
                        </div>
                    </div>
                </div>
                <div style="padding: 15px 25px; text-align: right; background: #f8f9fc; border-top: 1px solid #eee; display: flex; justify-content: flex-end; gap: 10px;">
                    <button class="btn-gradient" style="background: #858796;" onclick="closeSpecificModal('detailModal_${pn.maPN}')">Đóng</button>
                    <button class="btn-gradient btn-gradient-primary" style="padding: 10px 20px;" onclick="printReceipt('printArea_${pn.maPN}')"><i class="fa-solid fa-print"></i> In Phiếu / Xuất PDF</button>
                </div>
            </div>
        </div>
    </c:forEach>

    <script>
        function switchTab(tab) {
            document.getElementById('tab-ton-kho').style.display = (tab === 'ton-kho') ? 'block' : 'none';
            document.getElementById('tab-lich-su-nhap').style.display = (tab === 'lich-su-nhap') ? 'block' : 'none';
            document.getElementById('tab-lich-su-kiem-ke').style.display = (tab === 'lich-su-kiem-ke') ? 'block' : 'none';
            
            // Ẩn/Hiện bộ lọc lịch sử
            document.getElementById('filterHistoryContainer').style.display = (tab === 'ton-kho') ? 'none' : 'block';
            document.getElementById('tabParam').value = tab;

            document.getElementById('btnTab1').className = 'btn-gradient tab-btn ' + ((tab === 'ton-kho') ? 'tab-active' : 'tab-inactive');
            document.getElementById('btnTab2').className = 'btn-gradient tab-btn ' + ((tab === 'lich-su-nhap') ? 'tab-active' : 'tab-inactive');
            document.getElementById('btnTab3').className = 'btn-gradient tab-btn ' + ((tab === 'lich-su-kiem-ke') ? 'tab-active' : 'tab-inactive');
        }

        const rowsPerPage = 7; 
        const tableRows = document.querySelectorAll('.product-row');
        const paginationContainer = document.getElementById('pagination');
        let totalPages = Math.ceil(tableRows.length / rowsPerPage);

        function showPage(page) {
            tableRows.forEach((row, index) => {
                row.style.display = (index >= (page - 1) * rowsPerPage && index < page * rowsPerPage) ? '' : 'none';
            });
            document.querySelectorAll('.page-btn').forEach(btn => btn.classList.remove('active'));
            let activeBtn = document.getElementById('btnPage_' + page);
            if(activeBtn) activeBtn.classList.add('active');
        }

        if (totalPages > 1) {
            for (let i = 1; i <= totalPages; i++) {
                const btn = document.createElement('button');
                btn.className = 'page-btn'; btn.id = 'btnPage_' + i; btn.innerText = i;
                btn.onclick = () => showPage(i);
                paginationContainer.appendChild(btn);
            }
            showPage(1); 
        }

        function openDetailModal(modalId) { document.getElementById(modalId).style.display = 'flex'; }
        function closeSpecificModal(modalId) { document.getElementById(modalId).style.display = 'none'; }
        window.onclick = function(event) { if (event.target.classList.contains('modal')) event.target.style.display = 'none'; }

        // HÀM IN ẤN CHUẨN A4 XUẤT PDF
        function printReceipt(divId) {
            var printContents = document.getElementById(divId).innerHTML;
            var printWindow = window.open('', '', 'height=800,width=800');
            printWindow.document.write('<html><head><title>In Phiếu / Xuất PDF</title>');
            printWindow.document.write(`
                <style>
                    body { font-family: 'Segoe UI', Arial, sans-serif; color: #000; padding: 20px; line-height: 1.5; background: #fff;}
                    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                    th { background-color: #f2f2f2 !important; -webkit-print-color-adjust: exact; }
                    th, td { border: 1px solid #000; padding: 10px; text-align: left; }
                    h2 { color: #000 !important; }
                    /* Định dạng kích thước giấy A4 */
                    @page { size: A4; margin: 15mm; }
                    @media print {
                        body { padding: 0; }
                    }
                </style>
            `);
            printWindow.document.write('</head><body>');
            printWindow.document.write(printContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            
            setTimeout(function() {
                printWindow.print();
                printWindow.close();
            }, 500);
        }
    </script>
</body>
</html>