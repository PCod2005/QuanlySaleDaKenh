<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Lập Phiếu Nhập Kho</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .import-container { display: flex; gap: 20px; height: calc(100vh - 170px); margin-top: 15px;}
        .left-panel { flex: 6.5; background: #fff; border-radius: 8px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); display: flex; flex-direction: column; overflow: hidden;}
        .right-panel { flex: 3.5; background: #fff; border-radius: 8px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); display: flex; flex-direction: column; overflow: hidden;}
        
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; overflow-y: auto; padding-right: 5px; margin-top: 15px;}
        .product-card { border: 1px solid #eaecf4; border-radius: 8px; padding: 12px; text-align: center; cursor: pointer; transition: 0.2s;}
        .product-card:hover { border-color: #4e73df; box-shadow: 0 4px 10px rgba(78,115,223,0.15); transform: translateY(-2px);}
        .product-card img { width: 100%; height: 110px; object-fit: cover; border-radius: 6px; margin-bottom: 10px;}
        
        .cart-table { width: 100%; border-collapse: collapse; margin-top: 5px; }
        .cart-table th { background: #f8f9fc; padding: 10px; font-size: 12px; color: var(--primary); text-transform: uppercase; position: sticky; top: 0;}
        .cart-table td { padding: 10px; border-bottom: 1px solid #eee; font-size: 13px; vertical-align: middle;}
        
        .qty-input { width: 50px; padding: 5px; text-align: center; border: 1px solid #d1d3e2; border-radius: 4px; font-weight: bold;}
        .price-input { width: 85px; padding: 5px; border: 1px solid #d1d3e2; border-radius: 4px; }
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; }
        .modal-content { background: #fff; border-radius: 12px; width: 700px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; }
        .modal-header { background: linear-gradient(45deg, #1cc88a, #13855c); color: white; padding: 18px 25px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 24px; cursor: pointer; }
        .modal-body { padding: 25px; overflow-y: auto; }
        
        .btn-gradient { border: none; border-radius: 6px; padding: 8px 14px; color: white; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-size: 13px; transition: 0.3s; text-decoration: none;}
        .btn-success { background: linear-gradient(45deg, #1cc88a, #13855c); }
        .btn-primary { background: linear-gradient(45deg, #4e73df, #224abe); }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <!-- HIỂN THỊ THÔNG BÁO -->
            <c:if test="${not empty sessionScope.errorMsg}">
                <div style="background: #fdeaea; color: #e74a3b; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; border-left: 5px solid #e74a3b; display: flex; justify-content: space-between; align-items: center;" id="alertMsg">
                    <span><i class="fa-solid fa-triangle-exclamation"></i> ${sessionScope.errorMsg}</span>
                    <i class="fa-solid fa-xmark" style="cursor:pointer; font-size: 18px;" onclick="document.getElementById('alertMsg').style.display='none'"></i>
                </div>
                <c:remove var="errorMsg" scope="session"/>
            </c:if>

            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: var(--dark); font-size: 24px; margin: 0;"><i class="fa-solid fa-truck-ramp-box" style="color: #1cc88a; margin-right: 10px;"></i>Lập Phiếu Nhập Kho</h2>
                    <hr style="height: 3px; background: linear-gradient(90deg, #1cc88a, #36b9cc, transparent); border: none; margin: 10px 0 0 0; border-radius: 5px; width: 150px;">
                </div>
                <div>
                    <a href="${pageContext.request.contextPath}/inventory" class="btn-gradient" style="background: #858796;"><i class="fa-solid fa-arrow-left"></i> Trở về Kho</a>
                </div>
            </div>

            <!-- GIAO DIỆN LẬP PHIẾU -->
            <div class="import-container">
                <div class="left-panel">
                    <input type="text" id="searchInput" class="form-control" placeholder="Tìm kiếm tên sản phẩm..." style="width: 100%; padding: 12px; font-size: 15px;">
                    <div class="product-grid" id="productGrid">
                        <c:forEach var="entry" items="${groupedProducts}" varStatus="loop">
                            <c:set var="baseName" value="${entry.key}" />
                            <c:set var="variants" value="${entry.value}" />
                            <c:set var="firstVariant" value="${variants[0]}" />
                            
                            <div class="product-card" data-name="${fn:toLowerCase(baseName)}" onclick="openVariantSelector('selectModal_${loop.index}')">
                                <img src="${firstVariant.anh != null ? firstVariant.anh : 'https://via.placeholder.com/150'}" alt="${baseName}">
                                <div style="font-weight: bold; font-size: 14px; color: var(--dark); margin-bottom: 5px;">${baseName}</div>
                                <div style="font-size: 12px; color: gray;">${fn:length(variants)} Phân loại</div>
                            </div>

                            <div id="selectModal_${loop.index}" class="modal" onclick="event.stopPropagation()">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 style="margin:0;">Nhập Kho: ${baseName}</h3>
                                        <span class="close-btn" onclick="closeSpecificModal('selectModal_${loop.index}')">&times;</span>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table" style="width:100%; text-align:left;">
                                            <thead>
                                                <tr>
                                                    <th>Phân loại (Màu/Size)</th>
                                                    <th style="width: 110px;">Giá nhập (₫)</th>
                                                    <th style="width: 90px; text-align:center;">Số lượng</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <c:forEach var="v" items="${variants}">
                                                    <c:set var="vName" value="${fn:replace(v.tenSP, baseName, '')}" />
                                                    <c:set var="vName" value="${fn:replace(vName, ' - ', ' ')}" />
                                                    <c:if test="${empty vName}"><c:set var="vName" value="(Bản tiêu chuẩn)" /></c:if>
                                                    <tr>
                                                        <td style="font-weight:bold; color:var(--primary);">${vName}</td>
                                                        <td><input type="number" id="gn_${v.maSP}" value="${v.giaNhap}" class="price-input"></td>
                                                        <td style="text-align:center;"><input type="number" id="qty_${v.maSP}" min="0" value="0" class="qty-input"></td>
                                                    </tr>
                                                </c:forEach>
                                            </tbody>
                                        </table>
                                        <button class="btn-gradient btn-success" style="width: 100%; margin-top: 20px; padding: 12px; font-size: 14px;" 
                                                onclick="addVariantsToCart('${baseName}', '${loop.index}'); closeSpecificModal('selectModal_${loop.index}')">
                                            <i class="fa-solid fa-check"></i> XÁC NHẬN ĐƯA VÀO PHIẾU
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>

                <div class="right-panel">
                    <h3 style="margin-top:0; color: var(--dark); border-bottom: 2px solid #eee; padding-bottom: 10px;">Chi Tiết Phiếu Nhập</h3>
                    
                    <form action="${pageContext.request.contextPath}/inventory" method="post" id="importForm" style="display: flex; flex-direction: column; flex-grow: 1;">
                        <input type="hidden" name="action" value="checkout">
                        
                        <div style="flex-grow: 1; overflow-y: auto;">
                            <table class="cart-table">
                                <thead><tr><th>Sản phẩm</th><th style="text-align:center;">SL</th><th style="text-align:right;">Thành tiền</th><th></th></tr></thead>
                                <tbody id="cartBody">
                                    <tr id="emptyRow"><td colspan="4" style="text-align:center; color:gray; padding: 30px 0;"><i class="fa-solid fa-box-open fa-2x" style="color:#ddd; margin-bottom:10px;"></i><br>Chưa có sản phẩm nào.</td></tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div style="border-top: 2px solid #eee; padding-top: 15px; margin-top: 10px;">
                            <input type="text" name="ghiChu" class="form-control" placeholder="Ghi chú (Tên nhà cung cấp...)" required style="width:100%; margin-bottom: 15px; padding: 10px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 15px;">
                                <span style="font-weight:bold; font-size: 16px;">TỔNG TIỀN NHẬP:</span>
                                <span id="totalAmountText" style="font-weight:900; font-size: 24px; color: var(--danger);">0 ₫</span>
                            </div>
                            <button type="button" class="btn-gradient btn-success" style="width:100%; padding: 15px; font-size: 16px;" onclick="submitCart()">
                                <i class="fa-solid fa-floppy-disk"></i> HOÀN TẤT NHẬP KHO
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- MODAL XÁC NHẬN NHẬP KHO CHUYÊN NGHIỆP -->
    <div id="confirmModal" class="modal">
        <div class="modal-content" style="width: 450px; text-align: center; padding-bottom: 20px;">
            <div class="modal-header" style="background: linear-gradient(45deg, #f6c23e, #d49a15); justify-content: center; position: relative;">
                <h3 style="margin:0;"><i class="fa-solid fa-circle-exclamation"></i> YÊU CẦU XÁC NHẬN</h3>
                <span class="close-btn" style="position: absolute; right: 20px;" onclick="closeSpecificModal('confirmModal')">&times;</span>
            </div>
            <div class="modal-body" style="padding: 30px 25px 10px 25px;">
                <i class="fa-solid fa-boxes-packing fa-4x" style="color: #1cc88a; margin-bottom: 20px;"></i>
                <h3 style="color: var(--dark); margin-bottom: 15px;">Hoàn Tất Lập Phiếu?</h3>
                <p style="color: #555; margin-bottom: 15px; font-size: 15px;">
                    Bạn sắp nhập kho lô hàng với tổng giá trị:<br>
                    <b style="color: var(--danger); font-size: 26px; display: inline-block; margin-top: 10px;" id="confirmTotal"></b>
                </p>
                <div style="background: #fdeaea; padding: 10px; border-radius: 6px; margin-bottom: 25px;">
                    <p style="font-size: 13px; color: #e74a3b; margin: 0; font-weight: bold;">
                        <i class="fa-solid fa-triangle-exclamation"></i> Lưu ý: Dữ liệu Tồn kho sẽ được cộng thêm ngay lập tức và lưu vào lịch sử.
                    </p>
                </div>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button type="button" class="btn-gradient" style="background: #858796; padding: 12px 25px; font-size: 15px;" onclick="closeSpecificModal('confirmModal')">Hủy bỏ</button>
                    <button type="button" class="btn-gradient btn-success" style="padding: 12px 25px; font-size: 15px;" onclick="executeSubmit()">
                        <i class="fa-solid fa-check"></i> XÁC NHẬN
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('searchInput').addEventListener('input', function(e) {
            let keyword = e.target.value.toLowerCase();
            let cards = document.querySelectorAll('.product-card');
            cards.forEach(card => {
                if (card.getAttribute('data-name').includes(keyword)) card.style.display = 'block';
                else card.style.display = 'none';
            });
        });

        function openVariantSelector(modalId) { document.getElementById(modalId).style.display = 'flex'; }
        function closeSpecificModal(modalId) { document.getElementById(modalId).style.display = 'none'; }
        window.onclick = function(event) { if (event.target.classList.contains('modal')) event.target.style.display = 'none'; }

        let cartTotal = 0;
        let itemCounter = 0;

        function addVariantsToCart(baseName, loopIndex) {
            const modal = document.getElementById('selectModal_' + loopIndex);
            const qtyInputs = modal.querySelectorAll('.qty-input');
            const cartBody = document.getElementById('cartBody');
            
            if(document.getElementById('emptyRow')) document.getElementById('emptyRow').remove();
            
            qtyInputs.forEach(input => {
                let qty = parseInt(input.value);
                if (qty > 0) {
                    let id = input.id.split('_')[1];
                    let tr = input.closest('tr');
                    let variantName = tr.cells[0].innerText;
                    let price = parseInt(document.getElementById('gn_' + id).value);
                    let subTotal = qty * price;
                    cartTotal += subTotal;
                    
                    let row = document.createElement('tr');
                    row.id = 'cartItem_' + itemCounter;
                    row.innerHTML = `
                        <td>
                            <input type="hidden" name="maSP[]" value="\${id}">
                            <input type="hidden" name="soLuong[]" value="\${qty}">
                            <input type="hidden" name="giaNhap[]" value="\${price}">
                            <div style="font-weight:bold; color:#4e73df;">\${baseName}</div>
                            <div style="font-size:11px; color:gray;">\${variantName}</div>
                            <div style="font-size:11px;">Giá: \${price.toLocaleString('vi-VN')} ₫</div>
                        </td>
                        <td style="text-align:center; font-weight:bold;">\${qty}</td>
                        <td style="text-align:right; font-weight:bold; color:var(--danger);">\${subTotal.toLocaleString('vi-VN')} ₫</td>
                        <td style="text-align:center; color:red; cursor:pointer;" onclick="removeCartItem('\${row.id}', \${subTotal})"><i class="fa-solid fa-trash-can" style="background:#fdeaea; padding:6px; border-radius:4px;"></i></td>
                    `;
                    cartBody.appendChild(row);
                    input.value = 0; 
                    itemCounter++;
                }
            });
            document.getElementById('totalAmountText').innerText = cartTotal.toLocaleString('vi-VN') + ' ₫';
        }

        function removeCartItem(rowId, subTotal) {
            document.getElementById(rowId).remove();
            cartTotal -= subTotal;
            document.getElementById('totalAmountText').innerText = cartTotal.toLocaleString('vi-VN') + ' ₫';
            if(cartTotal === 0) document.getElementById('cartBody').innerHTML = '<tr id="emptyRow"><td colspan="4" style="text-align:center; color:gray; padding: 30px 0;"><i class="fa-solid fa-box-open fa-2x" style="color:#ddd; margin-bottom:10px;"></i><br>Chưa có sản phẩm nào.</td></tr>';
        }

        function submitCart() {
            if(cartTotal === 0) {
                alert("Vui lòng chọn ít nhất 1 sản phẩm để nhập kho!");
                return;
            }
            // Gọi Hộp thoại Modal Xác nhận
            document.getElementById('confirmTotal').innerText = cartTotal.toLocaleString('vi-VN') + ' ₫';
            document.getElementById('confirmModal').style.display = 'flex';
        }

        function executeSubmit() {
            document.getElementById('importForm').submit();
        }
    </script>
</body>
</html>