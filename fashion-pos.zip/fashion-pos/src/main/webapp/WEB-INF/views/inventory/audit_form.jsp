<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cân Bằng / Kiểm Kê Kho</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .import-container { display: flex; gap: 20px; height: calc(100vh - 170px); margin-top: 15px;}
        .left-panel { flex: 5.5; background: #fff; border-radius: 8px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); display: flex; flex-direction: column; overflow: hidden;}
        .right-panel { flex: 4.5; background: #fff; border-radius: 8px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); display: flex; flex-direction: column; overflow: hidden;}
        
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 15px; overflow-y: auto; padding-right: 5px; margin-top: 15px;}
        .product-card { border: 1px solid #eaecf4; border-radius: 8px; padding: 12px; text-align: center; cursor: pointer; transition: 0.2s;}
        .product-card:hover { border-color: #f6c23e; box-shadow: 0 4px 10px rgba(246,194,62,0.15); transform: translateY(-2px);}
        .product-card img { width: 100%; height: 100px; object-fit: cover; border-radius: 6px; margin-bottom: 10px;}
        
        .cart-table { width: 100%; border-collapse: collapse; margin-top: 5px; }
        .cart-table th { background: #fef2ce; padding: 10px; font-size: 12px; color: #d49a15; text-transform: uppercase; position: sticky; top: 0;}
        .cart-table td { padding: 10px; border-bottom: 1px solid #eee; font-size: 13px; vertical-align: middle;}
        
        .qty-input { width: 60px; padding: 5px; text-align: center; border: 1px solid #d1d3e2; border-radius: 4px; font-weight: bold; background: #fff;}
        .diff-text { font-weight: bold; padding: 2px 6px; border-radius: 4px;}
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; }
        .modal-content { background: #fff; border-radius: 12px; width: 650px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; }
        .modal-header { background: linear-gradient(45deg, #f6c23e, #d49a15); color: white; padding: 18px 25px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 24px; cursor: pointer; }
        .modal-body { padding: 25px; overflow-y: auto; }
        
        .btn-gradient { border: none; border-radius: 6px; padding: 8px 14px; color: white; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-size: 13px; transition: 0.3s; text-decoration: none;}
        .btn-warning { background: linear-gradient(45deg, #f6c23e, #d49a15); }
    </style>
</head>
<body style="background-color: #f8f9fc; margin: 0;">
    <jsp:include page="../layout/sidebar.jsp" />
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: var(--dark); font-size: 24px; margin: 0;"><i class="fa-solid fa-scale-balanced" style="color: #f6c23e; margin-right: 10px;"></i>Phiếu Cân Bằng / Kiểm Kê</h2>
                    <hr style="height: 3px; background: linear-gradient(90deg, #f6c23e, transparent); border: none; margin: 10px 0 0 0; border-radius: 5px; width: 150px;">
                </div>
                <div>
                    <a href="${pageContext.request.contextPath}/inventory" class="btn-gradient" style="background: #858796;"><i class="fa-solid fa-arrow-left"></i> Trở về Kho</a>
                </div>
            </div>

            <div class="import-container">
                <!-- CỘT TRÁI: DANH SÁCH -->
                <div class="left-panel">
                    <input type="text" id="searchInput" class="form-control" placeholder="Tìm sản phẩm cần kiểm kê..." style="width: 100%; padding: 12px; font-size: 15px;">
                    
                    <div class="product-grid" id="productGrid">
                        <c:forEach var="entry" items="${groupedProducts}" varStatus="loop">
                            <c:set var="baseName" value="${entry.key}" />
                            <c:set var="variants" value="${entry.value}" />
                            <c:set var="firstVariant" value="${variants[0]}" />
                            
                            <div class="product-card" data-name="${fn:toLowerCase(baseName)}" onclick="openVariantSelector('selectModal_${loop.index}')">
                                <img src="${firstVariant.anh != null ? firstVariant.anh : 'https://via.placeholder.com/150'}" alt="${baseName}">
                                <div style="font-weight: bold; font-size: 13px; color: var(--dark); margin-bottom: 5px;">${baseName}</div>
                            </div>

                            <div id="selectModal_${loop.index}" class="modal" onclick="event.stopPropagation()">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h3 style="margin:0;">Kiểm Kê: ${baseName}</h3>
                                        <span class="close-btn" onclick="closeSpecificModal('selectModal_${loop.index}')">&times;</span>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table" style="width:100%; text-align:left;">
                                            <thead>
                                                <tr>
                                                    <th>Phân loại</th>
                                                    <th style="width: 100px; text-align:center;">Tồn hệ thống</th>
                                                    <th style="width: 120px; text-align:center;">Tồn kho thực tế</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <c:forEach var="v" items="${variants}">
                                                    <c:set var="vName" value="${fn:replace(v.tenSP, baseName, '')}" />
                                                    <c:set var="vName" value="${fn:replace(vName, ' - ', ' ')}" />
                                                    <c:if test="${empty vName}"><c:set var="vName" value="(Bản tiêu chuẩn)" /></c:if>
                                                    <tr>
                                                        <td style="font-weight:bold; color:var(--primary);">${vName}</td>
                                                        <td style="text-align:center; font-weight:bold; color:gray;" id="sysQty_${v.maSP}">${v.soLuongTon}</td>
                                                        <td style="text-align:center;">
                                                            <!-- Ô nhập số lượng thực tế -->
                                                            <input type="number" id="actualQty_${v.maSP}" value="${v.soLuongTon}" min="0" class="qty-input">
                                                        </td>
                                                    </tr>
                                                </c:forEach>
                                            </tbody>
                                        </table>
                                        <button class="btn-gradient btn-warning" style="width: 100%; margin-top: 20px; padding: 12px; font-size: 14px;" 
                                                onclick="addVariantsToAudit('${baseName}', '${loop.index}'); closeSpecificModal('selectModal_${loop.index}')">
                                            <i class="fa-solid fa-plus"></i> ĐƯA VÀO PHIẾU KIỂM KÊ
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </c:forEach>
                    </div>
                </div>

                <!-- CỘT PHẢI: CHI TIẾT PHIẾU -->
                <div class="right-panel">
                    <h3 style="margin-top:0; color: var(--dark); border-bottom: 2px solid #eee; padding-bottom: 10px;">Chi Tiết Phiếu Kiểm Kê</h3>
                    
                    <form action="${pageContext.request.contextPath}/inventory" method="post" id="auditForm" style="display: flex; flex-direction: column; flex-grow: 1;">
                        <input type="hidden" name="action" value="audit_checkout">
                        
                        <div style="flex-grow: 1; overflow-y: auto;">
                            <table class="cart-table">
                                <thead><tr><th>Sản phẩm</th><th style="text-align:center;">Hệ thống</th><th style="text-align:center;">Thực tế</th><th style="text-align:center;">Chênh lệch</th><th></th></tr></thead>
                                <tbody id="auditBody">
                                    <tr id="emptyRow"><td colspan="5" style="text-align:center; color:gray; padding: 30px 0;"><i class="fa-solid fa-clipboard-check fa-2x" style="color:#ddd; margin-bottom:10px;"></i><br>Chưa có sản phẩm cần kiểm kê.</td></tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div style="border-top: 2px solid #eee; padding-top: 15px; margin-top: 10px;">
                            <input type="text" name="ghiChu" class="form-control" placeholder="Ghi chú (Lý do chênh lệch, mất hàng...)" required style="width:100%; margin-bottom: 15px; padding: 10px;">
                            <button type="button" class="btn-gradient btn-warning" style="width:100%; padding: 15px; font-size: 16px;" onclick="submitAudit()">
                                <i class="fa-solid fa-scale-balanced"></i> XÁC NHẬN CÂN BẰNG KHO
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- MODAL XÁC NHẬN KIỂM KÊ -->
    <div id="confirmModal" class="modal">
        <div class="modal-content" style="width: 450px; text-align: center; padding-bottom: 20px;">
            <div class="modal-header" style="background: linear-gradient(45deg, #e74a3b, #be2617); justify-content: center; position: relative;">
                <h3 style="margin:0;"><i class="fa-solid fa-triangle-exclamation"></i> LƯU Ý QUAN TRỌNG</h3>
                <span class="close-btn" style="position: absolute; right: 20px;" onclick="closeSpecificModal('confirmModal')">&times;</span>
            </div>
            <div class="modal-body" style="padding: 30px 25px 10px 25px;">
                <i class="fa-solid fa-scale-balanced fa-4x" style="color: #f6c23e; margin-bottom: 20px;"></i>
                <h3 style="color: var(--dark); margin-bottom: 15px;">Hoàn Tất Cân Bằng Kho?</h3>
                <p style="color: #555; margin-bottom: 15px; font-size: 14px;">
                    Hệ thống sẽ <b>thay thế số lượng Tồn Kho hiện tại bằng Số lượng Thực Tế</b> mà bạn vừa nhập.<br><br>
                    Các chênh lệch (+/-) sẽ được ghi nhận vào Lịch sử giao dịch dưới dạng Phiếu Kiểm Kê. Thao tác này không thể hoàn tác!
                </p>
                <div style="display: flex; gap: 15px; justify-content: center; margin-top: 20px;">
                    <button type="button" class="btn-gradient" style="background: #858796; padding: 12px 25px;" onclick="closeSpecificModal('confirmModal')">Hủy bỏ</button>
                    <button type="button" class="btn-gradient btn-warning" style="padding: 12px 25px;" onclick="executeSubmit()">XÁC NHẬN ĐIỀU CHỈNH</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('searchInput').addEventListener('input', function(e) {
            let keyword = e.target.value.toLowerCase();
            let cards = document.querySelectorAll('.product-card');
            cards.forEach(card => {
                if (card.getAttribute('data-name').includes(keyword)) card.style.display = 'block';
                else card.style.display = 'none';
            });
        });

        function openVariantSelector(modalId) { document.getElementById(modalId).style.display = 'flex'; }
        function closeSpecificModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

        let itemCounter = 0;
        let hasAuditItems = false;

        function addVariantsToAudit(baseName, loopIndex) {
            const modal = document.getElementById('selectModal_' + loopIndex);
            const actualInputs = modal.querySelectorAll('.qty-input');
            const auditBody = document.getElementById('auditBody');
            
            if(document.getElementById('emptyRow')) document.getElementById('emptyRow').remove();
            
            actualInputs.forEach(input => {
                let actualQty = parseInt(input.value);
                let id = input.id.split('_')[1];
                let sysQty = parseInt(document.getElementById('sysQty_' + id).innerText);
                let diff = actualQty - sysQty;
                
                // CHỈ THÊM VÀO BẢNG NẾU CÓ SỰ CHÊNH LỆCH
                if (diff !== 0) {
                    hasAuditItems = true;
                    let tr = input.closest('tr');
                    let variantName = tr.cells[0].innerText;
                    
                    let diffHtml = diff > 0 
                        ? `<span class="diff-text" style="color: #1cc88a; background: #e3fbed;">+`+diff+`</span>`
                        : `<span class="diff-text" style="color: #e74a3b; background: #fdeaea;">`+diff+`</span>`;

                    let row = document.createElement('tr');
                    row.id = 'auditItem_' + itemCounter;
                    
                    row.innerHTML = `
                        <td>
                            <input type="hidden" name="maSP[]" value="\${id}">
                            <input type="hidden" name="soLuongThucTe[]" value="\${actualQty}">
                            <input type="hidden" name="chenhLech[]" value="\${diff}">
                            <div style="font-weight:bold; color:#4e73df;">\${baseName}</div>
                            <div style="font-size:11px; color:gray;">\${variantName}</div>
                        </td>
                        <td style="text-align:center; font-weight:bold; color:gray;">\${sysQty}</td>
                        <td style="text-align:center; font-weight:bold; color:var(--dark);">\${actualQty}</td>
                        <td style="text-align:center;">\${diffHtml}</td>
                        <td style="text-align:center; color:red; cursor:pointer;" onclick="removeAuditItem('\${row.id}')"><i class="fa-solid fa-xmark"></i></td>
                    `;
                    auditBody.appendChild(row);
                    itemCounter++;
                }
            });
            // Ẩn modal sau khi thêm xong
            modal.style.display = 'none';
        }

        function removeAuditItem(rowId) {
            document.getElementById(rowId).remove();
            if(document.getElementById('auditBody').children.length === 0) {
                hasAuditItems = false;
                document.getElementById('auditBody').innerHTML = '<tr id="emptyRow"><td colspan="5" style="text-align:center; color:gray; padding: 30px 0;">Chưa có sản phẩm cần kiểm kê.</td></tr>';
            }
        }

        function submitAudit() {
            if(!hasAuditItems) {
                alert("Không có sản phẩm nào bị chênh lệch tồn kho để kiểm kê!");
                return;
            }
            document.getElementById('confirmModal').style.display = 'flex';
        }

        function executeSubmit() {
            document.getElementById('auditForm').submit();
        }
    </script>
</body>
</html>