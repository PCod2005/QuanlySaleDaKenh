<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Sản phẩm - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .topbar { padding: 15px 30px !important; box-shadow: 0 2px 10px rgba(0,0,0,0.05) !important; background: #fff !important; width: 100% !important; }
        .main-wrapper .content { padding: 25px 30px; }

        .table-custom { border-collapse: separate; border-spacing: 0 10px; margin-top: 10px; width: 100%; }
        .table-custom th { background: transparent; color: var(--dark); text-transform: uppercase; font-size: 13px; border: none; padding-bottom: 5px; }
        .table-custom td { background: #fff; padding: 15px; vertical-align: middle; border-top: 1px solid #f1f3f5; border-bottom: 1px solid #f1f3f5; }
        .table-custom td:first-child { border-left: 1px solid #f1f3f5; border-radius: 8px 0 0 8px; }
        .table-custom td:last-child { border-right: 1px solid #f1f3f5; border-radius: 0 8px 8px 0; }
        .table-custom tr:hover td { box-shadow: 0 4px 15px rgba(0,0,0,0.05); transform: translateY(-1px); transition: all 0.2s; }

        .btn-gradient { border: none; border-radius: 6px; padding: 8px 14px; color: white; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-size: 12px; transition: 0.3s; text-decoration: none;}
        .btn-gradient-primary { background: linear-gradient(45deg, #4e73df, #224abe); }
        .btn-gradient-info { background: linear-gradient(45deg, #36b9cc, #1e8a99); }
        .btn-gradient-warning { background: linear-gradient(45deg, #f6c23e, #d49a15); color: #fff; }
        .btn-gradient-danger { background: linear-gradient(45deg, #e74a3b, #be2617); }
        .btn-gradient-success { background: linear-gradient(45deg, #1cc88a, #13855c); }
        .btn-gradient:hover { transform: translateY(-2px); filter: brightness(1.1); }
        
        .status-pill { padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; text-align: center; min-width: 90px;}
        
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; }
        .modal-content { background: #fff; border-radius: 12px; max-height: 95vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; }
        .modal-header { background: linear-gradient(45deg, #4e73df, #36b9cc); color: white; padding: 18px 25px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 24px; cursor: pointer; }
        .modal-body { padding: 25px; overflow-y: auto; }
        
        .color-tags-container { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
        .color-tag { background: #eaecf4; border-radius: 15px; padding: 5px 12px; font-size: 13px; font-weight: bold; display: flex; align-items: center; gap: 8px;}
        .size-checkboxes { display: flex; gap: 15px; flex-wrap: wrap; margin-top: 10px; background: #fff; padding: 10px; border-radius: 6px; border: 1px solid #d1d3e2;}
        .img-preview { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; border: 1px solid #ddd; cursor: pointer;}
        
        .variant-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .variant-table th, .variant-table td { padding: 12px 10px; border-bottom: 1px solid #eee; font-size: 13px; }
        .variant-table th { background: #f8f9fc; color: var(--primary); }

        .search-wrapper { display: flex; gap: 10px; margin-bottom: 15px; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05);}
        .pagination-container { display: flex; justify-content: center; gap: 8px; margin-top: 20px; margin-bottom: 15px;}
        .page-btn { padding: 8px 14px; border: 1px solid #d1d3e2; background: #fff; border-radius: 6px; cursor: pointer; font-weight: bold; color: var(--primary); transition: 0.2s;}
        .page-btn:hover { background: #eaecf4; }
        .page-btn.active { background: #4e73df; color: white; border-color: #4e73df; }
        .product-link:hover { text-decoration: underline; color: #224abe !important; cursor: pointer; }
        
        /* Cấu hình ô Input bị khóa */
        .locked-input { background-color: #e9ecef !important; pointer-events: none; opacity: 0.8; }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        <div class="content">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: var(--dark); font-size: 24px; margin: 0;"><i class="fa-solid fa-shirt" style="color: #4e73df; margin-right: 10px;"></i>Quản lý Sản Phẩm</h2>
                    <hr style="height: 3px; background: linear-gradient(90deg, #4e73df, #36b9cc, transparent); border: none; margin: 15px 0 20px 0; border-radius: 5px; width: 150px;">
                </div>
                <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                    <button class="btn-gradient btn-gradient-primary" onclick="openAddModal()">
                        <i class="fa-solid fa-layer-group"></i> Tạo Mẫu Sản Phẩm Mới
                    </button>
                </c:if>
            </div>

            <!-- THANH TÌM KIẾM & PHÂN LOẠI -->
            <form class="search-wrapper" action="${pageContext.request.contextPath}/product" method="get">
                <input type="text" name="keyword" class="form-control" style="flex-grow: 1; max-width: 400px;" placeholder="Tìm theo mã SKU hoặc tên..." value="${keyword}">
                <select name="catId" class="form-control" style="width: 200px;">
                    <option value="">-- Tất cả danh mục --</option>
                    <c:forEach var="c" items="${categories}">
                        <option value="${c.maDM}" ${catId == c.maDM ? 'selected' : ''}>${c.tenDM}</option>
                    </c:forEach>
                </select>
                <button type="submit" class="btn-gradient btn-gradient-info"><i class="fa-solid fa-magnifying-glass"></i> Tìm kiếm</button>
                <c:if test="${not empty keyword or not empty catId}">
                    <a href="${pageContext.request.contextPath}/product" class="btn-gradient btn-gradient-danger"><i class="fa-solid fa-xmark"></i> Hủy lọc</a>
                </c:if>
            </form>

            <!-- BẢNG CHÍNH SẢN PHẨM GỐC -->
            <div class="card" style="border: none; box-shadow: none; background: transparent; padding: 0;">
                <table class="table table-custom" id="mainProductTable">
                    <thead>
                        <tr>
                            <th style="width: 60px; text-align:center;">Ảnh</th>
                            <th>Mẫu Sản Phẩm (Click để xem chi tiết)</th>
                            <th>Danh mục</th>
                            <th>Giá Bán Chung</th>
                            <th style="text-align: center;">Tồn Kho</th>
                            <th style="text-align: center;">Thao tác Nhóm</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <c:forEach var="entry" items="${groupedProducts}" varStatus="loop">
                            <c:set var="baseName" value="${entry.key}" />
                            <c:set var="variants" value="${entry.value}" />
                            <c:set var="firstVariant" value="${variants[0]}" />
                            <c:set var="totalStock" value="0" />
                            <c:set var="allVariantIds" value="" />
                            
                            <c:forEach var="v" items="${variants}">
                                <c:set var="totalStock" value="${totalStock + v.soLuongTon}" />
                                <c:set var="allVariantIds" value="${allVariantIds}${v.maSP}," />
                            </c:forEach>

                            <tr class="product-row">
                                <td style="text-align:center;">
                                    <c:choose>
                                        <c:when test="${not empty firstVariant.anh}"><img src="${firstVariant.anh}" class="img-preview"></c:when>
                                        <c:otherwise><div class="img-preview" style="background:#eee; display:flex; align-items:center; justify-content:center;"><i class="fa-solid fa-image" style="color:#ccc;"></i></div></c:otherwise>
                                    </c:choose>
                                </td>
                                <td>
                                    <!-- CICK VÀO TÊN ĐỂ XEM CHI TIẾT SẢN PHẨM -->
                                    <a class="product-link" style="font-weight: bold; font-size: 16px; color: #4e73df; text-decoration: none;" 
                                       onclick="openDetailModal('${baseName}', '${firstVariant.tenDM}', ${firstVariant.giaNhap}, ${firstVariant.giaBan}, '${firstVariant.moTa}', '${firstVariant.anh}', ${fn:length(variants)}, ${totalStock})">
                                       ${baseName}
                                    </a><br>
                                    <span style="font-size: 12px; color: gray;"><i class="fa-solid fa-tags"></i> ${fn:length(variants)} phân loại (màu/size)</span>
                                </td>
                                <td><span style="background: #f1f3f5; padding: 4px 8px; border-radius: 4px; font-size: 12px; color:var(--dark);"><i class="fa-solid fa-tag"></i> ${firstVariant.tenDM}</span></td>
                                <td style="color: var(--danger); font-weight: bold;"><fmt:formatNumber value="${firstVariant.giaBan}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></td>
                                <td style="text-align: center;">
                                    <span style="font-weight: 900; font-size: 16px; color: ${totalStock <= 0 ? '#e74a3b' : (totalStock <= 10 ? '#f6c23e' : '#1cc88a')};">
                                        ${totalStock}
                                    </span>
                                </td>
                                <td style="text-align: center; min-width: 280px;">
                                    <button class="btn-gradient btn-gradient-info" onclick="openVariantsModal('variantsModal_${loop.index}')" title="Quản lý từng Size/Màu">
                                        <i class="fa-solid fa-list"></i> Biến thể
                                    </button>
                                    <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                                        <button class="btn-gradient btn-gradient-warning" onclick="openEditGroupModal('${baseName}', ${firstVariant.maDM}, ${firstVariant.giaNhap}, ${firstVariant.giaBan}, '${firstVariant.moTa}', '${firstVariant.anh}', '${allVariantIds}')">
                                            <i class="fa-solid fa-pen"></i> Sửa chung
                                        </button>
                                        <form action="${pageContext.request.contextPath}/product" method="post" style="display:inline;" onsubmit="return confirm('CẢNH BÁO: Bạn chuẩn bị Xóa toàn bộ biến thể. Tiếp tục?');">
                                            <input type="hidden" name="action" value="deleteGroup">
                                            <input type="hidden" name="maSPList" value="${allVariantIds}">
                                            <button type="submit" class="btn-gradient btn-gradient-danger"><i class="fa-solid fa-trash"></i> Xóa hết</button>
                                        </form>
                                    </c:if>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
                
                <!-- NÚT PHÂN TRANG -->
                <div class="pagination-container" id="pagination"></div>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- MODAL XEM CHI TIẾT SẢN PHẨM -->
    <div id="detailModal" class="modal">
        <div class="modal-content" style="width: 450px;">
            <div class="modal-header">
                <h3 style="margin:0;"><i class="fa-solid fa-circle-info"></i> Bảng Thông Tin Sản Phẩm</h3>
                <span class="close-btn" onclick="closeSpecificModal('detailModal')">&times;</span>
            </div>
            <div class="modal-body" style="text-align: center;">
                <img id="detailImg" src="" style="width: 250px; height: 250px; object-fit: cover; border-radius: 10px; border: 1px solid #ddd; margin: 0 auto 15px auto; display: none; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                <div id="detailImgPlaceholder" style="width: 250px; height: 250px; background: #f1f3f5; border-radius: 10px; margin: 0 auto 15px auto; display: flex; align-items: center; justify-content: center; font-size: 50px; color: #ccc;"><i class="fa-solid fa-image"></i></div>
                
                <h3 id="detailName" style="color: var(--primary); margin-bottom: 5px; font-size: 22px;"></h3>
                <span id="detailCat" style="background: #f1f3f5; padding: 4px 10px; border-radius: 15px; font-size: 12px; color: gray; font-weight: bold; margin-bottom: 15px; display: inline-block;"></span>
                
                <div style="background: #f8f9fc; padding: 20px; border-radius: 8px; text-align: left; margin-top: 10px;">
                    <div style="display:flex; justify-content:space-between; margin-bottom: 10px;"><span>Giá nhập kho:</span> <strong id="detailImport" style="color: gray;"></strong></div>
                    <div style="display:flex; justify-content:space-between; margin-bottom: 10px;"><span>Giá bán niêm yết:</span> <strong id="detailExport" style="color: var(--danger); font-size: 18px;"></strong></div>
                    <div style="display:flex; justify-content:space-between; margin-bottom: 10px;"><span>Số lượng phân loại:</span> <strong id="detailVariants"></strong></div>
                    <div style="display:flex; justify-content:space-between; margin-bottom: 10px;"><span>Tổng Tồn kho:</span> <strong id="detailStock" style="color: var(--success); font-size: 18px;"></strong></div>
                    <hr style="border: 0; border-top: 1px solid #ddd; margin: 15px 0;">
                    <p style="margin:0; font-size: 14px; color: #555; line-height: 1.5;"><b>Mô tả:</b> <br><span id="detailDesc"></span></p>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL QUẢN LÝ BIẾN THỂ -->
    <c:forEach var="entry" items="${groupedProducts}" varStatus="loop">
        <c:set var="baseName" value="${entry.key}" />
        <c:set var="variants" value="${entry.value}" />
        <c:set var="firstVariant" value="${variants[0]}" />
        
        <div id="variantsModal_${loop.index}" class="modal">
            <div class="modal-content" style="width: 800px;">
                <div class="modal-header">
                    <h3 style="margin:0;"><i class="fa-solid fa-list-ul"></i> Danh sách Biến thể: ${baseName}</h3>
                    <span class="close-btn" onclick="closeSpecificModal('variantsModal_${loop.index}')">&times;</span>
                </div>
                <div class="modal-body">
                    <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                        <!-- Nút Thêm Phân Loại -->
                        <button class="btn-gradient btn-gradient-success" style="margin-bottom: 15px;" 
                                onclick="closeSpecificModal('variantsModal_${loop.index}'); openAddSingleVariantModal(${firstVariant.maDM}, '${baseName}', ${firstVariant.giaNhap}, ${firstVariant.giaBan}, '${firstVariant.moTa}', '${firstVariant.anh}', '${firstVariant.tenDM}')">
                            <i class="fa-solid fa-plus"></i> Bổ sung thêm Màu/Size mới
                        </button>
                    </c:if>
                    <table class="variant-table">
                        <thead>
                            <tr>
                                <th>Mã SKU</th>
                                <th>Chi tiết Màu / Size</th>
                                <th style="text-align: center;">Tồn Kho</th>
                                <th style="text-align: center;">Bán / Khóa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="v" items="${variants}">
                                <c:set var="variantInfo" value="${fn:replace(v.tenSP, baseName, '')}" />
                                <c:set var="variantInfo" value="${fn:replace(variantInfo, ' - ', ' ')}" />
                                <c:if test="${empty variantInfo}"><c:set var="variantInfo" value="(Bản tiêu chuẩn)" /></c:if>
                                
                                <c:set var="prefix" value="SP" />
                                <c:set var="dm" value="${fn:toLowerCase(v.tenDM)}" />
                                <c:if test="${fn:contains(dm, 'áo') || fn:contains(dm, 'quần')}"><c:set var="prefix" value="QA" /></c:if>
                                <c:if test="${fn:contains(dm, 'giày') || fn:contains(dm, 'dép')}"><c:set var="prefix" value="GD" /></c:if>
                                <c:if test="${fn:contains(dm, 'phụ kiện') || fn:contains(dm, 'túi')}"><c:set var="prefix" value="PK" /></c:if>
                                <c:set var="displayId" value="${prefix}${String.format('%04d', v.maSP)}" />

                                <tr>
                                    <td><b>${displayId}</b></td>
                                    <td style="font-weight: bold; color: var(--primary);">${variantInfo}</td>
                                    <td style="text-align: center; font-weight: bold; color: ${v.soLuongTon == 0 ? 'red' : 'black'};">${v.soLuongTon}</td>
                                    <td style="text-align: center;">
                                        <!-- Nút KHÓA ĐỘC LẬP - Rất cần thiết cho SKU ngừng sản xuất -->
                                        <a href="${pageContext.request.contextPath}/product?action=toggleStatus&id=${v.maSP}&status=${v.trangThai}" 
                                           class="btn-gradient ${v.trangThai ? 'btn-gradient-success' : 'btn-gradient-danger'}" 
                                           style="padding: 4px 12px; font-size:11px;" title="Click để Bán/Khóa">
                                            <i class="fa-solid ${v.trangThai ? 'fa-unlock' : 'fa-lock'}"></i> ${v.trangThai ? 'Đang bán' : 'Bị Khóa'}
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </c:forEach>

    <!-- FORM DÙNG CHUNG: THÊM MỚI (NHIỀU BIẾN THỂ) VÀ SỬA CHUNG -->
    <div id="productModal" class="modal">
        <div class="modal-content" style="width: 600px;">
            <div class="modal-header">
                <h3 id="modalTitle"></h3>
                <span class="close-btn" onclick="closeSpecificModal('productModal')">&times;</span>
            </div>
            <div class="modal-body">
                <form id="productForm" action="${pageContext.request.contextPath}/product" method="post">
                    <input type="hidden" id="action" name="action" value="add">
                    <input type="hidden" id="maSPList" name="maSPList">
                    
                    <div class="form-group">
                        <label class="form-label">Chọn Danh mục <span style="color:red;">*</span></label>
                        <select id="maDM" name="maDM" class="form-control" required>
                            <option value="">-- Chọn --</option>
                            <c:forEach var="c" items="${categories}">
                                <option value="${c.maDM}">${c.tenDM}</option>
                            </c:forEach>
                        </select>
                    </div>
                    
                    <div class="form-group" id="nameGroup">
                        <label class="form-label" id="nameLabel">Tên sản phẩm gốc <span style="color:red;">*</span></label>
                        <input type="text" id="tenSP" name="tenSP" class="form-control" placeholder="Ví dụ: Áo Polo Basic">
                    </div>

                    <div id="variantGeneratorArea" style="border: 1px dashed var(--primary); padding: 15px; border-radius: 8px; margin-bottom: 15px; background: #f8f9fc;">
                        <h4 style="margin: 0 0 10px 0; color: var(--primary); font-size: 14px;"><i class="fa-solid fa-wand-magic-sparkles"></i> Sinh Biến thể nhanh</h4>
                        <div class="form-group">
                            <label class="form-label">Kiểu mặt hàng <span style="color:red;">*</span></label>
                            <select id="loaiMatHang" class="form-control" onchange="handleProductTypeChange(this)">
                                <option value="">-- Chọn Loại Hàng --</option>
                                <option value="quan_ao">Quần áo (S, M, L...)</option>
                                <option value="giay_dep">Giày dép (38, 39, 40...)</option>
                                <option value="khac">Phụ kiện (Không Size)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Thêm Màu sắc</label>
                            <div style="display: flex; gap: 5px;">
                                <input type="text" id="colorInput" class="form-control" placeholder="Gõ tên màu, nhấn Enter">
                                <button type="button" class="btn-gradient btn-gradient-success" onclick="addColor()"><i class="fa-solid fa-plus"></i></button>
                            </div>
                            <div id="colorContainer" class="color-tags-container"></div>
                        </div>
                        <div class="form-group" id="sizeGroup" style="display: none;">
                            <label class="form-label">Chọn Size áp dụng</label>
                            <div class="size-checkboxes" id="sizeCheckboxesContainer"></div>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 15px;">
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Giá nhập kho (₫) <span style="color:red;">*</span></label>
                            <input type="number" id="giaNhap" name="giaNhap" class="form-control" min="1" required>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label class="form-label">Giá bán niêm yết (₫) <span style="color:red;">*</span></label>
                            <input type="number" id="giaBan" name="giaBan" class="form-control" min="1" required>
                        </div>
                    </div>
                    <div class="form-group"><label class="form-label">Link Hình ảnh (URL)</label><input type="text" id="anh" name="anh" class="form-control" placeholder="https://..."></div>
                    <div class="form-group"><label class="form-label">Mô tả chi tiết</label><textarea id="moTa" name="moTa" class="form-control" rows="2"></textarea></div>
                    
                    <button type="submit" class="btn-gradient btn-gradient-primary" style="width: 100%; justify-content: center; padding: 12px; margin-top: 10px; font-size: 15px;">
                        <i class="fa-solid fa-floppy-disk"></i> <span id="submitBtnText">LƯU LẠI</span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const formatMoney = (amount) => amount.toLocaleString('vi-VN') + ' ₫';

        // TĂNG SỐ LƯỢNG HIỂN THỊ LÊN 7 SẢN PHẨM / TRANG ĐỂ LẤP ĐẦY KHOẢNG TRỐNG
        const rowsPerPage = 6; 
        const tableRows = document.querySelectorAll('.product-row');
        const paginationContainer = document.getElementById('pagination');
        let totalPages = Math.ceil(tableRows.length / rowsPerPage);

        function showPage(page) {
            tableRows.forEach((row, index) => {
                row.style.display = (index >= (page - 1) * rowsPerPage && index < page * rowsPerPage) ? '' : 'none';
            });
            document.querySelectorAll('.page-btn').forEach(btn => btn.classList.remove('active'));
            document.getElementById('btnPage_' + page).classList.add('active');
        }

        if (totalPages > 1) {
            for (let i = 1; i <= totalPages; i++) {
                const btn = document.createElement('button');
                btn.className = 'page-btn'; btn.id = 'btnPage_' + i; btn.innerText = i;
                btn.onclick = () => showPage(i);
                paginationContainer.appendChild(btn);
            }
            showPage(1); 
        }

        function openVariantsModal(modalId) { document.getElementById(modalId).style.display = 'flex'; }
        function closeSpecificModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

        function openDetailModal(baseName, catName, importPrice, exportPrice, desc, img, variantCount, stockCount) {
            document.getElementById('detailName').innerText = baseName;
            document.getElementById('detailCat').innerText = catName;
            document.getElementById('detailDesc').innerText = (desc !== 'null' && desc !== '') ? desc : 'Không có mô tả';
            document.getElementById('detailImport').innerText = formatMoney(importPrice);
            document.getElementById('detailExport').innerText = formatMoney(exportPrice);
            document.getElementById('detailVariants').innerText = variantCount + " mẫu";
            document.getElementById('detailStock').innerText = stockCount + " cái";
            
            if(img && img !== 'null' && img !== '') {
                document.getElementById('detailImg').src = img;
                document.getElementById('detailImg').style.display = 'block';
                document.getElementById('detailImgPlaceholder').style.display = 'none';
            } else {
                document.getElementById('detailImg').style.display = 'none';
                document.getElementById('detailImgPlaceholder').style.display = 'flex';
            }
            document.getElementById('detailModal').style.display = 'flex';
        }

        // --- CÁC HÀM MỞ FORM THÊM/SỬA ĐÃ ĐƯỢC XỬ LÝ KHÓA CỨNG FIELD ---
        function resetFormFields() {
            const fields = ['maDM', 'loaiMatHang', 'tenSP', 'giaNhap', 'giaBan', 'moTa', 'anh'];
            fields.forEach(f => {
                let el = document.getElementById(f);
                if(el) {
                    el.classList.remove('locked-input');
                    el.readOnly = false;
                    el.value = '';
                }
            });
            document.getElementById('nameGroup').style.display = 'block';
            document.getElementById('variantGeneratorArea').style.display = 'block';
            document.getElementById('colorContainer').innerHTML = ''; 
            document.getElementById('sizeGroup').style.display = 'none';
        }

        function openAddModal() {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Tạo Mẫu Sản Phẩm Mới';
            document.getElementById('action').value = 'add';
            resetFormFields();
            document.getElementById('submitBtnText').innerText = 'TẠO MẪU & SINH BIẾN THỂ';
            document.getElementById('productModal').style.display = 'flex';
        }

        // LOGIC CHUẨN: KHÓA CỨNG TOÀN BỘ KHI THÊM PHÂN LOẠI
        function openAddSingleVariantModal(maDM, baseName, giaNhap, giaBan, moTa, anh, catName) {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-plus"></i> Thêm Phân Loại Cho: ' + baseName;
            document.getElementById('action').value = 'add';
            resetFormFields();
            
            // 1. Khóa cứng Select Danh mục (Dùng Class CSS pointer-events: none)
            let dm = document.getElementById('maDM');
            dm.value = maDM; dm.classList.add('locked-input');
            
            // 2. Khóa cứng các Input text
            const textInputs = ['tenSP', 'giaNhap', 'giaBan', 'moTa', 'anh'];
            const values = [baseName, giaNhap, giaBan, (moTa !== 'null' ? moTa : ''), (anh !== 'null' ? anh : '')];
            textInputs.forEach((f, index) => {
                let el = document.getElementById(f);
                el.value = values[index];
                el.classList.add('locked-input');
                el.readOnly = true;
            });

            // 3. Tự nhận diện Kiểu mặt hàng và Khóa cứng luôn để chống lỗi data
            let pType = 'khac';
            let cn = catName.toLowerCase();
            if (cn.includes('áo') || cn.includes('quần')) pType = 'quan_ao';
            else if (cn.includes('giày') || cn.includes('dép')) pType = 'giay_dep';
            
            let lmh = document.getElementById('loaiMatHang');
            lmh.value = pType; 
            handleProductTypeChange(lmh); // Gọi hàm render checkbox size
            lmh.classList.add('locked-input');

            document.getElementById('submitBtnText').innerText = 'THÊM PHÂN LOẠI MỚI';
            document.getElementById('productModal').style.display = 'flex';
        }

        function openEditGroupModal(baseName, maDM, giaNhap, giaBan, moTa, anh, idListStr) {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-pen"></i> Sửa chung tất cả: ' + baseName;
            document.getElementById('action').value = 'editGroup';
            document.getElementById('maSPList').value = idListStr;
            resetFormFields();

            document.getElementById('maDM').value = maDM;
            document.getElementById('giaNhap').value = giaNhap; document.getElementById('giaBan').value = giaBan;
            document.getElementById('moTa').value = (moTa !== 'null' && moTa !== '') ? moTa : '';
            document.getElementById('anh').value = (anh !== 'null' && anh !== '') ? anh : '';
            
            document.getElementById('nameGroup').style.display = 'none'; document.getElementById('tenSP').required = false; 
            document.getElementById('variantGeneratorArea').style.display = 'none';
            document.getElementById('submitBtnText').innerText = 'LƯU ÁP DỤNG TOÀN BỘ';
            document.getElementById('productModal').style.display = 'flex';
        }

        function closeModal(modalId) { document.getElementById(modalId).style.display = 'none'; }

        // LOGIC CHECKBOX MÀU/SIZE
        const sizeGroups = { quan_ao: ['XS', 'S', 'M', 'L', 'XL', 'XXL'], giay_dep: ['36', '37', '38', '39', '40', '41', '42', '43'] };
        function handleProductTypeChange(selectElement) {
            const type = selectElement.value;
            const sizeContainer = document.getElementById('sizeCheckboxesContainer');
            const sizeGroupDiv = document.getElementById('sizeGroup');
            sizeContainer.innerHTML = '';
            let sizesToRender = sizeGroups[type];
            if (sizesToRender) {
                sizeGroupDiv.style.display = 'block';
                sizesToRender.forEach(size => {
                    const cb = document.createElement('label');
                    cb.style.cssText = "display:flex; align-items:center; gap:5px; font-weight:bold; cursor:pointer;";
                    cb.innerHTML = `<input type="checkbox" name="sizes[]" value="`+size+`" checked> ` + size;
                    sizeContainer.appendChild(cb);
                });
            } else { sizeGroupDiv.style.display = 'none'; }
        }

        function addColor() {
            const input = document.getElementById('colorInput');
            const color = input.value.trim();
            if(color) {
                const container = document.getElementById('colorContainer');
                const tag = document.createElement('div'); tag.className = 'color-tag';
                tag.innerHTML = color + ` <input type="hidden" name="colors[]" value="`+color+`"> <i class="fa-solid fa-xmark" onclick="this.parentElement.remove()"></i>`;
                container.appendChild(tag); input.value = '';
            }
        }
        document.getElementById('colorInput').addEventListener('keypress', function(e) { if (e.key === 'Enter') { e.preventDefault(); addColor(); }});
        window.onclick = function(event) { if (event.target.classList.contains('modal')) { event.target.style.display = 'none'; } }
    </script>
</body>
</html>