<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thanh Toán Thành Công</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content" style="display: flex; justify-content: center; align-items: center; flex-direction: column; padding-top: 50px;">
            <div style="background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; max-width: 500px;">
                <h1 style="color: var(--success); margin-bottom: 20px;">Thanh Toán Thành Công!</h1>
                <p style="font-size: 16px; margin-bottom: 10px;">Đơn hàng <b>#${param.orderId}</b> đã được lưu vào hệ thống và kho hàng đã được trừ thành công.</p>
                <p style="color: gray; margin-bottom: 30px;">(Bạn có thể xem lại chi tiết và in hóa đơn trong mục Quản lý Đơn Hàng)</p>
                
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <a href="${pageContext.request.contextPath}/sale" class="btn btn-primary">Tạo đơn mới</a>
                    <a href="${pageContext.request.contextPath}/order" class="btn btn-secondary">Xem Đơn hàng</a>
                </div>
            </div>
        </div>
        
        <jsp:include page="../layout/footer.jsp" />
    </div>
</body>
</html>