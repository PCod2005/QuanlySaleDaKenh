<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Bán Hàng - Hệ Thống</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .pos-container { display: flex; gap: 20px; height: calc(100vh - 110px); }
        .pos-left { flex: 6.5; display: flex; flex-direction: column; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .pos-right { flex: 3.5; display: flex; flex-direction: column; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); overflow-y: auto;}
        
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 15px; overflow-y: auto; flex-grow: 1; margin-top: 15px; padding-right: 5px;}
        .product-card { border: 1px solid #e3e6f0; border-radius: 10px; text-align: center; cursor: pointer; transition: all 0.2s; background: #fff; overflow: hidden; display: flex; flex-direction: column;}
        .product-card:hover { border-color: #4e73df; transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
        .product-img { width: 100%; height: 130px; object-fit: cover; background: #f8f9fc; }
        .product-info { padding: 12px; display: flex; flex-direction: column; flex-grow: 1; justify-content: space-between; text-align: left;}
        .product-name { font-weight: 700; font-size: 13px; color: #3a3b45; margin-bottom: 5px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; height: 34px;}
        .product-price { font-weight: 800; color: #e74a3b; font-size: 14px; }
        .product-stock { font-size: 11px; color: #858796; margin-top: 4px; }

        .cart-table-wrapper { flex-grow: 1; overflow-y: auto; border: 1px solid #f1f3f5; border-radius: 8px; margin-bottom: 15px; max-height: 250px;}
        .cart-table { width: 100%; border-collapse: collapse; }
        .cart-table th { background: #f8f9fc; color: #4e73df; padding: 10px; font-size: 12px; text-transform: uppercase; position: sticky; top: 0; z-index: 1;}
        .cart-table td { padding: 10px; border-bottom: 1px solid #f1f3f5; vertical-align: middle; font-size: 13px; }
        .cart-qty-input { width: 45px; padding: 4px; text-align: center; border: 1px solid #d1d3e2; border-radius: 4px; font-weight: bold;}
        
        .checkout-section { background: #f8f9fc; padding: 15px; border-radius: 10px; border: 1px solid #e3e6f0; }
        .checkout-row { display: flex; justify-content: space-between; margin-bottom: 10px; align-items: center; }
        .checkout-total { font-size: 20px; font-weight: 900; color: #e74a3b; }
        .btn-action { padding: 4px 8px; font-size: 11px; border-radius: 4px;}

        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; }
        .modal-content { background: #fff; border-radius: 12px; width: 450px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; }
        .modal-header { background: linear-gradient(45deg, #4e73df, #224abe); color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 22px; cursor: pointer; }
        .modal-body { padding: 20px; overflow-y: auto; }
        
        .variant-group { margin-bottom: 15px; }
        .variant-label { font-weight: bold; font-size: 13px; margin-bottom: 8px; color: #3a3b45; display: block;}
        .variant-options { display: flex; flex-wrap: wrap; gap: 8px; }
        .variant-chip { padding: 6px 14px; border: 1px solid #d1d3e2; border-radius: 6px; font-size: 13px; cursor: pointer; background: #fff; transition: 0.2s; font-weight: 600;}
        .variant-chip:hover { border-color: #4e73df; color: #4e73df; }
        .variant-chip.selected { background: #4e73df; color: #fff; border-color: #4e73df; }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        
        <div class="content">
            <c:if test="${not empty sessionScope.errorMsg}">
                <div style="background: #fdeaea; color: #e74a3b; padding: 12px; margin-bottom: 15px; border-radius: 8px; font-weight: bold; border-left: 5px solid #e74a3b;">
                    <i class="fa-solid fa-triangle-exclamation"></i> ${sessionScope.errorMsg}
                </div>
                <c:remove var="errorMsg" scope="session"/>
            </c:if>

            <div class="pos-container">
                <!-- VẾ TRÁI: TÌM KIẾM & DANH SÁCH SẢN PHẨM GỐC -->
                <div class="pos-left">
                    <form action="${pageContext.request.contextPath}/sale" method="get" style="display: flex; gap: 10px;">
                        <input type="text" name="keyword" class="form-control" placeholder="Tìm kiếm sản phẩm (Tên)..." value="${keyword}" style="border-radius: 50px; padding-left: 20px;">
                        <button type="submit" class="btn btn-primary" style="border-radius: 50px; padding: 0 20px;"><i class="fa-solid fa-magnifying-glass"></i> Tìm</button>
                        <a href="${pageContext.request.contextPath}/sale" class="btn btn-secondary" style="border-radius: 50px; padding: 0 15px; display:inline-flex; align-items:center;">Tất cả</a>
                    </form>
                    
                    <div class="product-grid">
                        <c:forEach var="entry" items="${groupedProducts}">
                            <c:set var="baseName" value="${entry.key}" />
                            <c:set var="variants" value="${entry.value}" />
                            <c:set var="firstV" value="${variants[0]}" />
                            
                            <c:set var="totalStock" value="0" />
                            <c:forEach var="v" items="${variants}"><c:set var="totalStock" value="${totalStock + v.soLuongTon}" /></c:forEach>
                            
                            <!-- Đóng gói dữ liệu biến thể trực tiếp vào thẻ HTML qua cú pháp JSON chuẩn -->
                            <div class="product-card" onclick='openVariantModal("${baseName}", [
                                <c:forEach var="v" items="${variants}" varStatus="status">
                                    {"maSP": ${v.maSP}, "tenSP": "${v.tenSP}", "giaBan": ${v.giaBan}, "soLuongTon": ${v.soLuongTon}, "anh": "${v.anh}"}<c:if test="${!status.last}">,</c:if>
                                </c:forEach>
                            ])'>
                                <img src="${firstV.anh != null ? firstV.anh : 'https://via.placeholder.com/150'}" class="product-img" alt="Product">
                                <div class="product-info">
                                    <div class="product-name" title="${baseName}">${baseName}</div>
                                    <div>
                                        <div class="product-price"><fmt:formatNumber value="${firstV.giaBan}" type="currency" currencySymbol="₫" maxFractionDigits="0"/></div>
                                        <div class="product-stock"><i class="fa-solid fa-boxes-stacked"></i> Kho: ${totalStock}</div>
                                    </div>
                                </div>
                            </div>
                        </c:forEach>
                        <c:if test="${empty groupedProducts}">
                            <div style="grid-column: 1 / -1; text-align: center; padding: 50px; color: gray;">
                                <i class="fa-solid fa-box-open fa-3x" style="color: #ccc; margin-bottom: 10px;"></i><br>Không tìm thấy sản phẩm nào.
                            </div>
                        </c:if>
                    </div>
                </div>
                
                <!-- VẾ PHẢI: GIỎ HÀNG & THANH TOÁN -->
                <div class="pos-right">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <h4 style="color: var(--dark); margin:0; font-weight: 800;"><i class="fa-solid fa-cart-shopping" style="color: #4e73df;"></i> Giỏ Hàng</h4>
                        <form action="${pageContext.request.contextPath}/cart" method="post" style="display: inline;">
                            <input type="hidden" name="action" value="clear">
                            <button type="submit" class="btn btn-danger btn-action" onclick="return confirm('Xóa toàn bộ giỏ hàng?');"><i class="fa-solid fa-trash"></i> Hủy giỏ</button>
                        </form>
                    </div>
                    
                    <div class="cart-table-wrapper">
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th>Sản phẩm</th>
                                    <th style="width: 50px; text-align: center;">SL</th>
                                    <th style="text-align: right;">Thành tiền</th>
                                    <th style="width: 30px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="item" items="${sessionScope.cart.items}">
                                    <tr>
                                        <td><div style="font-weight: bold; font-size: 12px; color: #3a3b45;" title="${item.tenSP}">${item.tenSP}</div></td>
                                        <td style="text-align: center;">
                                            <form action="${pageContext.request.contextPath}/cart" method="post">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="maSP" value="${item.maSP}">
                                                <input type="number" name="soLuong" value="${item.soLuong}" min="1" max="${item.maxStock}" class="cart-qty-input" onchange="this.form.submit()">
                                            </form>
                                        </td>
                                        <td style="color: #e74a3b; font-weight: bold; text-align: right;">
                                            <fmt:formatNumber value="${item.thanhTien}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                        </td>
                                        <td style="text-align: center;">
                                            <form action="${pageContext.request.contextPath}/cart" method="post">
                                                <input type="hidden" name="action" value="remove">
                                                <input type="hidden" name="maSP" value="${item.maSP}">
                                                <button type="submit" class="btn btn-secondary btn-action" style="background: #e74a3b; color:white; border:none;"><i class="fa-solid fa-xmark"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                </c:forEach>
                                <c:if test="${empty sessionScope.cart.items}">
                                    <tr><td colspan="4" style="text-align: center; color: gray; padding: 40px;"><i class="fa-solid fa-basket-shopping fa-2x" style="color:#ddd; margin-bottom:8px;"></i><br>Giỏ hàng trống</td></tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- FORM THANH TOÁN -->
                    <div class="checkout-section">
                        <form action="${pageContext.request.contextPath}/cart" method="post">
                            <input type="hidden" name="action" value="checkout">
                            
                            <div class="checkout-row">
                                <span style="font-size: 13px; font-weight:600;">Kênh bán:</span>
                                <select name="kenhBan" id="kenhBanSelect" class="form-control" style="width: 65%; padding: 6px; font-size: 13px;" onchange="toggleAddressField()">
                                    <c:forEach var="c" items="${channels}">
                                        <option value="${c}">${c}</option>
                                    </c:forEach>
                                </select>
                            </div>
                            <div class="checkout-row">
                                <span style="font-size: 13px; font-weight:600;">Điện thoại <span style="color:red;">*</span>:</span>
                                <input type="text" name="soDienThoaiKhachHang" placeholder="SĐT khách hàng (Cốt lõi)" class="form-control" style="width: 65%; font-size: 13px; padding: 6px;" required>
                            </div>
                            <div class="checkout-row">
                                <span style="font-size: 13px; font-weight:600;">Khách hàng:</span>
                                <input type="text" name="tenKhachHang" placeholder="Tên KH (Bỏ trống = Khách lẻ)" class="form-control" style="width: 65%; font-size: 13px; padding: 6px;">
                            </div>
                            
                            <div class="checkout-row" id="addressRow">
                                <span style="font-size: 13px; font-weight:600;">Địa chỉ giao:</span>
                                <input type="text" name="diaChiKhachHang" placeholder="Địa chỉ nhận hàng" class="form-control" style="width: 65%; font-size: 13px; padding: 6px;">
                            </div>
                            
                            <div class="checkout-row">
                                <span style="font-size: 13px; font-weight:600;">Thanh toán:</span>
                                <select name="maPTTT" id="maPTTT" class="form-control" style="width: 65%; padding: 6px; font-size: 13px;" onchange="toggleCashInput()">
                                    <option value="1">Tiền mặt</option>
                                    <option value="2">Chuyển khoản</option>
                                </select>
                            </div>
                            
                            <div class="checkout-row" id="cashInputRow">
                                <span style="font-size: 13px; font-weight:600;">Khách đưa:</span>
                                <input type="number" name="tienKhachDua" id="tienKhachDua" class="form-control" style="width: 65%; font-size: 13px; padding: 6px;" min="0" onkeyup="calculateChange()">
                            </div>
                            <div class="checkout-row" id="changeRow">
                                <span style="font-size: 13px; font-weight:600;">Tiền thừa:</span>
                                <span id="tienThuaDisplay" style="font-weight: 900; color: #1cc88a; font-size: 15px;">0 ₫</span>
                            </div>
                            
                            <hr style="border: 0; border-top: 2px dashed #d1d3e2; margin: 12px 0;">
                            
                            <div class="checkout-row" style="margin-bottom: 15px;">
                                <span style="font-size: 16px; font-weight: 800;">TỔNG CỘNG:</span>
                                <span class="checkout-total">
                                    <fmt:formatNumber value="${sessionScope.cart != null ? sessionScope.cart.total : 0}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                </span>
                                <input type="hidden" id="cartTotal" value="${sessionScope.cart != null ? sessionScope.cart.total : 0}">
                            </div>
                            
                            <button type="submit" class="btn btn-success" style="width: 100%; font-size: 15px; font-weight: 800; padding: 12px; border-radius: 50px;" 
                                    ${empty sessionScope.cart.items ? 'disabled' : ''}>
                                <i class="fa-solid fa-bag-shopping"></i> THANH TOÁN NGAY
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- MODAL CHỌN PHÂN LOẠI -->
    <div id="variantModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalProductName" style="margin:0; font-size:16px;">Chọn phân loại</h3>
                <span class="close-btn" onclick="closeVariantModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div style="display: flex; gap: 15px; margin-bottom: 20px; align-items: center;">
                    <img id="modalProductImg" src="" style="width: 70px; height: 70px; border-radius: 8px; object-fit: cover; border: 1px solid #ddd;">
                    <div>
                        <div id="modalProductPrice" style="color: #e74a3b; font-size: 18px; font-weight: 900;">0 ₫</div>
                        <div id="modalProductStock" style="font-size: 12px; color: gray; margin-top: 4px;">Kho: 0</div>
                    </div>
                </div>

                <div class="variant-group">
                    <span class="variant-label">Màu sắc:</span>
                    <div id="colorOptions" class="variant-options"></div>
                </div>

                <div class="variant-group">
                    <span class="variant-label">Kích thước (Size):</span>
                    <div id="sizeOptions" class="variant-options"></div>
                </div>

                <button type="button" id="addToCartBtn" class="btn btn-primary" style="width: 100%; padding: 12px; font-weight: 800; border-radius: 50px; margin-top: 15px;" disabled onclick="submitAddToCart()">
                    THÊM VÀO GIỎ HÀNG
                </button>
            </div>
        </div>
    </div>

    <form id="addForm" action="${pageContext.request.contextPath}/cart" method="post" style="display: none;">
        <input type="hidden" name="action" value="add">
        <input type="hidden" id="selectedMaSP" name="maSP">
    </form>

    <script>
        let currentVariants = [];
        let selectedColor = null;
        let selectedSize = null;
        let matchedVariant = null;

        function openVariantModal(baseName, variants) {
            currentVariants = variants;
            selectedColor = null;
            selectedSize = null;
            matchedVariant = null;

            document.getElementById('modalProductName').innerText = baseName;
            document.getElementById('modalProductImg').src = variants[0].anh ? variants[0].anh : 'https://via.placeholder.com/150';
            document.getElementById('modalProductPrice').innerText = variants[0].giaBan.toLocaleString('vi-VN') + ' ₫';
            document.getElementById('modalProductStock').innerText = 'Kho: ' + variants.reduce((sum, v) => sum + v.soLuongTon, 0);
            
            document.getElementById('addToCartBtn').disabled = true;

            let colors = [...new Set(variants.map(v => extractColor(v.tenSP, baseName)))];
            let colorContainer = document.getElementById('colorOptions');
            colorContainer.innerHTML = '';
            
            colors.forEach(color => {
                let chip = document.createElement('div');
                chip.className = 'variant-chip';
                chip.innerText = color;
                chip.onclick = () => selectColor(color, chip);
                colorContainer.appendChild(chip);
            });

            let sizes = [...new Set(variants.map(v => extractSize(v.tenSP)))];
            let sizeContainer = document.getElementById('sizeOptions');
            sizeContainer.innerHTML = '';
            
            sizes.forEach(size => {
                let chip = document.createElement('div');
                chip.className = 'variant-chip';
                chip.innerText = size;
                chip.onclick = () => selectSize(size, chip);
                sizeContainer.appendChild(chip);
            });

            document.getElementById('variantModal').style.display = 'flex';
        }

        function extractColor(fullName, baseName) {
            let remain = fullName.replace(baseName, '').replace(/^[\s\-]+/, '');
            let parts = remain.split(' - ');
            return parts[0] ? parts[0].trim() : 'Mặc định';
        }

        function extractSize(fullName) {
            if (fullName.includes('Size ')) {
                return fullName.substring(fullName.indexOf('Size ') + 5).trim();
            }
            return 'Freesize';
        }

        function selectColor(color, element) {
            document.querySelectorAll('#colorOptions .variant-chip').forEach(c => c.classList.remove('selected'));
            element.classList.add('selected');
            selectedColor = color;
            checkMatch();
        }

        function selectSize(size, element) {
            document.querySelectorAll('#sizeOptions .variant-chip').forEach(c => c.classList.remove('selected'));
            element.classList.add('selected');
            selectedSize = size;
            checkMatch();
        }

        function checkMatch() {
            if (selectedColor && selectedSize) {
                matchedVariant = currentVariants.find(v => v.tenSP.includes(selectedColor) && v.tenSP.includes(selectedSize));
                let btn = document.getElementById('addToCartBtn');
                if (matchedVariant && matchedVariant.soLuongTon > 0) {
                    btn.disabled = false;
                    document.getElementById('modalProductStock').innerText = 'Kho còn: ' + matchedVariant.soLuongTon;
                    document.getElementById('modalProductPrice').innerText = matchedVariant.giaBan.toLocaleString('vi-VN') + ' ₫';
                } else {
                    btn.disabled = true;
                    document.getElementById('modalProductStock').innerText = 'Hết hàng hoặc phân loại này không tồn tại!';
                }
            }
        }

        function submitAddToCart() {
            if (matchedVariant) {
                document.getElementById('selectedMaSP').value = matchedVariant.maSP;
                document.getElementById('addForm').submit();
            }
        }

        function closeVariantModal() {
            document.getElementById('variantModal').style.display = 'none';
        }

        function toggleAddressField() {
            let channel = document.getElementById('kenhBanSelect').value;
            let addressRow = document.getElementById('addressRow');
            if (channel === 'Tại cửa hàng') {
                addressRow.style.display = 'none';
            } else {
                addressRow.style.display = 'flex';
            }
        }
        window.onload = toggleAddressField;

        function toggleCashInput() {
            var method = document.getElementById('maPTTT').value;
            var cashRow = document.getElementById('cashInputRow');
            var changeRow = document.getElementById('changeRow');
            if (method == '1') { 
                cashRow.style.display = 'flex';
                changeRow.style.display = 'flex';
            } else { 
                cashRow.style.display = 'none';
                changeRow.style.display = 'none';
            }
        }

        function calculateChange() {
            var total = parseFloat(document.getElementById('cartTotal').value) || 0;
            var received = parseFloat(document.getElementById('tienKhachDua').value) || 0;
            var change = received - total;
            document.getElementById('tienThuaDisplay').innerText = (change > 0 ? change.toLocaleString('vi-VN') : 0) + ' ₫';
        }
    </script>
</body>
</html>