<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập hệ thống - FASHION POS</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body, html { height: 100%; margin: 0; font-family: 'Nunito', sans-serif; background-color: #f8f9fc; }
        .login-container { display: flex; height: 100vh; width: 100vw; overflow: hidden; }
        
        /* CỘT TRÁI - HÌNH ẢNH BANNER */
        .login-banner {
            flex: 6;
            background: linear-gradient(rgba(78, 115, 223, 0.8), rgba(54, 185, 204, 0.8)), 
                        url('https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2070&auto=format&fit=crop') center/cover;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            padding: 40px;
            text-align: center;
        }
        .login-banner h1 { font-size: 45px; font-weight: 900; margin-bottom: 10px; letter-spacing: 2px; }
        .login-banner p { font-size: 18px; font-weight: 300; max-width: 500px; line-height: 1.6; }

        /* CỘT PHẢI - FORM ĐĂNG NHẬP */
        .login-form-wrapper {
            flex: 4;
            background: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 0 8%;
            box-shadow: -10px 0 30px rgba(0,0,0,0.05);
            z-index: 10;
        }
        .login-header { margin-bottom: 40px; text-align: center; }
        .login-header h2 { color: #3a3b45; font-size: 28px; font-weight: 800; margin-bottom: 5px; }
        .login-header p { color: #858796; font-size: 15px; margin: 0; }

        .form-group { margin-bottom: 25px; position: relative; }
        .form-control {
            width: 100%; padding: 15px 20px 15px 45px; font-size: 15px; border-radius: 50px;
            border: 1px solid #d1d3e2; outline: none; transition: 0.3s; box-sizing: border-box;
            background-color: #f8f9fc;
        }
        .form-control:focus { border-color: #4e73df; background-color: #fff; box-shadow: 0 0 0 3px rgba(78,115,223,0.1); }
        .form-group i { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: #b7b9cc; font-size: 18px; }

        .btn-login {
            width: 100%; padding: 15px; border-radius: 50px; border: none; font-size: 16px; font-weight: 700;
            color: white; background: linear-gradient(45deg, #4e73df, #224abe); cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s; margin-top: 10px;
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(78,115,223,0.4); }

        .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; font-weight: 600; text-align: center; }
        .alert-error { background-color: #fdeaea; color: #e74a3b; border: 1px solid #e74a3b; }
        .alert-success { background-color: #e3fbed; color: #1cc88a; border: 1px solid #1cc88a; }
        
        .footer-text { text-align: center; margin-top: 40px; font-size: 13px; color: #858796; }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Cột Banner Trực Quan -->
        <div class="login-banner">
            <i class="fa-solid fa-store" style="font-size: 80px; margin-bottom: 20px; text-shadow: 2px 2px 10px rgba(0,0,0,0.2);"></i>
            <h1>FASHION POS</h1>
            <p>Hệ thống Quản lý Bán lẻ Tiên tiến. Nơi tối ưu hóa quy trình vận hành và kiểm soát tồn kho thông minh.</p>
        </div>

        <!-- Cột Form Đăng Nhập -->
        <div class="login-form-wrapper">
            <div class="login-header">
                <h2>Chào mừng trở lại!</h2>
                <p>Vui lòng đăng nhập để tiếp tục</p>
            </div>

            <c:if test="${not empty errorMsg}">
                <div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation"></i> ${errorMsg}</div>
                <c:remove var="errorMsg" scope="session"/>
            </c:if>
            <c:if test="${not empty successMsg}">
                <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> ${successMsg}</div>
                <c:remove var="successMsg" scope="session"/>
            </c:if>

            <form action="${pageContext.request.contextPath}/login" method="post">
                <div class="form-group">
                    <i class="fa-solid fa-user"></i>
                    <input type="text" name="username" class="form-control" placeholder="Tên đăng nhập" required autocomplete="off">
                </div>
                
                <div class="form-group">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="password" class="form-control" placeholder="Mật khẩu" required>
                </div>
                
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; padding: 0 10px;">
                    <label style="font-size: 13px; color: #858796; cursor: pointer; display: flex; align-items: center;">
                        <input type="checkbox" style="margin-right: 8px;"> Ghi nhớ đăng nhập
                    </label>
                    <a href="#" style="font-size: 13px; color: #4e73df; text-decoration: none; font-weight: 600;">Quên mật khẩu?</a>
                </div>

                <button type="submit" class="btn-login">ĐĂNG NHẬP <i class="fa-solid fa-arrow-right-to-bracket" style="margin-left: 5px;"></i></button>
            </form>
            
            <div class="footer-text">
                &copy; 2026 Fashion POS System. All rights reserved.
            </div>
        </div>
    </div>
</body>
</html>