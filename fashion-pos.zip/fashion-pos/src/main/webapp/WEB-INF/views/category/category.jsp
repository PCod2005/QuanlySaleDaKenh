<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Danh mục - POS</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .table-custom { border-collapse: separate; border-spacing: 0 10px; margin-top: 10px; width: 100%; }
        .table-custom th { background: transparent; color: var(--dark); text-transform: uppercase; font-size: 13px; border: none; padding-bottom: 5px; }
        .table-custom td { background: #fff; padding: 15px; vertical-align: middle; border-top: 1px solid #f1f3f5; border-bottom: 1px solid #f1f3f5; }
        .table-custom td:first-child { border-left: 1px solid #f1f3f5; border-radius: 8px 0 0 8px; }
        .table-custom td:last-child { border-right: 1px solid #f1f3f5; border-radius: 0 8px 8px 0; }
        .table-custom tr:hover td { box-shadow: 0 4px 15px rgba(0,0,0,0.05); transform: translateY(-1px); }

        .btn-gradient { border: none; border-radius: 6px; padding: 8px 14px; color: white; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; font-size: 12px; transition: 0.3s; }
        .btn-gradient-primary { background: linear-gradient(45deg, #4e73df, #224abe); }
        .btn-gradient-info { background: linear-gradient(45deg, #36b9cc, #1e8a99); }
        .btn-gradient-warning { background: linear-gradient(45deg, #f6c23e, #d49a15); color: #fff; }
        .btn-gradient-danger { background: linear-gradient(45deg, #e74a3b, #be2617); }
        .btn-gradient:hover:not(.btn-disabled) { transform: translateY(-2px); filter: brightness(1.1); }
        
        /* CSS cho nút Xóa bị mờ (Disabled) */
        .btn-disabled { opacity: 0.4; cursor: not-allowed !important; filter: grayscale(80%); }

        .status-pill { padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; text-align: center; min-width: 90px;}
        .status-active { background-color: #e3fbed; color: #1cc88a; border: 1px solid #1cc88a; }
        .status-inactive { background-color: #fdeaea; color: #e74a3b; border: 1px solid #e74a3b; }

        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(3px); align-items: center; justify-content: center; }
        .modal-content { background: #fff; border-radius: 12px; width: 500px; max-height: 85vh; display: flex; flex-direction: column; overflow: hidden; animation: slideDown 0.3s ease forwards; }
        /* Modal Chi tiết rộng hơn */
        .modal-large { width: 700px; } 
        
        .modal-header { background: linear-gradient(45deg, #4e73df, #36b9cc); color: white; padding: 18px 25px; display: flex; justify-content: space-between; align-items: center; }
        .close-btn { color: white; font-size: 24px; cursor: pointer; }
        .modal-body { padding: 25px; overflow-y: auto; }
        
        .header-divider { height: 3px; background: linear-gradient(90deg, #4e73df, #36b9cc, transparent); border: none; margin: 15px 0 20px 0; border-radius: 5px; width: 150px; }
        
        .product-list-table th, .product-list-table td { padding: 8px; border-bottom: 1px solid #eee; font-size: 13px; }
        .product-list-table th { color: var(--primary); }
    </style>
</head>
<body>
    <jsp:include page="../layout/sidebar.jsp" />
    <div class="main-wrapper">
        <jsp:include page="../layout/header.jsp" />
        <div class="content">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="color: var(--dark); font-size: 24px; margin: 0;"><i class="fa-solid fa-layer-group" style="color: #4e73df; margin-right: 10px;"></i>Danh Sách Danh Mục</h2>
                    <!-- Đường chỉ ngang mượt mà dưới Header -->
                    <hr class="header-divider">
                </div>
                <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                    <button class="btn-gradient btn-gradient-primary" onclick="openAddModal()">
                        <i class="fa-solid fa-plus"></i> Thêm Mới
                    </button>
                </c:if>
            </div>

            <table class="table table-custom">
                <thead>
                    <tr>
                        <th style="width: 80px;">Mã DM</th>
                        <th>Tên Danh Mục</th>
                        <th>Mô tả chi tiết</th>
                        <th style="text-align: center;">Số lượng SP</th>
                        <th style="text-align: center;">Trạng thái</th>
                        <th style="text-align: center;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="cat" items="${categories}">
                        <tr>
                            <td><b>#${cat.maDM}</b></td>
                            <td style="font-size: 15px; font-weight: 600; color: #4e73df;">${cat.tenDM}</td>
                            <td style="color: #666;">${empty cat.moTa ? '<i style="color:#aaa;">Không có mô tả</i>' : cat.moTa}</td>
                            
                            <td style="text-align: center;">
                                <span style="background: #f1f3f5; padding: 4px 10px; border-radius: 12px; font-weight: bold; color: ${cat.soLuongSanPham > 0 ? '#4e73df' : '#999'};">
                                    ${cat.soLuongSanPham}
                                </span>
                            </td>
                            
                            <td style="text-align: center;">
                                <span class="status-pill ${cat.trangThai ? 'status-active' : 'status-inactive'}">
                                    <i class="fa-solid ${cat.trangThai ? 'fa-check-circle' : 'fa-ban'}"></i> 
                                    ${cat.trangThai ? 'Hoạt động' : 'Đã khóa'}
                                </span>
                            </td>
                            
                            <td style="text-align: center; min-width: 250px;">
                                <!-- Nút Xem Chi Tiết (Ai cũng xem được) -->
                                <button class="btn-gradient btn-gradient-info" onclick="openDetailModal('detailModal_${cat.maDM}')">
                                    <i class="fa-solid fa-eye"></i> Chi tiết
                                </button>
                                
                                <c:if test="${sessionScope.currentUser.role == 'ADMIN'}">
                                    <button class="btn-gradient btn-gradient-warning" onclick="openEditModal(${cat.maDM}, '${cat.tenDM}', '${cat.moTa}', ${cat.trangThai})">
                                        <i class="fa-solid fa-pen-to-square"></i> Sửa
                                    </button>
                                    
                                    <!-- Logic Nút Xóa: Nếu có SP thì mờ đi và khóa click -->
                                    <c:choose>
                                        <c:when test="${cat.soLuongSanPham > 0}">
                                            <button class="btn-gradient btn-gradient-danger btn-disabled" title="Không thể xóa vì đang có sản phẩm">
                                                <i class="fa-solid fa-trash-can"></i> Xóa
                                            </button>
                                        </c:when>
                                        <c:otherwise>
                                            <a href="${pageContext.request.contextPath}/category?action=delete&id=${cat.maDM}" 
                                               class="btn-gradient btn-gradient-danger" 
                                               onclick="return confirm('Xóa danh mục [${cat.tenDM}]?');">
                                               <i class="fa-solid fa-trash-can"></i> Xóa
                                            </a>
                                        </c:otherwise>
                                    </c:choose>
                                </c:if>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty categories}">
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px; color: #999;">
                                <i class="fa-solid fa-folder-open fa-3x" style="margin-bottom: 15px; color: #ddd;"></i><br>
                                Chưa có dữ liệu danh mục nào!
                            </td>
                        </tr>
                    </c:if>
                </tbody>
            </table>
        </div>
        <jsp:include page="../layout/footer.jsp" />
    </div>

    <!-- KHẮC PHỤC LỖI HTML: Đưa toàn bộ Modal Chi Tiết ra bên ngoài table -->
    <c:forEach var="cat" items="${categories}">
        <div id="detailModal_${cat.maDM}" class="modal">
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h3 style="margin:0;"><i class="fa-solid fa-box-open"></i> Sản phẩm thuộc: ${cat.tenDM}</h3>
                    <span class="close-btn" onclick="closeSpecificModal('detailModal_${cat.maDM}')">&times;</span>
                </div>
                <div class="modal-body">
                    <c:if test="${cat.soLuongSanPham == 0}">
                        <div style="text-align: center; padding: 30px; color: #999;">
                            <i class="fa-solid fa-box-open fa-3x" style="margin-bottom: 10px; color: #ddd;"></i><br>
                            Danh mục này chưa có sản phẩm nào.
                        </div>
                    </c:if>
                    <c:if test="${cat.soLuongSanPham > 0}">
                        <table class="product-list-table" style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr>
                                    <th>Mã SP</th>
                                    <th>Tên Sản Phẩm</th>
                                    <th style="text-align: right;">Giá Bán</th>
                                    <th style="text-align: center;">Tồn Kho</th>
                                    <th style="text-align: center;">Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="sp" items="${cat.danhSachSanPham}">
                                    <tr>
                                        <td>#${sp.maSP}</td>
                                        <td style="font-weight: bold;">${sp.tenSP}</td>
                                        <td style="text-align: right; color: var(--danger); font-weight: bold;">
                                            <fmt:formatNumber value="${sp.giaBan}" type="currency" currencySymbol="₫" maxFractionDigits="0"/>
                                        </td>
                                        <td style="text-align: center;">${sp.soLuongTon}</td>
                                        <td style="text-align: center;">
                                            <span style="color: ${sp.trangThai ? 'green' : 'red'}; font-size: 11px; font-weight: bold;">
                                                ${sp.trangThai ? 'Đang bán' : 'Ngừng KD'}
                                            </span>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </c:if>
                </div>
            </div>
        </div>
    </c:forEach>
    <!-- END MODAL CHI TIẾT -->

    <!-- Modal Form Thêm/Sửa -->
    <div id="categoryModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle"></h3>
                <span class="close-btn" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="categoryForm" action="${pageContext.request.contextPath}/category" method="post">
                    <input type="hidden" id="action" name="action" value="add">
                    <input type="hidden" id="maDM" name="maDM">
                    
                    <div class="form-group">
                        <label class="form-label">Tên danh mục <span style="color:red;">*</span></label>
                        <input type="text" id="tenDM" name="tenDM" class="form-control" placeholder="Nhập tên..." required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mô tả</label>
                        <textarea id="moTa" name="moTa" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="form-group" style="background: #f8f9fc; padding: 12px; border-radius: 6px; border: 1px solid #eaecf4;">
                        <label style="display: flex; align-items: center; cursor: pointer; margin:0;">
                            <input type="checkbox" id="trangThai" name="trangThai" value="true" checked style="margin-right: 10px;"> 
                            <span style="font-weight: 600; color: var(--dark);">Đang hoạt động</span>
                        </label>
                    </div>
                    
                    <button type="submit" class="btn-gradient btn-gradient-primary" style="width: 100%; justify-content: center; padding: 12px; margin-top: 10px;">
                        <i class="fa-solid fa-floppy-disk"></i> LƯU THAY ĐỔI
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const modal = document.getElementById('categoryModal');
        
        function openAddModal() {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-plus-circle"></i> Thêm Danh Mục';
            document.getElementById('action').value = 'add';
            document.getElementById('maDM').value = '';
            document.getElementById('tenDM').value = '';
            document.getElementById('moTa').value = '';
            document.getElementById('trangThai').checked = true;
            modal.style.display = 'flex';
        }

        function openEditModal(id, ten, moTa, trangThai) {
            document.getElementById('modalTitle').innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Cập Nhật Danh Mục';
            document.getElementById('action').value = 'edit';
            document.getElementById('maDM').value = id;
            document.getElementById('tenDM').value = ten;
            document.getElementById('moTa').value = (moTa !== 'null' && moTa !== '') ? moTa : '';
            document.getElementById('trangThai').checked = trangThai;
            modal.style.display = 'flex';
        }

        function openDetailModal(modalId) {
            document.getElementById(modalId).style.display = 'flex';
        }

        function closeSpecificModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function closeModal() {
            modal.style.display = 'none';
        }

        // Fix logic click ra ngoài Modal để đóng (Hỗ trợ đóng TẤT CẢ các loại modal)
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>