<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Redirect to login servlet or dashboard based on future filter logic
    response.sendRedirect(request.getContextPath() + "/login");
%>