package com.cnj11.filter;

import com.cnj11.model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class AuthorizationFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String path = req.getRequestURI();

        if (path.contains("/login") || path.contains("/assets/") || path.contains("/logout")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        if (session != null) {
            User user = (User) session.getAttribute("currentUser");
            if (user != null) {
                // STAFF không được phép truy cập module Account (Quản lý tài khoản)
                boolean isAdminOnlyPath = path.contains("/account"); 
                
                if (isAdminOnlyPath && !"ADMIN".equals(user.getRole())) {
                    res.sendError(HttpServletResponse.SC_FORBIDDEN, "Lỗi 403: Bạn không có quyền truy cập chức năng của Quản Trị Viên.");
                    return;
                }
            }
        }
        chain.doFilter(request, response);
    }
}