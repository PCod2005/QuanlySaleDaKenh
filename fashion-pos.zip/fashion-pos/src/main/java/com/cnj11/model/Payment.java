package com.cnj11.model;
import java.sql.Timestamp;

public class Payment {
    private int maTT;
    private int maDH;
    private Timestamp ngayTT;
    private double tienKhachDua;
    private double tienThua;
    private String ghiChu;

    public Payment() {}
    public int getMaTT() { return maTT; } public void setMaTT(int maTT) { this.maTT = maTT; }
    public int getMaDH() { return maDH; } public void setMaDH(int maDH) { this.maDH = maDH; }
    public Timestamp getNgayTT() { return ngayTT; } public void setNgayTT(Timestamp ngayTT) { this.ngayTT = ngayTT; }
    public double getTienKhachDua() { return tienKhachDua; } public void setTienKhachDua(double tienKhachDua) { this.tienKhachDua = tienKhachDua; }
    public double getTienThua() { return tienThua; } public void setTienThua(double tienThua) { this.tienThua = tienThua; }
    public String getGhiChu() { return ghiChu; } public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
}