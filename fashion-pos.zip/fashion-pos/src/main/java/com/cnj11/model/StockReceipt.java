package com.cnj11.model;
import java.sql.Timestamp;

public class StockReceipt {
    private int maPN;
    private int maNV;
    private Timestamp ngayNhap;
    private double tongTien;
    private String ghiChu;
    private String tenNV; // Hiển thị UI

    public StockReceipt() {}
    public int getMaPN() { return maPN; } public void setMaPN(int maPN) { this.maPN = maPN; }
    public int getMaNV() { return maNV; } public void setMaNV(int maNV) { this.maNV = maNV; }
    public Timestamp getNgayNhap() { return ngayNhap; } public void setNgayNhap(Timestamp ngayNhap) { this.ngayNhap = ngayNhap; }
    public double getTongTien() { return tongTien; } public void setTongTien(double tongTien) { this.tongTien = tongTien; }
    public String getGhiChu() { return ghiChu; } public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
    public String getTenNV() { return tenNV; } public void setTenNV(String tenNV) { this.tenNV = tenNV; }
}