package com.cnj11.model;

public class User {
    private int maNV;
    private String username;
    private String password;
    private String hoTen;
    private String sdt;
    private String email;
    private String role;
    private boolean trangThai;

    public User() {}
    public int getMaNV() { return maNV; } public void setMaNV(int maNV) { this.maNV = maNV; }
    public String getUsername() { return username; } public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; } public void setPassword(String password) { this.password = password; }
    public String getHoTen() { return hoTen; } public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public String getSdt() { return sdt; } public void setSdt(String sdt) { this.sdt = sdt; }
    public String getEmail() { return email; } public void setEmail(String email) { this.email = email; }
    public String getRole() { return role; } public void setRole(String role) { this.role = role; }
    public boolean isTrangThai() { return trangThai; } public void setTrangThai(boolean trangThai) { this.trangThai = trangThai; }
}