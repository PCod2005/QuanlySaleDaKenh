package com.cnj11.model;
import java.util.List;

public class Category {
    private int maDM;
    private String tenDM;
    private String moTa;
    private boolean trangThai;
    
    // THÊM MỚI ĐỂ XỬ LÝ GIAO DIỆN & LOGIC
    private int soLuongSanPham; 
    private List<Product> danhSachSanPham; 

    public Category() {}
    public int getMaDM() { return maDM; } public void setMaDM(int maDM) { this.maDM = maDM; }
    public String getTenDM() { return tenDM; } public void setTenDM(String tenDM) { this.tenDM = tenDM; }
    public String getMoTa() { return moTa; } public void setMoTa(String moTa) { this.moTa = moTa; }
    public boolean isTrangThai() { return trangThai; } public void setTrangThai(boolean trangThai) { this.trangThai = trangThai; }
    
    public int getSoLuongSanPham() { return soLuongSanPham; } public void setSoLuongSanPham(int soLuongSanPham) { this.soLuongSanPham = soLuongSanPham; }
    public List<Product> getDanhSachSanPham() { return danhSachSanPham; } public void setDanhSachSanPham(List<Product> danhSachSanPham) { this.danhSachSanPham = danhSachSanPham; }
}