package com.cnj11.model;

public class Product {
    private int maSP;
    private int maDM;
    private String tenSP;
    private double giaNhap;
    private double giaBan;
    private int soLuongTon;
    private String moTa;
    private String anh;
    private boolean trangThai;
    
    private String tenDM; // Phục vụ hiển thị UI

    public Product() {}
    public int getMaSP() { return maSP; } public void setMaSP(int maSP) { this.maSP = maSP; }
    public int getMaDM() { return maDM; } public void setMaDM(int maDM) { this.maDM = maDM; }
    public String getTenSP() { return tenSP; } public void setTenSP(String tenSP) { this.tenSP = tenSP; }
    public double getGiaNhap() { return giaNhap; } public void setGiaNhap(double giaNhap) { this.giaNhap = giaNhap; }
    public double getGiaBan() { return giaBan; } public void setGiaBan(double giaBan) { this.giaBan = giaBan; }
    public int getSoLuongTon() { return soLuongTon; } public void setSoLuongTon(int soLuongTon) { this.soLuongTon = soLuongTon; }
    public String getMoTa() { return moTa; } public void setMoTa(String moTa) { this.moTa = moTa; }
    public String getAnh() { return anh; } public void setAnh(String anh) { this.anh = anh; }
    public boolean isTrangThai() { return trangThai; } public void setTrangThai(boolean trangThai) { this.trangThai = trangThai; }
    public String getTenDM() { return tenDM; } public void setTenDM(String tenDM) { this.tenDM = tenDM; }
}