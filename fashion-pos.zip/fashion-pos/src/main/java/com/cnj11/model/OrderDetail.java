package com.cnj11.model;

public class OrderDetail {
    private int maDH;
    private int maSP;
    private int soLuong;
    private double giaBan;
    private double thanhTien;
    private String tenSP; // UI Display

    public OrderDetail() {}
    public int getMaDH() { return maDH; } public void setMaDH(int maDH) { this.maDH = maDH; }
    public int getMaSP() { return maSP; } public void setMaSP(int maSP) { this.maSP = maSP; }
    public int getSoLuong() { return soLuong; } public void setSoLuong(int soLuong) { this.soLuong = soLuong; }
    public double getGiaBan() { return giaBan; } public void setGiaBan(double giaBan) { this.giaBan = giaBan; }
    public double getThanhTien() { return thanhTien; } public void setThanhTien(double thanhTien) { this.thanhTien = thanhTien; }
    public String getTenSP() { return tenSP; } public void setTenSP(String tenSP) { this.tenSP = tenSP; }
}