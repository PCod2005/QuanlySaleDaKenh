package com.cnj11.model;

public class RevenueItem {
    private String label;
    private double value;

    public RevenueItem() {}
    
    public RevenueItem(String label, double value) {
        this.label = label;
        this.value = value;
    }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
    public double getValue() { return value; }
    public void setValue(double value) { this.value = value; }
}