package com.cnj11.model;

import java.util.Map;

public class DashboardStats {
    private double totalRevenue;
    private int totalOrders;
    private int todayOrders;
    private int productsSold;
    private int lowStockCount;
    
    private Map<String, Integer> bestSellingProducts;
    private Map<String, Double> revenueByChannel;

    public DashboardStats() {}

    public double getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(double totalRevenue) { this.totalRevenue = totalRevenue; }

    public int getTotalOrders() { return totalOrders; }
    public void setTotalOrders(int totalOrders) { this.totalOrders = totalOrders; }

    public int getTodayOrders() { return todayOrders; }
    public void setTodayOrders(int todayOrders) { this.todayOrders = todayOrders; }

    public int getProductsSold() { return productsSold; }
    public void setProductsSold(int productsSold) { this.productsSold = productsSold; }

    public int getLowStockCount() { return lowStockCount; }
    public void setLowStockCount(int lowStockCount) { this.lowStockCount = lowStockCount; }

    public Map<String, Integer> getBestSellingProducts() { return bestSellingProducts; }
    public void setBestSellingProducts(Map<String, Integer> bestSellingProducts) { this.bestSellingProducts = bestSellingProducts; }

    public Map<String, Double> getRevenueByChannel() { return revenueByChannel; }
    public void setRevenueByChannel(Map<String, Double> revenueByChannel) { this.revenueByChannel = revenueByChannel; }
}