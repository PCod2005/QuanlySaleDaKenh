package com.cnj11.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Cart {
    // Dùng LinkedHashMap để giữ đúng thứ tự sản phẩm được thêm vào
    private final Map<Integer, CartItem> items = new LinkedHashMap<>();

    public void addItem(Product p, int qty) {
        if (!p.isTrangThai() || p.getSoLuongTon() <= 0 || qty <= 0) return;

        if (items.containsKey(p.getMaSP())) {
            CartItem item = items.get(p.getMaSP());
            int newQty = item.getSoLuong() + qty;
            if (newQty <= p.getSoLuongTon()) {
                item.setSoLuong(newQty);
                item.setThanhTien(newQty * item.getGiaBan());
            }
        } else {
            if (qty <= p.getSoLuongTon()) {
                CartItem item = new CartItem();
                item.setMaSP(p.getMaSP());
                item.setTenSP(p.getTenSP());
                item.setGiaBan(p.getGiaBan());
                item.setSoLuong(qty);
                item.setThanhTien(qty * p.getGiaBan());
                item.setMaxStock(p.getSoLuongTon());
                items.put(p.getMaSP(), item);
            }
        }
    }

    public void updateQuantity(int maSP, int qty) {
        if (items.containsKey(maSP)) {
            CartItem item = items.get(maSP);
            if (qty <= 0) {
                items.remove(maSP);
            } else if (qty <= item.getMaxStock()) {
                item.setSoLuong(qty);
                item.setThanhTien(qty * item.getGiaBan());
            }
        }
    }

    public void removeItem(int maSP) {
        items.remove(maSP);
    }

    public void clear() {
        items.clear();
    }

    public double getTotal() {
        double total = 0;
        for (CartItem item : items.values()) {
            total += item.getThanhTien();
        }
        return total;
    }

    public List<CartItem> getItems() {
        return new ArrayList<>(items.values());
    }
    
    public boolean isEmpty() {
        return items.isEmpty();
    }
}