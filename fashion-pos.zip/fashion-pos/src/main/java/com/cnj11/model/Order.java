package com.cnj11.model;
import java.sql.Timestamp;
import java.util.List;

public class Order {
    private int maDH;
    private int maNV;
    private Timestamp ngayLap;
    private String tenKhachHang;
    private String soDienThoaiKhachHang;
    private String diaChiKhachHang;
    private String kenhBan;
    private int maPTTT;
    private double tongTien;
    private String trangThai;
    private String ghiChu;

    // Các trường dùng để hiển thị (Join từ bảng khác)
    private String tenNV;
    private String tenPTTT;

    private List<OrderDetail> chiTietList;
    private Payment thanhToan;

    public Order() {}
    
    public int getMaDH() { return maDH; } public void setMaDH(int maDH) { this.maDH = maDH; }
    public int getMaNV() { return maNV; } public void setMaNV(int maNV) { this.maNV = maNV; }
    public Timestamp getNgayLap() { return ngayLap; } public void setNgayLap(Timestamp ngayLap) { this.ngayLap = ngayLap; }
    public String getTenKhachHang() { return tenKhachHang; } public void setTenKhachHang(String tenKhachHang) { this.tenKhachHang = tenKhachHang; }
    public String getSoDienThoaiKhachHang() { return soDienThoaiKhachHang; } public void setSoDienThoaiKhachHang(String soDienThoaiKhachHang) { this.soDienThoaiKhachHang = soDienThoaiKhachHang; }
    public String getDiaChiKhachHang() { return diaChiKhachHang; } public void setDiaChiKhachHang(String diaChiKhachHang) { this.diaChiKhachHang = diaChiKhachHang; }
    public String getKenhBan() { return kenhBan; } public void setKenhBan(String kenhBan) { this.kenhBan = kenhBan; }
    public int getMaPTTT() { return maPTTT; } public void setMaPTTT(int maPTTT) { this.maPTTT = maPTTT; }
    public double getTongTien() { return tongTien; } public void setTongTien(double tongTien) { this.tongTien = tongTien; }
    public String getTrangThai() { return trangThai; } public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
    public String getGhiChu() { return ghiChu; } public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
    
    public String getTenNV() { return tenNV; } public void setTenNV(String tenNV) { this.tenNV = tenNV; }
    public String getTenPTTT() { return tenPTTT; } public void setTenPTTT(String tenPTTT) { this.tenPTTT = tenPTTT; }
    
    public List<OrderDetail> getChiTietList() { return chiTietList; } public void setChiTietList(List<OrderDetail> chiTietList) { this.chiTietList = chiTietList; }
    public Payment getThanhToan() { return thanhToan; } public void setThanhToan(Payment thanhToan) { this.thanhToan = thanhToan; }
}