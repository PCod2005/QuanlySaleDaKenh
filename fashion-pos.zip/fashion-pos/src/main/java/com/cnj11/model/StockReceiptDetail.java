package com.cnj11.model;

public class StockReceiptDetail {
    private int maPN;
    private int maSP;
    private int soLuong;
    private double giaNhap;
    private double thanhTien;
    private String tenSP; // Hiển thị UI

    public StockReceiptDetail() {}
    public int getMaPN() { return maPN; } public void setMaPN(int maPN) { this.maPN = maPN; }
    public int getMaSP() { return maSP; } public void setMaSP(int maSP) { this.maSP = maSP; }
    public int getSoLuong() { return soLuong; } public void setSoLuong(int soLuong) { this.soLuong = soLuong; }
    public double getGiaNhap() { return giaNhap; } public void setGiaNhap(double giaNhap) { this.giaNhap = giaNhap; }
    public double getThanhTien() { return thanhTien; } public void setThanhTien(double thanhTien) { this.thanhTien = thanhTien; }
    public String getTenSP() { return tenSP; } public void setTenSP(String tenSP) { this.tenSP = tenSP; }
}