package com.cnj11.model;

public class CartItem {
    private int maSP;
    private String tenSP;
    private double giaBan;
    private int soLuong;
    private double thanhTien;
    private int maxStock; // Dùng để validate UI không cho nhập quá tồn kho

    public CartItem() {}

    public int getMaSP() { return maSP; } public void setMaSP(int maSP) { this.maSP = maSP; }
    public String getTenSP() { return tenSP; } public void setTenSP(String tenSP) { this.tenSP = tenSP; }
    public double getGiaBan() { return giaBan; } public void setGiaBan(double giaBan) { this.giaBan = giaBan; }
    public int getSoLuong() { return soLuong; } public void setSoLuong(int soLuong) { this.soLuong = soLuong; }
    public double getThanhTien() { return thanhTien; } public void setThanhTien(double thanhTien) { this.thanhTien = thanhTien; }
    public int getMaxStock() { return maxStock; } public void setMaxStock(int maxStock) { this.maxStock = maxStock; }
}