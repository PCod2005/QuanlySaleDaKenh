package com.cnj11.dao;

import com.cnj11.model.DashboardStats;

public interface DashboardDAO {
    DashboardStats getDashboardStatistics();
}