package com.cnj11.dao;
import com.cnj11.model.Product;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface ProductDAO {
    Product findById(int id);
    List<Product> findAll();
    List<Product> search(String keyword);
    boolean insert(Product product);
    boolean update(Product product);
    boolean updateStatus(int id, boolean status);
    boolean deleteProduct(int maSP);
    // Transaction support cho việc trừ kho khi bán hàng
    void updateStock(Connection conn, int maSP, int quantityChange) throws SQLException;
}