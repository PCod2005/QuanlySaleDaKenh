package com.cnj11.dao.impl;
import com.cnj11.dao.UserDAO;
import com.cnj11.model.User;
import com.cnj11.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO {
    private User extractUser(ResultSet rs) throws SQLException {
        User u = new User();
        u.setMaNV(rs.getInt("maNV"));
        u.setUsername(rs.getString("username"));
        u.setPassword(rs.getString("password"));
        u.setHoTen(rs.getString("hoTen"));
        u.setSdt(rs.getString("sdt"));
        u.setEmail(rs.getString("email"));
        u.setRole(rs.getString("role"));
        u.setTrangThai(rs.getBoolean("trangThai"));
        return u;
    }

    @Override
    public User findByUsername(String username) {
        String sql = "SELECT * FROM NGUOI_DUNG WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return extractUser(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public User findById(int id) {
        String sql = "SELECT * FROM NGUOI_DUNG WHERE maNV = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return extractUser(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM NGUOI_DUNG";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(extractUser(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean insert(User user) {
        String sql = "INSERT INTO NGUOI_DUNG(username, password, hoTen, sdt, email, role, trangThai) VALUES(?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getHoTen());
            ps.setString(4, user.getSdt());
            ps.setString(5, user.getEmail());
            ps.setString(6, user.getRole());
            ps.setBoolean(7, user.isTrangThai());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public boolean update(User user) {
        String sql = "UPDATE NGUOI_DUNG SET hoTen=?, sdt=?, email=?, role=?, trangThai=? WHERE maNV=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getHoTen());
            ps.setString(2, user.getSdt());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getRole());
            ps.setBoolean(5, user.isTrangThai());
            ps.setInt(6, user.getMaNV());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public boolean updateStatus(int id, boolean status) {
        String sql = "UPDATE NGUOI_DUNG SET trangThai = ? WHERE maNV = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBoolean(1, status);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
}