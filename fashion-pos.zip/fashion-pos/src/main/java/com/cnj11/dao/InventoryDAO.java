package com.cnj11.dao;
import com.cnj11.model.StockReceipt;
import com.cnj11.model.StockReceiptDetail;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface InventoryDAO {
    int insertReceipt(Connection conn, StockReceipt receipt) throws SQLException;
    void insertReceiptDetail(Connection conn, StockReceiptDetail detail) throws SQLException;
    List<StockReceipt> findAllReceipts();
    List<StockReceiptDetail> findDetailsByReceiptId(int maPN);
}