package com.cnj11.dao;
import com.cnj11.model.Category;
import java.util.List;

public interface CategoryDAO {
    Category findById(int id);
    List<Category> findAll();
    boolean insert(Category category);
    boolean update(Category category);
    boolean delete(int id); // Sẽ catch SQLException nếu vướng FK
}