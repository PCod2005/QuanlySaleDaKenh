package com.cnj11.dao.impl;

import com.cnj11.dao.DashboardDAO;
import com.cnj11.model.DashboardStats;
import com.cnj11.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class DashboardDAOImpl implements DashboardDAO {

    @Override
    public DashboardStats getDashboardStatistics() {
        DashboardStats stats = new DashboardStats();
        
        try (Connection conn = DBConnection.getConnection()) {
            // 1. Tổng doanh thu (bỏ qua đơn Đã hủy)
            String sqlRevenue = "SELECT SUM(tongTien) FROM DON_HANG WHERE trangThai != 'Đã hủy'";
            try (PreparedStatement ps = conn.prepareStatement(sqlRevenue); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.setTotalRevenue(rs.getDouble(1));
            }

            // 2. Tổng đơn hàng
            String sqlTotalOrders = "SELECT COUNT(*) FROM DON_HANG";
            try (PreparedStatement ps = conn.prepareStatement(sqlTotalOrders); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.setTotalOrders(rs.getInt(1));
            }

            // 3. Đơn hàng hôm nay
            String sqlTodayOrders = "SELECT COUNT(*) FROM DON_HANG WHERE DATE(ngayLap) = CURDATE()";
            try (PreparedStatement ps = conn.prepareStatement(sqlTodayOrders); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.setTodayOrders(rs.getInt(1));
            }

            // 4. Số lượng sản phẩm đã bán
            String sqlProductsSold = "SELECT COALESCE(SUM(cd.soLuong), 0) FROM CHI_TIET_DON_HANG cd JOIN DON_HANG d ON cd.maDH = d.maDH WHERE d.trangThai != 'Đã hủy'";
            try (PreparedStatement ps = conn.prepareStatement(sqlProductsSold); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.setProductsSold(rs.getInt(1));
            }

            // 5. Sản phẩm sắp hết hàng (Dưới 10)
            String sqlLowStock = "SELECT COUNT(*) FROM SAN_PHAM WHERE soLuongTon > 0 AND soLuongTon <= 10 AND trangThai = 1";
            try (PreparedStatement ps = conn.prepareStatement(sqlLowStock); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.setLowStockCount(rs.getInt(1));
            }

            // 6. Top 5 sản phẩm bán chạy
            Map<String, Integer> bestSellers = new LinkedHashMap<>();
            String sqlBestSellers = "SELECT p.tenSP, SUM(cd.soLuong) as total FROM CHI_TIET_DON_HANG cd JOIN DON_HANG d ON cd.maDH = d.maDH JOIN SAN_PHAM p ON cd.maSP = p.maSP WHERE d.trangThai != 'Đã hủy' GROUP BY p.maSP ORDER BY total DESC LIMIT 5";
            try (PreparedStatement ps = conn.prepareStatement(sqlBestSellers); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    bestSellers.put(rs.getString("tenSP"), rs.getInt("total"));
                }
            }
            stats.setBestSellingProducts(bestSellers);

            // 7. Thống kê theo Kênh Bán
            Map<String, Double> channelStats = new LinkedHashMap<>();
            String sqlChannels = "SELECT kenhBan, SUM(tongTien) FROM DON_HANG WHERE trangThai != 'Đã hủy' GROUP BY kenhBan";
            try (PreparedStatement ps = conn.prepareStatement(sqlChannels); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    channelStats.put(rs.getString("kenhBan"), rs.getDouble(2));
                }
            }
            stats.setRevenueByChannel(channelStats);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stats;
    }
}