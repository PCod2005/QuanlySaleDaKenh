package com.cnj11.dao.impl;
import com.cnj11.dao.OrderDAO;
import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import com.cnj11.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAOImpl implements OrderDAO {
    
    @Override
    public int insertOrder(Connection conn, Order order) throws SQLException {
        String sql = "INSERT INTO DON_HANG(maNV, tenKhachHang, soDienThoaiKhachHang, diaChiKhachHang, kenhBan, maPTTT, tongTien, trangThai, ghiChu) VALUES(?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, order.getMaNV());
            ps.setString(2, order.getTenKhachHang());
            ps.setString(3, order.getSoDienThoaiKhachHang());
            ps.setString(4, order.getDiaChiKhachHang());
            ps.setString(5, order.getKenhBan());
            ps.setInt(6, order.getMaPTTT());
            ps.setDouble(7, order.getTongTien());
            ps.setString(8, order.getTrangThai());
            ps.setString(9, order.getGhiChu());
            ps.executeUpdate();
            
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("Failed to insert Order, no ID obtained.");
    }

    @Override
    public void insertOrderDetail(Connection conn, OrderDetail detail) throws SQLException {
        String sql = "INSERT INTO CHI_TIET_DON_HANG(maDH, maSP, soLuong, giaBan, thanhTien) VALUES(?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, detail.getMaDH());
            ps.setInt(2, detail.getMaSP());
            ps.setInt(3, detail.getSoLuong());
            ps.setDouble(4, detail.getGiaBan());
            ps.setDouble(5, detail.getThanhTien());
            ps.executeUpdate();
        }
    }

    @Override
    public void insertPayment(Connection conn, Payment payment) throws SQLException {
        String sql = "INSERT INTO THANH_TOAN(maDH, tienKhachDua, tienThua, ghiChu) VALUES(?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, payment.getMaDH());
            ps.setDouble(2, payment.getTienKhachDua());
            ps.setDouble(3, payment.getTienThua());
            ps.setString(4, payment.getGhiChu());
            ps.executeUpdate();
        }
    }

    @Override
    public Order findById(int id) {
        String sql = "SELECT * FROM DON_HANG WHERE maDH = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Order order = new Order();
                    order.setMaDH(rs.getInt("maDH"));
                    order.setMaNV(rs.getInt("maNV"));
                    order.setNgayLap(rs.getTimestamp("ngayLap"));
                    order.setTenKhachHang(rs.getString("tenKhachHang"));
                    order.setSoDienThoaiKhachHang(rs.getString("soDienThoaiKhachHang"));
                    order.setDiaChiKhachHang(rs.getString("diaChiKhachHang"));
                    order.setKenhBan(rs.getString("kenhBan"));
                    order.setMaPTTT(rs.getInt("maPTTT"));
                    order.setTongTien(rs.getDouble("tongTien"));
                    order.setTrangThai(rs.getString("trangThai"));
                    order.setGhiChu(rs.getString("ghiChu"));
                    return order;
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Order> findAll() {
        // Implement full query logic later for Order List screen
        return new ArrayList<>();
    }

    @Override
    public List<OrderDetail> findDetailsByOrderId(int maDH) {
        List<OrderDetail> list = new ArrayList<>();
        String sql = "SELECT cd.*, p.tenSP FROM CHI_TIET_DON_HANG cd JOIN SAN_PHAM p ON cd.maSP = p.maSP WHERE cd.maDH = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maDH);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    OrderDetail od = new OrderDetail();
                    od.setMaDH(rs.getInt("maDH"));
                    od.setMaSP(rs.getInt("maSP"));
                    od.setSoLuong(rs.getInt("soLuong"));
                    od.setGiaBan(rs.getDouble("giaBan"));
                    od.setThanhTien(rs.getDouble("thanhTien"));
                    od.setTenSP(rs.getString("tenSP"));
                    list.add(od);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public void updateStatus(int id, String status) {
        String sql = "UPDATE DON_HANG SET trangThai = ? WHERE maDH = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }
 // ... (Giữ nguyên các hàm insert)

    @Override
    public List<Order> searchAndFilter(String keyword, String fromDate, String toDate, String status, String channel) {
        List<Order> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT o.*, u.hoTen as tenNV, p.tenPTTT as tenPTTT " +
            "FROM DON_HANG o " +
            "JOIN NGUOI_DUNG u ON o.maNV = u.maNV " +
            "JOIN PHUONG_THUC_THANH_TOAN p ON o.maPTTT = p.maPTTT " +
            "WHERE 1=1 "
        );
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (o.maDH LIKE ? OR o.tenKhachHang LIKE ? OR o.soDienThoaiKhachHang LIKE ?) ");
            String kw = "%" + keyword.trim() + "%";
            params.add(kw); params.add(kw); params.add(kw);
        }
        if (fromDate != null && !fromDate.trim().isEmpty()) {
            sql.append(" AND DATE(o.ngayLap) >= ? ");
            params.add(fromDate);
        }
        if (toDate != null && !toDate.trim().isEmpty()) {
            sql.append(" AND DATE(o.ngayLap) <= ? ");
            params.add(toDate);
        }
        if (status != null && !status.trim().isEmpty() && !status.equals("All")) {
            sql.append(" AND o.trangThai = ? ");
            params.add(status);
        }
        if (channel != null && !channel.trim().isEmpty() && !channel.equals("All")) {
            sql.append(" AND o.kenhBan = ? ");
            params.add(channel);
        }
        
        sql.append(" ORDER BY o.maDH DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order order = new Order();
                    order.setMaDH(rs.getInt("maDH"));
                    order.setMaNV(rs.getInt("maNV"));
                    order.setNgayLap(rs.getTimestamp("ngayLap"));
                    order.setTenKhachHang(rs.getString("tenKhachHang"));
                    order.setSoDienThoaiKhachHang(rs.getString("soDienThoaiKhachHang"));
                    order.setDiaChiKhachHang(rs.getString("diaChiKhachHang"));
                    order.setKenhBan(rs.getString("kenhBan"));
                    order.setMaPTTT(rs.getInt("maPTTT"));
                    order.setTongTien(rs.getDouble("tongTien"));
                    order.setTrangThai(rs.getString("trangThai"));
                    order.setGhiChu(rs.getString("ghiChu"));
                    order.setTenNV(rs.getString("tenNV"));
                    order.setTenPTTT(rs.getString("tenPTTT"));
                    list.add(order);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Payment findPaymentByOrderId(int maDH) {
        String sql = "SELECT * FROM THANH_TOAN WHERE maDH = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maDH);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Payment payment = new Payment();
                    payment.setMaTT(rs.getInt("maTT"));
                    payment.setMaDH(rs.getInt("maDH"));
                    payment.setNgayTT(rs.getTimestamp("ngayTT"));
                    payment.setTienKhachDua(rs.getDouble("tienKhachDua"));
                    payment.setTienThua(rs.getDouble("tienThua"));
                    payment.setGhiChu(rs.getString("ghiChu"));
                    return payment;
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }
}