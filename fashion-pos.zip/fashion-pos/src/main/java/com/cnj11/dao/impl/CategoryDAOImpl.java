package com.cnj11.dao.impl;
import com.cnj11.dao.CategoryDAO;
import com.cnj11.model.Category;
import com.cnj11.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAOImpl implements CategoryDAO {
    private Category extractCategory(ResultSet rs) throws SQLException {
        Category c = new Category();
        c.setMaDM(rs.getInt("maDM"));
        c.setTenDM(rs.getString("tenDM"));
        c.setMoTa(rs.getString("moTa"));
        c.setTrangThai(rs.getBoolean("trangThai"));
        return c;
    }

    @Override
    public Category findById(int id) {
        String sql = "SELECT * FROM DANH_MUC WHERE maDM = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return extractCategory(rs); }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Category> findAll() {
        List<Category> list = new ArrayList<>();
        // Query đếm số lượng SP thuộc Danh mục này
        String sql = "SELECT c.*, (SELECT COUNT(*) FROM SAN_PHAM p WHERE p.maDM = c.maDM) AS soLuongSP FROM DANH_MUC c ORDER BY c.maDM DESC";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Category c = new Category();
                c.setMaDM(rs.getInt("maDM"));
                c.setTenDM(rs.getString("tenDM"));
                c.setMoTa(rs.getString("moTa"));
                c.setTrangThai(rs.getBoolean("trangThai"));
                c.setSoLuongSanPham(rs.getInt("soLuongSP")); // Gán số lượng để chặn xóa
                list.add(c);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean insert(Category category) {
        String sql = "INSERT INTO DANH_MUC(tenDM, moTa, trangThai) VALUES(?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, category.getTenDM());
            ps.setString(2, category.getMoTa());
            ps.setBoolean(3, category.isTrangThai());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public boolean update(Category category) {
        String sql = "UPDATE DANH_MUC SET tenDM=?, moTa=?, trangThai=? WHERE maDM=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, category.getTenDM());
            ps.setString(2, category.getMoTa());
            ps.setBoolean(3, category.isTrangThai());
            ps.setInt(4, category.getMaDM());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM DANH_MUC WHERE maDM=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { 
            e.printStackTrace(); 
            // Sẽ handle foreign key constraint trong Controller/Service
            return false; 
        }
    }
}