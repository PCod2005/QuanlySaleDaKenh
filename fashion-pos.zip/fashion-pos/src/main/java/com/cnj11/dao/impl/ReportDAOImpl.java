package com.cnj11.dao.impl;

import com.cnj11.dao.ReportDAO;
import com.cnj11.model.RevenueItem;
import com.cnj11.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReportDAOImpl implements ReportDAO {

    @Override
    public List<RevenueItem> getRevenueByLastDays(int days) {
        List<RevenueItem> list = new ArrayList<>();
        // Lấy doanh thu theo ngày, gom nhóm bằng DATE()
        String sql = "SELECT DATE(ngayLap) as report_date, SUM(tongTien) as total " +
                     "FROM DON_HANG " +
                     "WHERE trangThai != 'Đã hủy' AND ngayLap >= DATE_SUB(CURDATE(), INTERVAL ? DAY) " +
                     "GROUP BY DATE(ngayLap) " +
                     "ORDER BY report_date ASC";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, days - 1);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    // Chuyển đổi format ngày nếu cần, ở đây lấy chuỗi YYYY-MM-DD
                    list.add(new RevenueItem(rs.getString("report_date"), rs.getDouble("total")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<RevenueItem> getRevenueByLastMonths(int months) {
        List<RevenueItem> list = new ArrayList<>();
        // Lấy doanh thu theo tháng YYYY-MM
        String sql = "SELECT DATE_FORMAT(ngayLap, '%Y-%m') as report_month, SUM(tongTien) as total " +
                     "FROM DON_HANG " +
                     "WHERE trangThai != 'Đã hủy' " +
                     "GROUP BY report_month " +
                     "ORDER BY report_month DESC LIMIT ?";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, months);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new RevenueItem(rs.getString("report_month"), rs.getDouble("total")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        
        // Đảo ngược list để biểu đồ hiển thị từ tháng cũ -> tháng mới
        java.util.Collections.reverse(list);
        return list;
    }

    @Override
    public List<RevenueItem> getRevenueByChannel() {
        List<RevenueItem> list = new ArrayList<>();
        String sql = "SELECT kenhBan, SUM(tongTien) as total FROM DON_HANG WHERE trangThai != 'Đã hủy' GROUP BY kenhBan";
        try (Connection conn = DBConnection.getConnection(); 
             PreparedStatement ps = conn.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new RevenueItem(rs.getString("kenhBan"), rs.getDouble("total")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}