package com.cnj11.dao;
import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface OrderDAO {
    // Transactional methods
    int insertOrder(Connection conn, Order order) throws SQLException;
    void insertOrderDetail(Connection conn, OrderDetail detail) throws SQLException;
    void insertPayment(Connection conn, Payment payment) throws SQLException;

    // Read methods
    Order findById(int id);
    List<Order> findAll();
    List<OrderDetail> findDetailsByOrderId(int maDH);
    void updateStatus(int id, String status);
    List<Order> searchAndFilter(String keyword, String fromDate, String toDate, String status, String channel);
    Payment findPaymentByOrderId(int maDH);
}