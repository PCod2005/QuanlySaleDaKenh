package com.cnj11.dao;
import com.cnj11.model.User;
import java.util.List;

public interface UserDAO {
    User findByUsername(String username);
    User findById(int id);
    List<User> findAll();
    boolean insert(User user);
    boolean update(User user);
    boolean updateStatus(int id, boolean status);
}