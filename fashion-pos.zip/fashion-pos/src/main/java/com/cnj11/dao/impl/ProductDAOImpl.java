package com.cnj11.dao.impl;
import com.cnj11.dao.ProductDAO;
import com.cnj11.model.Product;
import com.cnj11.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAOImpl implements ProductDAO {
    private Product extractProduct(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setMaSP(rs.getInt("maSP"));
        p.setMaDM(rs.getInt("maDM"));
        p.setTenSP(rs.getString("tenSP"));
        p.setGiaNhap(rs.getDouble("giaNhap"));
        p.setGiaBan(rs.getDouble("giaBan"));
        p.setSoLuongTon(rs.getInt("soLuongTon"));
        p.setMoTa(rs.getString("moTa"));
        p.setAnh(rs.getString("anh"));
        p.setTrangThai(rs.getBoolean("trangThai"));
        p.setTenDM(rs.getString("tenDM")); // JOIN column
        return p;
    }

    @Override
    public List<Product> findAll() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.tenDM FROM SAN_PHAM p JOIN DANH_MUC c ON p.maDM = c.maDM ORDER BY p.maSP DESC";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(extractProduct(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public Product findById(int id) {
        String sql = "SELECT p.*, c.tenDM FROM SAN_PHAM p JOIN DANH_MUC c ON p.maDM = c.maDM WHERE p.maSP = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return extractProduct(rs); }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<Product> search(String keyword) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT p.*, c.tenDM FROM SAN_PHAM p JOIN DANH_MUC c ON p.maDM = c.maDM WHERE p.tenSP LIKE ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(extractProduct(rs)); }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public boolean insert(Product product) {
        String sql = "INSERT INTO SAN_PHAM(maDM, tenSP, giaNhap, giaBan, soLuongTon, moTa, anh, trangThai) VALUES(?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, product.getMaDM());
            ps.setString(2, product.getTenSP());
            ps.setDouble(3, product.getGiaNhap());
            ps.setDouble(4, product.getGiaBan());
            ps.setInt(5, product.getSoLuongTon());
            ps.setString(6, product.getMoTa());
            ps.setString(7, product.getAnh());
            ps.setBoolean(8, product.isTrangThai());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public boolean update(Product product) {
        String sql = "UPDATE SAN_PHAM SET maDM=?, tenSP=?, giaNhap=?, giaBan=?, moTa=?, anh=?, trangThai=? WHERE maSP=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, product.getMaDM());
            ps.setString(2, product.getTenSP());
            ps.setDouble(3, product.getGiaNhap());
            ps.setDouble(4, product.getGiaBan());
            ps.setString(5, product.getMoTa());
            ps.setString(6, product.getAnh());
            ps.setBoolean(7, product.isTrangThai());
            ps.setInt(8, product.getMaSP());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public boolean updateStatus(int id, boolean status) {
        String sql = "UPDATE SAN_PHAM SET trangThai = ? WHERE maSP = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBoolean(1, status);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public void updateStock(Connection conn, int maSP, int quantityChange) throws SQLException {
        // Cộng hoặc trừ số lượng (quantityChange có thể âm khi bán, dương khi nhập)
        String sql = "UPDATE SAN_PHAM SET soLuongTon = soLuongTon + ? WHERE maSP = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, quantityChange);
            ps.setInt(2, maSP);
            ps.executeUpdate();
        }
    }
    @Override
    public boolean deleteProduct(int maSP) {
        String sql = "DELETE FROM SAN_PHAM WHERE maSP = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maSP);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            // Bắt lỗi Khóa ngoại (Sản phẩm đã nằm trong Hóa đơn thì CSDL sẽ chặn không cho xóa)
            return false; 
        }
    }
}