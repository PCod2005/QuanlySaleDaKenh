package com.cnj11.dao;
import com.cnj11.model.RevenueItem;
import java.util.List;

public interface ReportDAO {
    List<RevenueItem> getRevenueByLastDays(int days);
    List<RevenueItem> getRevenueByLastMonths(int months);
    List<RevenueItem> getRevenueByChannel();
}