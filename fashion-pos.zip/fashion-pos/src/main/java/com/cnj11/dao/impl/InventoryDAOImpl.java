package com.cnj11.dao.impl;
import com.cnj11.dao.InventoryDAO;
import com.cnj11.model.StockReceipt;
import com.cnj11.model.StockReceiptDetail;
import com.cnj11.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryDAOImpl implements InventoryDAO {

    @Override
    public int insertReceipt(Connection conn, StockReceipt receipt) throws SQLException {
        String sql = "INSERT INTO PHIEU_NHAP(maNV, tongTien, ghiChu) VALUES(?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, receipt.getMaNV());
            ps.setDouble(2, receipt.getTongTien());
            ps.setString(3, receipt.getGhiChu());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("Insert StockReceipt failed.");
    }

    @Override
    public void insertReceiptDetail(Connection conn, StockReceiptDetail detail) throws SQLException {
        String sql = "INSERT INTO CHI_TIET_PHIEU_NHAP(maPN, maSP, soLuong, giaNhap, thanhTien) VALUES(?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, detail.getMaPN());
            ps.setInt(2, detail.getMaSP());
            ps.setInt(3, detail.getSoLuong());
            ps.setDouble(4, detail.getGiaNhap());
            ps.setDouble(5, detail.getThanhTien());
            ps.executeUpdate();
        }
    }

    @Override
    public List<StockReceipt> findAllReceipts() {
        List<StockReceipt> list = new ArrayList<>();
        String sql = "SELECT p.*, u.hoTen as tenNV FROM PHIEU_NHAP p JOIN NGUOI_DUNG u ON p.maNV = u.maNV ORDER BY p.maPN DESC";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                StockReceipt sr = new StockReceipt();
                sr.setMaPN(rs.getInt("maPN"));
                sr.setMaNV(rs.getInt("maNV"));
                sr.setNgayNhap(rs.getTimestamp("ngayNhap"));
                sr.setTongTien(rs.getDouble("tongTien"));
                sr.setGhiChu(rs.getString("ghiChu"));
                sr.setTenNV(rs.getString("tenNV"));
                list.add(sr);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<StockReceiptDetail> findDetailsByReceiptId(int maPN) {
        List<StockReceiptDetail> list = new ArrayList<>();
        String sql = "SELECT c.*, s.tenSP FROM CHI_TIET_PHIEU_NHAP c JOIN SAN_PHAM s ON c.maSP = s.maSP WHERE c.maPN = ?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maPN);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    StockReceiptDetail d = new StockReceiptDetail();
                    d.setMaPN(rs.getInt("maPN"));
                    d.setMaSP(rs.getInt("maSP"));
                    d.setSoLuong(rs.getInt("soLuong"));
                    d.setGiaNhap(rs.getDouble("giaNhap"));
                    d.setThanhTien(rs.getDouble("thanhTien"));
                    d.setTenSP(rs.getString("tenSP"));
                    list.add(d);
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}