package com.cnj11.controller;

import com.cnj11.model.User;
import com.cnj11.service.UserService;
import com.cnj11.service.impl.UserServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
    private UserService userService;

    @Override
    public void init() throws ServletException {
        userService = new UserServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("currentUser");
        
        // Lấy thông tin mới nhất từ DB theo ID user đang đăng nhập
        if (currentUser != null) {
            User latestUser = userService.findById(currentUser.getMaNV());
            request.setAttribute("userProfile", latestUser);
        }
        
        request.getRequestDispatcher("/WEB-INF/views/profile/profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("currentUser");

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            String hoTen = request.getParameter("hoTen");
            String sdt = request.getParameter("sdt");
            String email = request.getParameter("email");

            if (hoTen == null || hoTen.trim().isEmpty()) {
                session.setAttribute("errorMsg", "Họ tên không được để trống!");
                response.sendRedirect(request.getContextPath() + "/profile");
                return;
            }

            // Cập nhật thông tin vào object hiện tại
            currentUser.setHoTen(hoTen.trim());
            currentUser.setSdt(sdt);
            currentUser.setEmail(email);

            boolean success = userService.updateUser(currentUser);
            if (success) {
                // Cập nhật lại session
                session.setAttribute("currentUser", currentUser);
                session.setAttribute("successMsg", "Cập nhật thông tin cá nhân thành công!");
            } else {
                session.setAttribute("errorMsg", "Cập nhật thất bại!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMsg", "Đã xảy ra lỗi hệ thống!");
        }

        response.sendRedirect(request.getContextPath() + "/profile");
    }
}