package com.cnj11.controller;

import com.cnj11.model.Category;
import com.cnj11.model.User;
import com.cnj11.service.CategoryService;
import com.cnj11.service.impl.CategoryServiceImpl;
import com.cnj11.util.SystemLogUtil; // Import thêm tiện ích Log

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
    private CategoryService categoryService;

    @Override
    public void init() throws ServletException {
        categoryService = new CategoryServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "delete":
                deleteCategory(request, response);
                break;
            default:
                listCategories(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Kiểm tra quyền (Chỉ ADMIN mới được Thêm/Sửa bằng POST)
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền thực hiện thao tác này.");
            return;
        }

        String action = request.getParameter("action");
        int currentMaNV = currentUser.getMaNV(); // Lấy ID người đang thao tác

        if ("add".equals(action)) {
            addCategory(request, response, currentMaNV);
        } else if ("edit".equals(action)) {
            updateCategory(request, response, currentMaNV);
        } else {
            response.sendRedirect(request.getContextPath() + "/category");
        }
    }

    private void listCategories(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Category> categories = categoryService.findAll();
        
        // Khởi tạo ProductService để lấy SP cho Modal chi tiết
        com.cnj11.service.ProductService productService = new com.cnj11.service.impl.ProductServiceImpl();
        List<com.cnj11.model.Product> allProducts = productService.findAll();
        
        // Nhét sản phẩm vào đúng danh mục của nó
        for (Category cat : categories) {
            List<com.cnj11.model.Product> spTrongDanhMuc = new java.util.ArrayList<>();
            for (com.cnj11.model.Product p : allProducts) {
                if (p.getMaDM() == cat.getMaDM()) {
                    spTrongDanhMuc.add(p);
                }
            }
            cat.setDanhSachSanPham(spTrongDanhMuc);
        }

        request.setAttribute("categories", categories);
        request.getRequestDispatcher("/WEB-INF/views/category/category.jsp").forward(request, response);
    }

    private void addCategory(HttpServletRequest request, HttpServletResponse response, int currentMaNV) throws IOException {
        String tenDM = request.getParameter("tenDM");
        String moTa = request.getParameter("moTa");
        boolean trangThai = request.getParameter("trangThai") != null;

        Category category = new Category();
        category.setTenDM(tenDM);
        category.setMoTa(moTa);
        category.setTrangThai(trangThai);

        if (categoryService.addCategory(category)) {
            // GHI LOG KHI THÊM THÀNH CÔNG
            SystemLogUtil.log(currentMaNV, "Thêm Danh Mục", "Tạo danh mục mới: " + tenDM);
            request.getSession().setAttribute("successMsg", "Thêm danh mục thành công!");
        } else {
            request.getSession().setAttribute("errorMsg", "Thêm thất bại! Tên danh mục có thể đã tồn tại.");
        }
        response.sendRedirect(request.getContextPath() + "/category");
    }

    private void updateCategory(HttpServletRequest request, HttpServletResponse response, int currentMaNV) throws IOException {
        try {
            int maDM = Integer.parseInt(request.getParameter("maDM"));
            String tenDM = request.getParameter("tenDM");
            String moTa = request.getParameter("moTa");
            boolean trangThai = request.getParameter("trangThai") != null;

            Category category = new Category();
            category.setMaDM(maDM);
            category.setTenDM(tenDM);
            category.setMoTa(moTa);
            category.setTrangThai(trangThai);

            if (categoryService.updateCategory(category)) {
                // GHI LOG KHI SỬA THÀNH CÔNG
                SystemLogUtil.log(currentMaNV, "Sửa Danh Mục", "Cập nhật mã DM: " + maDM + " (" + tenDM + ")");
                request.getSession().setAttribute("successMsg", "Cập nhật danh mục thành công!");
            } else {
                request.getSession().setAttribute("errorMsg", "Cập nhật thất bại!");
            }
        } catch (NumberFormatException e) {
            request.getSession().setAttribute("errorMsg", "Dữ liệu không hợp lệ!");
        }
        response.sendRedirect(request.getContextPath() + "/category");
    }

    private void deleteCategory(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền xóa.");
            return;
        }

        try {
            int maDM = Integer.parseInt(request.getParameter("id"));
            if (categoryService.deleteCategory(maDM)) {
                // GHI LOG KHI XÓA THÀNH CÔNG
                SystemLogUtil.log(currentUser.getMaNV(), "Xóa Danh Mục", "Đã xóa hoàn toàn mã DM: " + maDM);
                request.getSession().setAttribute("successMsg", "Xóa danh mục thành công!");
            } else {
                request.getSession().setAttribute("errorMsg", "Không thể xóa danh mục này vì đang có sản phẩm phụ thuộc!");
            }
        } catch (NumberFormatException e) {
            request.getSession().setAttribute("errorMsg", "Mã danh mục không hợp lệ!");
        }
        response.sendRedirect(request.getContextPath() + "/category");
    }
}