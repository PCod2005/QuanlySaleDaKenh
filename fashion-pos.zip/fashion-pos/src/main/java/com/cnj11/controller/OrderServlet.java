package com.cnj11.controller;

import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import com.cnj11.service.OrderService;
import com.cnj11.service.impl.OrderServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
    private OrderService orderService;
    private final String[] STATUSES = {"Mới tạo", "Đã thanh toán", "Đang chuẩn bị", "Đã gửi", "Đang giao", "Đã giao", "Đã hủy"};
    private final String[] CHANNELS = {"Tại cửa hàng", "Facebook", "Zalo", "Shopee", "TikTok", "Điện thoại", "Khác"};

    @Override
    public void init() throws ServletException {
        orderService = new OrderServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("detail".equals(action)) {
            showOrderDetail(request, response);
        } else {
            listOrders(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("updateStatus".equals(action)) {
            try {
                int maDH = Integer.parseInt(request.getParameter("maDH"));
                String status = request.getParameter("status");
                
                if (orderService.updateStatus(maDH, status)) {
                    request.getSession().setAttribute("successMsg", "Cập nhật trạng thái thành công!");
                } else {
                    request.getSession().setAttribute("errorMsg", "Cập nhật thất bại!");
                }
            } catch (NumberFormatException e) {
                request.getSession().setAttribute("errorMsg", "Dữ liệu không hợp lệ.");
            }
            response.sendRedirect(request.getContextPath() + "/order");
        }
    }

    private void listOrders(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        String status = request.getParameter("status");
        String channel = request.getParameter("channel");

        List<Order> orders = orderService.searchAndFilter(keyword, fromDate, toDate, status, channel);

        request.setAttribute("orders", orders);
        request.setAttribute("statuses", STATUSES);
        request.setAttribute("channels", CHANNELS);
        
        // Retain form data
        request.setAttribute("keyword", keyword);
        request.setAttribute("fromDate", fromDate);
        request.setAttribute("toDate", toDate);
        request.setAttribute("status", status);
        request.setAttribute("channel", channel);

        request.getRequestDispatcher("/WEB-INF/views/order/order.jsp").forward(request, response);
    }

    private void showOrderDetail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int maDH = Integer.parseInt(request.getParameter("id"));
            Order order = orderService.findById(maDH);
            if (order != null) {
                List<OrderDetail> details = orderService.findDetailsByOrderId(maDH);
                Payment payment = orderService.findPaymentByOrderId(maDH);
                
                request.setAttribute("order", order);
                request.setAttribute("details", details);
                request.setAttribute("payment", payment);
                request.getRequestDispatcher("/WEB-INF/views/order/order_detail.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/order");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/order");
        }
    }
}