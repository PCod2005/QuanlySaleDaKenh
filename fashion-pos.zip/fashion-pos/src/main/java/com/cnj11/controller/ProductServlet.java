package com.cnj11.controller;

import com.cnj11.model.Category;
import com.cnj11.model.Product;
import com.cnj11.model.User;
import com.cnj11.service.CategoryService;
import com.cnj11.service.ProductService;
import com.cnj11.service.impl.CategoryServiceImpl;
import com.cnj11.service.impl.ProductServiceImpl;
import com.cnj11.util.SystemLogUtil; // Import tiện ích ghi Log

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {
    private ProductService productService;
    private CategoryService categoryService;

    @Override
    public void init() throws ServletException {
        productService = new ProductServiceImpl();
        categoryService = new CategoryServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "toggleStatus":
                toggleStatus(request, response);
                break;
            case "delete":
                deleteSingleVariant(request, response);
                break;
            default:
                listProducts(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền.");
            return;
        }

        String action = request.getParameter("action");
        if ("add".equals(action)) {
            addProduct(request, response);
        } else if ("edit".equals(action)) { 
            updateProduct(request, response);
        } else if ("editGroup".equals(action)) { 
            updateProductGroup(request, response);
        } else if ("deleteGroup".equals(action)) { 
            deleteProductGroup(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/product");
        }
    }

    // =================================================================================
    // LOGIC: LẤY DANH SÁCH & LỌC & GOM NHÓM
    // =================================================================================
    private void listProducts(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        String catIdStr = request.getParameter("catId");
        
        List<Product> products = (keyword != null && !keyword.trim().isEmpty()) 
                                 ? productService.search(keyword.trim()) 
                                 : productService.findAll();

        // Xử lý Lọc theo Danh mục
        if (catIdStr != null && !catIdStr.isEmpty()) {
            int cId = Integer.parseInt(catIdStr);
            products = products.stream().filter(p -> p.getMaDM() == cId).collect(Collectors.toList());
            request.setAttribute("catId", catIdStr);
        }

        if (keyword != null) request.setAttribute("keyword", keyword);

        // GOM NHÓM
        Map<String, List<Product>> groupedProducts = new LinkedHashMap<>();
        for (Product p : products) {
            String name = p.getTenSP();
            String baseName = name.contains(" - ") ? name.substring(0, name.indexOf(" - ")).trim() : name;
            groupedProducts.computeIfAbsent(baseName, k -> new ArrayList<>()).add(p);
        }

        List<Category> activeCategories = categoryService.findAll().stream()
                .filter(Category::isTrangThai)
                .collect(Collectors.toList());
        
        request.setAttribute("groupedProducts", groupedProducts);
        request.setAttribute("categories", activeCategories);
        request.getRequestDispatcher("/WEB-INF/views/product/product.jsp").forward(request, response);
    }

    private void addProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        try {
            int maDM = Integer.parseInt(request.getParameter("maDM"));
            String tenGoc = request.getParameter("tenSP");
            double giaNhap = Double.parseDouble(request.getParameter("giaNhap"));
            double giaBan = Double.parseDouble(request.getParameter("giaBan"));
            String moTa = request.getParameter("moTa");
            String anh = request.getParameter("anh");
            
            String[] colors = request.getParameterValues("colors[]");
            String[] sizes = request.getParameterValues("sizes[]");

            if (tenGoc.trim().isEmpty() || giaNhap <= 0 || giaBan <= 0) {
                request.getSession().setAttribute("errorMsg", "Dữ liệu không hợp lệ!");
                response.sendRedirect(request.getContextPath() + "/product");
                return;
            }

            int countSuccess = 0;
            if (colors != null && colors.length > 0) {
                for (String color : colors) {
                    if (color.trim().isEmpty()) continue;
                    
                    if (sizes != null && sizes.length > 0) {
                        for (String size : sizes) {
                            String finalName = tenGoc.trim() + " - " + color.trim() + " - Size " + size;
                            if(saveSingleProduct(maDM, finalName, giaNhap, giaBan, moTa, anh)) countSuccess++;
                        }
                    } else {
                        String finalName = tenGoc.trim() + " - " + color.trim();
                        if(saveSingleProduct(maDM, finalName, giaNhap, giaBan, moTa, anh)) countSuccess++;
                    }
                }
            } else {
                if(saveSingleProduct(maDM, tenGoc.trim(), giaNhap, giaBan, moTa, anh)) countSuccess++;
            }
            
            if (countSuccess > 0) {
                SystemLogUtil.log(currentUser.getMaNV(), "Thêm Sản Phẩm", "Đã tạo " + countSuccess + " mã SKU cho mẫu: " + tenGoc.trim());
                request.getSession().setAttribute("successMsg", "Thành công! Đã tạo " + countSuccess + " mã SKU.");
            }
        } catch (NumberFormatException e) {
            request.getSession().setAttribute("errorMsg", "Lỗi định dạng số!");
        }
        response.sendRedirect(request.getContextPath() + "/product");
    }

    private boolean saveSingleProduct(int maDM, String name, double giaNhap, double giaBan, String moTa, String anh) {
        Product p = new Product();
        p.setMaDM(maDM); p.setTenSP(name); p.setGiaNhap(giaNhap); p.setGiaBan(giaBan);
        p.setSoLuongTon(0); p.setMoTa(moTa); p.setTrangThai(true);
        p.setAnh(anh != null && !anh.trim().isEmpty() ? anh.trim() : null);
        return productService.addProduct(p);
    }
    
    // Cập nhật 1 biến thể lẻ
    private void updateProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        try {
            int maSP = Integer.parseInt(request.getParameter("maSP"));
            int maDM = Integer.parseInt(request.getParameter("maDM"));
            String tenSP = request.getParameter("tenSP"); 
            double giaNhap = Double.parseDouble(request.getParameter("giaNhap"));
            double giaBan = Double.parseDouble(request.getParameter("giaBan"));
            String moTa = request.getParameter("moTa");
            String anh = request.getParameter("anh");
            boolean trangThai = request.getParameter("trangThai") != null;

            Product p = new Product();
            p.setMaSP(maSP); p.setMaDM(maDM); p.setTenSP(tenSP); p.setGiaNhap(giaNhap); p.setGiaBan(giaBan);
            p.setMoTa(moTa); p.setTrangThai(trangThai);
            p.setAnh(anh != null && !anh.trim().isEmpty() ? anh.trim() : null);

            if (productService.updateProduct(p)) {
                SystemLogUtil.log(currentUser.getMaNV(), "Sửa SKU Lẻ", "Cập nhật mã SKU: " + maSP + " (" + tenSP + ")");
                request.getSession().setAttribute("successMsg", "Cập nhật biến thể thành công!");
            } else {
                request.getSession().setAttribute("errorMsg", "Cập nhật thất bại!");
            }
        } catch (NumberFormatException e) {
            request.getSession().setAttribute("errorMsg", "Lỗi định dạng số!");
        }
        response.sendRedirect(request.getContextPath() + "/product");
    }

    // Cập nhật Nhóm
    private void updateProductGroup(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        try {
            String maSPListStr = request.getParameter("maSPList");
            int maDM = Integer.parseInt(request.getParameter("maDM"));
            double giaNhap = Double.parseDouble(request.getParameter("giaNhap"));
            double giaBan = Double.parseDouble(request.getParameter("giaBan"));
            String moTa = request.getParameter("moTa");
            String anh = request.getParameter("anh");

            if (maSPListStr != null && !maSPListStr.isEmpty()) {
                String[] ids = maSPListStr.split(",");
                List<Product> allProducts = productService.findAll(); 
                
                for (String idStr : ids) {
                    if (idStr.trim().isEmpty()) continue;
                    int id = Integer.parseInt(idStr);
                    Product original = allProducts.stream().filter(p -> p.getMaSP() == id).findFirst().orElse(null);
                    if (original != null) {
                        original.setMaDM(maDM); original.setGiaNhap(giaNhap); original.setGiaBan(giaBan);
                        original.setMoTa(moTa); original.setAnh(anh != null && !anh.trim().isEmpty() ? anh.trim() : null);
                        productService.updateProduct(original);
                    }
                }
                SystemLogUtil.log(currentUser.getMaNV(), "Sửa Nhóm Sản Phẩm", "Cập nhật thông tin chung cho các mã SKU: " + maSPListStr);
                request.getSession().setAttribute("successMsg", "Đã cập nhật thông tin chung cho toàn bộ biến thể!");
            }
        } catch (Exception e) { 
            request.getSession().setAttribute("errorMsg", "Dữ liệu không hợp lệ!"); 
        }
        response.sendRedirect(request.getContextPath() + "/product");
    }

    // Xóa nhóm sản phẩm
    private void deleteProductGroup(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        try {
            String maSPListStr = request.getParameter("maSPList");
            if (maSPListStr != null && !maSPListStr.isEmpty()) {
                String[] ids = maSPListStr.split(",");
                int count = 0;
                for (String idStr : ids) {
                    if (idStr.trim().isEmpty()) continue;
                    if (productService.deleteProduct(Integer.parseInt(idStr))) count++;
                }
                if (count > 0) {
                    SystemLogUtil.log(currentUser.getMaNV(), "Xóa Nhóm Sản Phẩm", "Đã xóa " + count + " mã SKU. Chuỗi ID: " + maSPListStr);
                    request.getSession().setAttribute("successMsg", "Đã xóa thành công " + count + " mã SKU!");
                } else {
                    request.getSession().setAttribute("errorMsg", "Không thể xóa do sản phẩm đã phát sinh giao dịch!");
                }
            }
        } catch (Exception e) {}
        response.sendRedirect(request.getContextPath() + "/product");
    }
    
    // Xóa 1 biến thể lẻ
    private void deleteSingleVariant(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền."); return;
        }
        try {
            int maSP = Integer.parseInt(request.getParameter("id"));
            if (productService.deleteProduct(maSP)) {
                SystemLogUtil.log(currentUser.getMaNV(), "Xóa Biến Thể", "Xóa vĩnh viễn mã SKU: " + maSP);
                request.getSession().setAttribute("successMsg", "Đã xóa biến thể thành công!");
            } else {
                request.getSession().setAttribute("errorMsg", "Không thể xóa vì biến thể này đã có trong hóa đơn hoặc tồn kho!");
            }
        } catch (Exception e) {}
        response.sendRedirect(request.getContextPath() + "/product");
    }

    // Bật tắt trạng thái bán
    private void toggleStatus(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền."); return;
        }
        try {
            int maSP = Integer.parseInt(request.getParameter("id"));
            boolean currentStatus = Boolean.parseBoolean(request.getParameter("status"));
            productService.changeStatus(maSP, !currentStatus);
            
            String statusText = !currentStatus ? "Mở bán" : "Khóa";
            SystemLogUtil.log(currentUser.getMaNV(), statusText + " Sản phẩm", "Thay đổi trạng thái mã SKU: " + maSP);
            
            request.getSession().setAttribute("successMsg", "Đã thay đổi trạng thái bán hàng.");
        } catch (Exception e) {}
        response.sendRedirect(request.getContextPath() + "/product");
    }
}