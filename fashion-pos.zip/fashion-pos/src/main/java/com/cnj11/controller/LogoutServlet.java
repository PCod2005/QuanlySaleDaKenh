package com.cnj11.controller;

import com.cnj11.model.User;
import com.cnj11.util.SystemLogUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            User currentUser = (User) session.getAttribute("currentUser");
            if (currentUser != null) {
                // ---> GHI LOG ĐĂNG XUẤT TRƯỚC KHI HỦY SESSION <---
                SystemLogUtil.log(currentUser.getMaNV(), "Đăng Xuất", "Đăng xuất khỏi hệ thống an toàn.");
            }
            // Hủy toàn bộ dữ liệu phiên đăng nhập
            session.invalidate();
        }
        
        // Trả về trang đăng nhập kèm thông báo
        request.getSession(true).setAttribute("successMsg", "Bạn đã đăng xuất thành công!");
        response.sendRedirect(request.getContextPath() + "/login");
    }
}