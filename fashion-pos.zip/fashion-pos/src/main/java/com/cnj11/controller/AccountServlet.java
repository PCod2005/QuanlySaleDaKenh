package com.cnj11.controller;

import com.cnj11.model.User;
import com.cnj11.service.UserService;
import com.cnj11.service.impl.UserServiceImpl;
import com.cnj11.util.DBConnection;
import com.cnj11.util.SystemLogUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/account")
public class AccountServlet extends HttpServlet {
    private UserService userService;

    @Override
    public void init() throws ServletException {
        userService = new UserServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ Quản trị viên mới được thao tác.");
            return;
        }

        String activeTab = request.getParameter("tab");
        request.setAttribute("activeTab", activeTab != null ? activeTab : "tai-khoan");

        // 1. LẤY DANH SÁCH TÀI KHOẢN TỪ SERVICE
        List<User> users = userService.findAll();
        request.setAttribute("users", users);

        // --- NHẬN THAM SỐ TÌM KIẾM ---
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        String searchLog = request.getParameter("searchLog");

        // 2. LẤY VÀ PHÂN TÁCH LỊCH SỬ HOẠT ĐỘNG (Có áp dụng bộ lọc)
        List<Map<String, Object>> adminLogs = new ArrayList<>();
        List<Map<String, Object>> staffLogs = new ArrayList<>();
        
        StringBuilder sqlLogs = new StringBuilder("SELECT maLog, maNV, hanhDong, chiTiet, thoiGian FROM LICH_SU_HOAT_DONG WHERE 1=1 ");
        
        if (fromDate != null && !fromDate.trim().isEmpty()) {
            sqlLogs.append(" AND DATE(thoiGian) >= '").append(fromDate.trim()).append("'");
        }
        if (toDate != null && !toDate.trim().isEmpty()) {
            sqlLogs.append(" AND DATE(thoiGian) <= '").append(toDate.trim()).append("'");
        }
        if (searchLog != null && !searchLog.trim().isEmpty()) {
            sqlLogs.append(" AND (hanhDong LIKE '%").append(searchLog.trim()).append("%' OR chiTiet LIKE '%").append(searchLog.trim()).append("%')");
        }
        sqlLogs.append(" ORDER BY thoiGian DESC LIMIT 500");

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sqlLogs.toString())) {
            while (rs.next()) {
                Map<String, Object> log = new LinkedHashMap<>();
                log.put("maLog", rs.getInt("maLog"));
                log.put("hanhDong", rs.getString("hanhDong"));
                log.put("chiTiet", rs.getString("chiTiet"));
                log.put("thoiGian", rs.getTimestamp("thoiGian"));
                
                int logMaNV = rs.getInt("maNV");
                String hoTen = "Tài khoản đã xóa";
                String username = "unknown";
                String role = "STAFF"; 
                
                for(User u : users) {
                    if(u.getMaNV() == logMaNV) {
                        hoTen = u.getHoTen();
                        username = u.getUsername();
                        role = u.getRole();
                        break;
                    }
                }
                log.put("hoTen", hoTen);
                log.put("username", username);
                
                if (role != null && role.equalsIgnoreCase("ADMIN")) {
                    adminLogs.add(log);
                } else {
                    staffLogs.add(log);
                }
            }
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
        
        request.setAttribute("adminLogs", adminLogs);
        request.setAttribute("staffLogs", staffLogs);
        request.setAttribute("fromDate", fromDate);
        request.setAttribute("toDate", toDate);
        request.setAttribute("searchLog", searchLog);
        
        request.getRequestDispatcher("/WEB-INF/views/account/account.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User currentUser = (User) request.getSession().getAttribute("currentUser");
        if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Chỉ Quản trị viên mới được thao tác.");
            return;
        }

        String action = request.getParameter("action");
        int currentMaNV = currentUser.getMaNV();

        if ("add".equals(action)) {
            addUser(request, response, currentMaNV);
        } else if ("edit".equals(action)) {
            updateUser(request, response, currentMaNV);
        } else if ("toggleStatus".equals(action)) {
            toggleStatus(request, response, currentMaNV);
        } else {
            response.sendRedirect(request.getContextPath() + "/account");
        }
    }

    private void addUser(HttpServletRequest request, HttpServletResponse response, int currentMaNV) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String hoTen = request.getParameter("hoTen");
        String sdt = request.getParameter("sdt");
        String email = request.getParameter("email");
        String role = request.getParameter("role");
        boolean trangThai = request.getParameter("trangThai") != null;

        if (username.trim().isEmpty() || password.trim().isEmpty() || hoTen.trim().isEmpty()) {
            request.getSession().setAttribute("errorMsg", "Vui lòng nhập đủ các trường bắt buộc!");
            response.sendRedirect(request.getContextPath() + "/account");
            return;
        }

        User u = new User();
        u.setUsername(username.trim());
        u.setPassword(password.trim()); 
        u.setHoTen(hoTen.trim());
        u.setSdt(sdt);
        u.setEmail(email);
        u.setRole(role);
        u.setTrangThai(trangThai);

        if (userService.addUser(u)) {
            SystemLogUtil.log(currentMaNV, "Thêm Tài Khoản", "Tạo mới tài khoản: " + username);
            request.getSession().setAttribute("successMsg", "Thêm tài khoản thành công!");
        } else {
            request.getSession().setAttribute("errorMsg", "Thêm thất bại! Tên đăng nhập có thể đã tồn tại.");
        }
        response.sendRedirect(request.getContextPath() + "/account");
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response, int currentMaNV) throws IOException {
        try {
            int maNV = Integer.parseInt(request.getParameter("maNV"));
            String hoTen = request.getParameter("hoTen");
            String sdt = request.getParameter("sdt");
            String email = request.getParameter("email");
            String role = request.getParameter("role");
            boolean trangThai = request.getParameter("trangThai") != null;

            if (hoTen.trim().isEmpty()) {
                request.getSession().setAttribute("errorMsg", "Họ tên không được để trống!");
                response.sendRedirect(request.getContextPath() + "/account");
                return;
            }

            User u = new User();
            u.setMaNV(maNV);
            u.setHoTen(hoTen.trim());
            u.setSdt(sdt);
            u.setEmail(email);
            u.setRole(role);
            u.setTrangThai(trangThai);

            if (userService.updateUser(u)) {
                SystemLogUtil.log(currentMaNV, "Sửa Thông Tin", "Cập nhật thông tin mã NV: " + maNV);
                request.getSession().setAttribute("successMsg", "Cập nhật tài khoản thành công!");
            } else {
                request.getSession().setAttribute("errorMsg", "Cập nhật thất bại!");
            }
        } catch (NumberFormatException e) {
            request.getSession().setAttribute("errorMsg", "Dữ liệu không hợp lệ!");
        }
        response.sendRedirect(request.getContextPath() + "/account");
    }

    private void toggleStatus(HttpServletRequest request, HttpServletResponse response, int currentMaNV) throws IOException {
        try {
            int maNV = Integer.parseInt(request.getParameter("maNV"));
            boolean currentStatus = Boolean.parseBoolean(request.getParameter("status"));
            
            if (maNV == currentMaNV) {
                request.getSession().setAttribute("errorMsg", "Bạn không thể tự khóa tài khoản của chính mình!");
                response.sendRedirect(request.getContextPath() + "/account");
                return;
            }

            if (userService.lockUnlockUser(maNV, !currentStatus)) {
                String statusStr = !currentStatus ? "Mở khóa" : "Khóa";
                SystemLogUtil.log(currentMaNV, statusStr + " Tài Khoản", "Tác động đến mã NV: " + maNV);
                request.getSession().setAttribute("successMsg", "Thay đổi trạng thái tài khoản thành công!");
            } else {
                request.getSession().setAttribute("errorMsg", "Thay đổi trạng thái thất bại!");
            }
        } catch (Exception e) {
            request.getSession().setAttribute("errorMsg", "Lỗi dữ liệu đầu vào!");
        }
        response.sendRedirect(request.getContextPath() + "/account");
    }
}