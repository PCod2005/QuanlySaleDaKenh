package com.cnj11.controller;

import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import com.cnj11.service.OrderService;
import com.cnj11.service.impl.OrderServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/invoice")
public class InvoiceServlet extends HttpServlet {
    private OrderService orderService;

    @Override
    public void init() throws ServletException {
        orderService = new OrderServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int maDH = Integer.parseInt(request.getParameter("id"));
            Order order = orderService.findById(maDH);
            
            if (order != null) {
                List<OrderDetail> details = orderService.findDetailsByOrderId(maDH);
                Payment payment = orderService.findPaymentByOrderId(maDH);
                
                request.setAttribute("order", order);
                request.setAttribute("details", details);
                request.setAttribute("payment", payment);
                
                request.getRequestDispatcher("/WEB-INF/views/order/invoice.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/order");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/order");
        }
    }
}