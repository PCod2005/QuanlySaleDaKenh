package com.cnj11.controller;

import com.cnj11.model.Category;
import com.cnj11.model.Product;
import com.cnj11.model.User;
import com.cnj11.service.CategoryService;
import com.cnj11.service.ProductService;
import com.cnj11.service.impl.CategoryServiceImpl;
import com.cnj11.service.impl.ProductServiceImpl;
import com.cnj11.util.DBConnection;
import com.cnj11.util.SystemLogUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/inventory")
public class InventoryServlet extends HttpServlet {
    private ProductService productService;
    private CategoryService categoryService;

    @Override
    public void init() throws ServletException {
        productService = new ProductServiceImpl();
        categoryService = new CategoryServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        if ("create".equals(action)) {
            showImportForm(request, response);
        } else if ("audit".equals(action)) {
            showAuditForm(request, response);
        } else {
            showInventoryList(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("checkout".equals(action)) {
            handleImportCheckout(request, response);
        } else if ("audit_checkout".equals(action)) {
            handleAuditCheckout(request, response);
        }
    }

    private void handleImportCheckout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            User currentUser = (User) request.getSession().getAttribute("currentUser");
            int maNV = (currentUser != null) ? currentUser.getMaNV() : 1; 
            
            String[] maSPs = request.getParameterValues("maSP[]");
            String[] qtys = request.getParameterValues("soLuong[]");
            String[] prices = request.getParameterValues("giaNhap[]");
            String ghiChu = request.getParameter("ghiChu");
            
            if (maSPs == null || maSPs.length == 0) {
                request.getSession().setAttribute("errorMsg", "Phiếu nhập trống!");
                response.sendRedirect(request.getContextPath() + "/inventory?action=create");
                return;
            }

            double totalAmount = 0;
            for (int i = 0; i < maSPs.length; i++) {
                totalAmount += (Double.parseDouble(prices[i]) * Integer.parseInt(qtys[i]));
            }

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false); 
                try {
                    try (Statement stmt = conn.createStatement()) { stmt.execute("SET FOREIGN_KEY_CHECKS=0"); }

                    String sqlPhieu = "INSERT INTO PHIEU_NHAP (maNV, ngayNhap, tongTien, ghiChu) VALUES (?, NOW(), ?, ?)";
                    PreparedStatement psPhieu = conn.prepareStatement(sqlPhieu, Statement.RETURN_GENERATED_KEYS);
                    psPhieu.setInt(1, maNV); psPhieu.setDouble(2, totalAmount); psPhieu.setString(3, ghiChu);
                    psPhieu.executeUpdate();
                    
                    ResultSet rsKeys = psPhieu.getGeneratedKeys();
                    int maPN = 0; if (rsKeys.next()) maPN = rsKeys.getInt(1);
                    
                    String sqlCT = "INSERT INTO CHI_TIET_PHIEU_NHAP (maPN, maSP, soLuong, giaNhap, thanhTien) VALUES (?, ?, ?, ?, ?)";
                    String sqlUpdate = "UPDATE SAN_PHAM " +
                                       "SET giaNhap = IF((soLuongTon + ?) <= 0, giaNhap, ((soLuongTon * giaNhap) + (? * ?)) / (soLuongTon + ?)), " +
                                       "    soLuongTon = soLuongTon + ? WHERE maSP = ?";
                    
                    PreparedStatement psCT = conn.prepareStatement(sqlCT);
                    PreparedStatement psUp = conn.prepareStatement(sqlUpdate);
                    
                    for (int i = 0; i < maSPs.length; i++) {
                        int maSP = Integer.parseInt(maSPs[i]); int qty = Integer.parseInt(qtys[i]); double price = Double.parseDouble(prices[i]);
                        
                        psCT.setInt(1, maPN); psCT.setInt(2, maSP); psCT.setInt(3, qty); psCT.setDouble(4, price); psCT.setDouble(5, price * qty);
                        psCT.addBatch();
                        
                        psUp.setInt(1, qty); psUp.setInt(2, qty); psUp.setDouble(3, price); psUp.setInt(4, qty); psUp.setInt(5, qty); psUp.setInt(6, maSP);
                        psUp.addBatch();
                    }
                    psCT.executeBatch(); psUp.executeBatch();
                    
                    try (Statement stmt = conn.createStatement()) { stmt.execute("SET FOREIGN_KEY_CHECKS=1"); }
                    conn.commit(); 
                    
                    // GHI LOG HỆ THỐNG
                    SystemLogUtil.log(maNV, "Nhập Kho", "Lập phiếu nhập #PN" + String.format("%04d", maPN) + " - Tổng tiền: " + String.format("%,.0f", totalAmount) + " ₫");
                    
                    request.getSession().setAttribute("successMsg", "Thành công! Đã lưu phiếu nhập và tính lại Giá Vốn Trung Bình.");
                } catch (Exception ex) { conn.rollback(); throw ex; }
            }
        } catch (Exception e) { request.getSession().setAttribute("errorMsg", "Lỗi CSDL: " + e.getMessage()); }
        response.sendRedirect(request.getContextPath() + "/inventory?tab=lich-su-nhap");
    }

    private void handleAuditCheckout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            User currentUser = (User) request.getSession().getAttribute("currentUser");
            int maNV = (currentUser != null) ? currentUser.getMaNV() : 1; 
            
            String[] maSPs = request.getParameterValues("maSP[]");
            String[] actualQtys = request.getParameterValues("soLuongThucTe[]");
            String[] diffQtys = request.getParameterValues("chenhLech[]");
            String ghiChu = "[KIỂM KÊ KHO] " + request.getParameter("ghiChu");
            
            if (maSPs == null || maSPs.length == 0) {
                response.sendRedirect(request.getContextPath() + "/inventory?action=audit");
                return;
            }

            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false); 
                try {
                    try (Statement stmt = conn.createStatement()) { stmt.execute("SET FOREIGN_KEY_CHECKS=0"); }

                    String sqlPhieu = "INSERT INTO PHIEU_NHAP (maNV, ngayNhap, tongTien, ghiChu) VALUES (?, NOW(), 0, ?)";
                    PreparedStatement psPhieu = conn.prepareStatement(sqlPhieu, Statement.RETURN_GENERATED_KEYS);
                    psPhieu.setInt(1, maNV); psPhieu.setString(2, ghiChu);
                    psPhieu.executeUpdate();
                    
                    ResultSet rsKeys = psPhieu.getGeneratedKeys();
                    int maPN = 0; if (rsKeys.next()) maPN = rsKeys.getInt(1);
                    
                    String sqlCT = "INSERT INTO CHI_TIET_PHIEU_NHAP (maPN, maSP, soLuong, giaNhap, thanhTien) VALUES (?, ?, ?, 0, 0)";
                    String sqlUpdate = "UPDATE SAN_PHAM SET soLuongTon = ? WHERE maSP = ?"; 
                    
                    PreparedStatement psCT = conn.prepareStatement(sqlCT);
                    PreparedStatement psUp = conn.prepareStatement(sqlUpdate);
                    
                    boolean hasChanges = false;
                    for (int i = 0; i < maSPs.length; i++) {
                        int maSP = Integer.parseInt(maSPs[i]);
                        int actualQty = Integer.parseInt(actualQtys[i]);
                        int diffQty = Integer.parseInt(diffQtys[i]);
                        
                        if (diffQty != 0) {
                            hasChanges = true;
                            psCT.setInt(1, maPN); psCT.setInt(2, maSP); psCT.setInt(3, diffQty); 
                            psCT.addBatch();
                            psUp.setInt(1, actualQty); psUp.setInt(2, maSP); 
                            psUp.addBatch();
                        }
                    }
                    
                    if (hasChanges) {
                        psCT.executeBatch(); psUp.executeBatch();
                        
                        // GHI LOG HỆ THỐNG
                        SystemLogUtil.log(maNV, "Cân Bằng Kho", "Lập phiếu kiểm kê #PN" + String.format("%04d", maPN));
                        request.getSession().setAttribute("successMsg", "Đã hoàn tất Cân bằng kho và lưu Lịch sử Kiểm kê.");
                    } else {
                        request.getSession().setAttribute("successMsg", "Kho đã cân bằng, không có sự chênh lệch nào được ghi nhận.");
                    }
                    
                    try (Statement stmt = conn.createStatement()) { stmt.execute("SET FOREIGN_KEY_CHECKS=1"); }
                    conn.commit(); 
                } catch (Exception ex) { conn.rollback(); throw ex; }
            }
        } catch (Exception e) { request.getSession().setAttribute("errorMsg", "Lỗi CSDL: " + e.getMessage()); }
        response.sendRedirect(request.getContextPath() + "/inventory?tab=lich-su-kiem-ke");
    }

    private void showInventoryList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String activeTab = request.getParameter("tab");
        request.setAttribute("activeTab", activeTab != null ? activeTab : "ton-kho");

        String keyword = request.getParameter("keyword");
        List<Product> products = (keyword != null && !keyword.trim().isEmpty()) ? productService.search(keyword.trim()) : productService.findAll();
        Map<String, List<Product>> groupedProducts = new LinkedHashMap<>();
        for (Product p : products) {
            String name = p.getTenSP();
            String baseName = name.contains(" - ") ? name.substring(0, name.indexOf(" - ")).trim() : name;
            groupedProducts.computeIfAbsent(baseName, k -> new ArrayList<>()).add(p);
        }
        request.setAttribute("groupedProducts", groupedProducts);

        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        String searchHistory = request.getParameter("searchHistory");
        
        List<Map<String, Object>> importHistory = new ArrayList<>();
        List<Map<String, Object>> auditHistory = new ArrayList<>();
        Map<Integer, List<Map<String, Object>>> importDetails = new HashMap<>(); 
        
        try (Connection conn = DBConnection.getConnection()) {
            StringBuilder sqlHistory = new StringBuilder("SELECT maPN, ngayNhap, tongTien, ghiChu FROM PHIEU_NHAP WHERE 1=1 ");
            if (fromDate != null && !fromDate.isEmpty()) sqlHistory.append(" AND DATE(ngayNhap) >= '").append(fromDate).append("'");
            if (toDate != null && !toDate.isEmpty()) sqlHistory.append(" AND DATE(ngayNhap) <= '").append(toDate).append("'");
            if (searchHistory != null && !searchHistory.isEmpty()) sqlHistory.append(" AND (ghiChu LIKE '%").append(searchHistory).append("%' OR maPN LIKE '%").append(searchHistory).append("%')");
            sqlHistory.append(" ORDER BY maPN DESC");

            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sqlHistory.toString())) {
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("maPN", rs.getInt("maPN"));
                    row.put("ngayNhap", rs.getTimestamp("ngayNhap"));
                    row.put("tongTien", rs.getDouble("tongTien"));
                    String ghiChu = rs.getString("ghiChu");
                    row.put("ghiChu", ghiChu);
                    
                    if (ghiChu != null && ghiChu.contains("[KIỂM KÊ KHO]")) {
                        auditHistory.add(row);
                    } else {
                        importHistory.add(row);
                    }
                }
            }
            
            String sqlDetails = "SELECT c.maPN, c.soLuong, c.giaNhap, c.thanhTien, s.tenSP FROM CHI_TIET_PHIEU_NHAP c JOIN SAN_PHAM s ON c.maSP = s.maSP";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sqlDetails)) {
                while(rs.next()) {
                    int maPN = rs.getInt("maPN");
                    Map<String, Object> detail = new HashMap<>();
                    detail.put("tenSP", rs.getString("tenSP"));
                    detail.put("soLuong", rs.getInt("soLuong"));
                    detail.put("giaNhap", rs.getDouble("giaNhap"));
                    detail.put("thanhTien", rs.getDouble("thanhTien"));
                    importDetails.computeIfAbsent(maPN, k -> new ArrayList<>()).add(detail);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }

        request.setAttribute("importHistory", importHistory); 
        request.setAttribute("auditHistory", auditHistory); 
        request.setAttribute("importDetails", importDetails); 
        
        request.setAttribute("fromDate", fromDate);
        request.setAttribute("toDate", toDate);
        request.setAttribute("searchHistory", searchHistory);
        
        request.getRequestDispatcher("/WEB-INF/views/inventory/inventory.jsp").forward(request, response);
    }

    private void showImportForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Product> products = productService.findAll();
        Map<String, List<Product>> groupedProducts = new LinkedHashMap<>();
        for (Product p : products) {
            if (!p.isTrangThai()) continue; 
            String baseName = p.getTenSP().contains(" - ") ? p.getTenSP().substring(0, p.getTenSP().indexOf(" - ")).trim() : p.getTenSP();
            groupedProducts.computeIfAbsent(baseName, k -> new ArrayList<>()).add(p);
        }
        request.setAttribute("groupedProducts", groupedProducts);
        request.getRequestDispatcher("/WEB-INF/views/inventory/import_form.jsp").forward(request, response);
    }

    private void showAuditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Product> products = productService.findAll();
        Map<String, List<Product>> groupedProducts = new LinkedHashMap<>();
        for (Product p : products) {
            if (!p.isTrangThai()) continue; 
            String baseName = p.getTenSP().contains(" - ") ? p.getTenSP().substring(0, p.getTenSP().indexOf(" - ")).trim() : p.getTenSP();
            groupedProducts.computeIfAbsent(baseName, k -> new ArrayList<>()).add(p);
        }
        request.setAttribute("groupedProducts", groupedProducts);
        request.getRequestDispatcher("/WEB-INF/views/inventory/audit_form.jsp").forward(request, response);
    }
}