package com.cnj11.controller;

import com.cnj11.model.*;
import com.cnj11.service.ProductService;
import com.cnj11.service.SaleService;
import com.cnj11.service.impl.ProductServiceImpl;
import com.cnj11.service.impl.SaleServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
    private ProductService productService;
    private SaleService saleService;

    @Override
    public void init() throws ServletException {
        productService = new ProductServiceImpl();
        saleService = new SaleServiceImpl();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        try {
            switch (action) {
                case "add":
                    int addId = Integer.parseInt(request.getParameter("maSP"));
                    Product p = productService.findById(addId);
                    if (p != null) cart.addItem(p, 1);
                    break;
                case "update":
                    int updateId = Integer.parseInt(request.getParameter("maSP"));
                    int qty = Integer.parseInt(request.getParameter("soLuong"));
                    cart.updateQuantity(updateId, qty);
                    break;
                case "remove":
                    int removeId = Integer.parseInt(request.getParameter("maSP"));
                    cart.removeItem(removeId);
                    break;
                case "clear":
                    cart.clear();
                    break;
                case "checkout":
                    processCheckout(request, response, cart);
                    return; // Dừng lại vì checkout đã handle redirect
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Sau khi thao tác giỏ hàng, quay lại trang POS
        response.sendRedirect(request.getContextPath() + "/sale");
    }

    private void processCheckout(HttpServletRequest request, HttpServletResponse response, Cart cart) throws IOException {
        if (cart.isEmpty()) {
            request.getSession().setAttribute("errorMsg", "Giỏ hàng trống!");
            response.sendRedirect(request.getContextPath() + "/sale");
            return;
        }

        User currentUser = (User) request.getSession().getAttribute("currentUser");
        
        int maPTTT = Integer.parseInt(request.getParameter("maPTTT")); // 1: Tiền mặt, 2: Chuyển khoản
        double total = cart.getTotal();
        double tienKhachDua = 0;

        if (maPTTT == 1) {
            String cashParam = request.getParameter("tienKhachDua");
            if (cashParam == null || cashParam.trim().isEmpty()) {
                request.getSession().setAttribute("errorMsg", "Vui lòng nhập số tiền khách đưa!");
                response.sendRedirect(request.getContextPath() + "/sale");
                return;
            }
            tienKhachDua = Double.parseDouble(cashParam);
            if (tienKhachDua < total) {
                request.getSession().setAttribute("errorMsg", "Tiền khách đưa không đủ!");
                response.sendRedirect(request.getContextPath() + "/sale");
                return;
            }
        } else {
            tienKhachDua = total; // Chuyển khoản mặc định đã nhận đủ
        }

        // Tạo Entity Order
        Order order = new Order();
        order.setMaNV(currentUser.getMaNV());
        order.setTenKhachHang(request.getParameter("tenKhachHang"));
        order.setSoDienThoaiKhachHang(request.getParameter("soDienThoaiKhachHang"));
        order.setDiaChiKhachHang(request.getParameter("diaChiKhachHang"));
        order.setKenhBan(request.getParameter("kenhBan"));
        order.setMaPTTT(maPTTT);
        order.setTongTien(total);
        order.setTrangThai("Đã thanh toán"); // Trạng thái mặc định khi bán POS thành công
        order.setGhiChu(request.getParameter("ghiChu"));

        // Build list chi tiết đơn
        List<OrderDetail> details = new ArrayList<>();
        for (CartItem ci : cart.getItems()) {
            OrderDetail detail = new OrderDetail();
            detail.setMaSP(ci.getMaSP());
            detail.setSoLuong(ci.getSoLuong());
            detail.setGiaBan(ci.getGiaBan());
            detail.setThanhTien(ci.getThanhTien());
            details.add(detail);
        }

        // Build Payment
        Payment payment = new Payment();
        payment.setTienKhachDua(tienKhachDua);
        payment.setTienThua(tienKhachDua - total);
        payment.setGhiChu("Thanh toán tại POS");

        // Execute Transaction
        int newOrderId = saleService.checkout(order, details, payment);

        if (newOrderId > 0) {
            cart.clear(); // Xóa giỏ hàng khi thành công
            response.sendRedirect(request.getContextPath() + "/sale?action=success&orderId=" + newOrderId);
        } else {
            request.getSession().setAttribute("errorMsg", "Có lỗi xảy ra trong quá trình thanh toán (Có thể kho đã hết hàng).");
            response.sendRedirect(request.getContextPath() + "/sale");
        }
    }
}