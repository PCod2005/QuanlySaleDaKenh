package com.cnj11.controller;

import com.cnj11.model.RevenueItem;
import com.cnj11.service.ReportService;
import com.cnj11.service.impl.ReportServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/report")
public class ReportServlet extends HttpServlet {
    private ReportService reportService;

    @Override
    public void init() throws ServletException {
        reportService = new ReportServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Lấy data báo cáo (7 ngày gần nhất, 6 tháng gần nhất)
        List<RevenueItem> dailyRevenue = reportService.getRevenueByLastDays(7);
        List<RevenueItem> monthlyRevenue = reportService.getRevenueByLastMonths(6);
        List<RevenueItem> channelRevenue = reportService.getRevenueByChannel();

        request.setAttribute("dailyRevenue", dailyRevenue);
        request.setAttribute("monthlyRevenue", monthlyRevenue);
        request.setAttribute("channelRevenue", channelRevenue);

        request.getRequestDispatcher("/WEB-INF/views/report/report.jsp").forward(request, response);
    }
}