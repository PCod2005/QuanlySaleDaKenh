package com.cnj11.controller;

import com.cnj11.model.User;
import com.cnj11.util.DBConnection;
import com.cnj11.util.SystemLogUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession().getAttribute("currentUser") != null) {
            response.sendRedirect(request.getContextPath() + "/inventory"); 
            return;
        }
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String u = request.getParameter("username");
        String p = request.getParameter("password");

        User user = null;
        String errorMessage = "Sai tên đăng nhập hoặc mật khẩu!"; 

        // Đã sửa tên bảng thành nguoi_dung và các cột tương ứng theo file database.sql của bạn
        String sql = "SELECT maNV, username, password, hoTen, role, trangThai FROM nguoi_dung WHERE username = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
             
            ps.setString(1, u);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Cột mật khẩu trong bảng nguoi_dung tên là password
                    String dbPass = rs.getString("password"); 
                    boolean isCorrect = false;

                    if (dbPass != null && dbPass.startsWith("$2a$")) {
                        try {
                            isCorrect = org.mindrot.jbcrypt.BCrypt.checkpw(p, dbPass);
                        } catch (Exception ex) {
                            isCorrect = false;
                        }
                    } else {
                        isCorrect = p.equals(dbPass);
                    }

                    if (isCorrect) {
                        user = new User();
                        user.setMaNV(rs.getInt("maNV"));
                        // Cột tên đăng nhập trong bảng nguoi_dung tên là username
                        user.setUsername(rs.getString("username"));
                        user.setHoTen(rs.getString("hoTen"));
                        user.setRole(rs.getString("role"));
                        user.setTrangThai(rs.getBoolean("trangThai"));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            errorMessage = "Lỗi Database: " + e.getMessage(); 
        }

        if (user != null) {
            if (!user.isTrangThai()) {
                request.setAttribute("errorMsg", "Tài khoản của bạn đã bị khóa. Vui lòng liên hệ Admin!");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                return;
            }

            HttpSession session = request.getSession();
            session.setAttribute("currentUser", user);
            
            SystemLogUtil.log(user.getMaNV(), "Đăng Nhập", "Truy cập hệ thống thành công. Quyền: " + user.getRole());
            
            response.sendRedirect(request.getContextPath() + "/inventory"); 
        } else {
            request.setAttribute("errorMsg", errorMessage);
            request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
        }
    }
}