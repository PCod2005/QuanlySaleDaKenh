package com.cnj11.controller;

import com.cnj11.model.Product;
import com.cnj11.service.ProductService;
import com.cnj11.service.impl.ProductServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@WebServlet("/sale")
public class SaleServlet extends HttpServlet {
    private ProductService productService;

    @Override
    public void init() throws ServletException {
        productService = new ProductServiceImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("success".equals(action)) {
            request.getRequestDispatcher("/WEB-INF/views/sale/checkout_success.jsp").forward(request, response);
            return;
        }

        String keyword = request.getParameter("keyword");
        List<Product> allProducts = (keyword != null && !keyword.trim().isEmpty()) 
                                    ? productService.search(keyword.trim()) 
                                    : productService.findAll();

        // Chỉ lấy sản phẩm đang kinh doanh và còn tồn kho
        List<Product> availableProducts = allProducts.stream()
                .filter(p -> p.isTrangThai() && p.getSoLuongTon() > 0)
                .collect(Collectors.toList());

        // GOM NHÓM SẢN PHẨM THEO TÊN GỐC (ĐỂ HIỂN THỊ DẠNG SHOPEE)
        // Key: Tên gốc (Ví dụ: "Áo Polo Basic"), Value: Danh sách các biến thể của nó
        Map<String, List<Product>> groupedProducts = new LinkedHashMap<>();
        for (Product p : availableProducts) {
            String name = p.getTenSP();
            // Tách tên gốc dựa vào dấu " - " (Ví dụ: "Áo Polo Basic - Trắng - Size S" -> "Áo Polo Basic")
            String baseName = name.contains(" - ") ? name.substring(0, name.indexOf(" - ")).trim() : name;
            groupedProducts.computeIfAbsent(baseName, k -> new ArrayList<>()).add(p);
        }

        // Danh sách kênh bán cố định theo yêu cầu
        String[] channels = {"Tại cửa hàng", "Facebook", "Zalo", "Shopee", "TikTok", "Điện thoại", "Khác"};

        request.setAttribute("groupedProducts", groupedProducts);
        request.setAttribute("keyword", keyword);
        request.setAttribute("channels", channels);
        request.getRequestDispatcher("/WEB-INF/views/sale/pos.jsp").forward(request, response);
    }
}