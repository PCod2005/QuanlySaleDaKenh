package com.cnj11.service;

import com.cnj11.model.Category;
import java.util.List;

public interface CategoryService {
    Category findById(int id);
    List<Category> findAll();
    boolean addCategory(Category category);
    boolean updateCategory(Category category);
    boolean deleteCategory(int id);
}