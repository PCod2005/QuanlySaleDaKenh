package com.cnj11.service.impl;
import com.cnj11.dao.InventoryDAO;
import com.cnj11.dao.ProductDAO;
import com.cnj11.dao.impl.InventoryDAOImpl;
import com.cnj11.dao.impl.ProductDAOImpl;
import com.cnj11.model.StockReceipt;
import com.cnj11.model.StockReceiptDetail;
import com.cnj11.service.InventoryService;
import com.cnj11.util.DBConnection;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class InventoryServiceImpl implements InventoryService {
    private final InventoryDAO inventoryDAO = new InventoryDAOImpl();
    private final ProductDAO productDAO = new ProductDAOImpl();

    @Override
    public boolean completeImport(StockReceipt receipt, List<StockReceiptDetail> details) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // TRANSACTION START

            // 1. Insert PHIEU_NHAP
            int maPN = inventoryDAO.insertReceipt(conn, receipt);
            
            // 2. Loop insert CHI_TIET_PHIEU_NHAP & Update Stock
            for (StockReceiptDetail d : details) {
                d.setMaPN(maPN);
                inventoryDAO.insertReceiptDetail(conn, d);
                // Truyền quantity dương (+) để cộng vào kho
                productDAO.updateStock(conn, d.getMaSP(), d.getSoLuong()); 
            }

            conn.commit(); // COMMIT TRANSACTION
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    @Override
    public List<StockReceipt> getReceiptHistory() {
        return inventoryDAO.findAllReceipts();
    }

    @Override
    public List<StockReceiptDetail> getReceiptDetails(int maPN) {
        return inventoryDAO.findDetailsByReceiptId(maPN);
    }
}