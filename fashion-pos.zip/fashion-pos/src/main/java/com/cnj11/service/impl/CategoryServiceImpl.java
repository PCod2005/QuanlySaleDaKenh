package com.cnj11.service.impl;

import com.cnj11.dao.CategoryDAO;
import com.cnj11.dao.impl.CategoryDAOImpl;
import com.cnj11.model.Category;
import com.cnj11.service.CategoryService;
import java.util.List;

public class CategoryServiceImpl implements CategoryService {
    private final CategoryDAO categoryDAO = new CategoryDAOImpl();

    @Override
    public Category findById(int id) {
        return categoryDAO.findById(id);
    }

    @Override
    public List<Category> findAll() {
        return categoryDAO.findAll();
    }

    @Override
    public boolean addCategory(Category category) {
        return categoryDAO.insert(category);
    }

    @Override
    public boolean updateCategory(Category category) {
        return categoryDAO.update(category);
    }

    @Override
    public boolean deleteCategory(int id) {
        // Cần xử lý cẩn thận vì có FK ràng buộc bên bảng SAN_PHAM
        return categoryDAO.delete(id);
    }
}