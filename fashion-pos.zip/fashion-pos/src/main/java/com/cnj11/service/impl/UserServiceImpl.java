package com.cnj11.service.impl;

import com.cnj11.dao.UserDAO;
import com.cnj11.dao.impl.UserDAOImpl;
import com.cnj11.model.User;
import com.cnj11.service.UserService;
import org.mindrot.jbcrypt.BCrypt;
import java.util.List;

public class UserServiceImpl implements UserService {
    private final UserDAO userDAO = new UserDAOImpl();

    @Override
    public User login(String username, String rawPassword) {
        User user = userDAO.findByUsername(username);
        if (user != null && user.isTrangThai()) {
            if (BCrypt.checkpw(rawPassword, user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    @Override
    public User findByUsername(String username) {
        return userDAO.findByUsername(username);
    }

    @Override
    public User findById(int id) {
        return userDAO.findById(id);
    }

    @Override
    public List<User> findAll() {
        return userDAO.findAll();
    }

    @Override
    public boolean addUser(User user) {
        // Hash password trước khi insert
        String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(10));
        user.setPassword(hashed);
        return userDAO.insert(user);
    }

    @Override
    public boolean updateUser(User user) {
        // Lưu ý: Update thông thường không đổi password. Chức năng đổi pass sẽ làm method riêng nếu cần.
        return userDAO.update(user);
    }

    @Override
    public boolean lockUnlockUser(int id, boolean status) {
        return userDAO.updateStatus(id, status);
    }
}