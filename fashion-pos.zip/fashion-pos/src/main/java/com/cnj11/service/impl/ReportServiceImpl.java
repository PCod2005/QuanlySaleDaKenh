package com.cnj11.service.impl;
import com.cnj11.dao.ReportDAO;
import com.cnj11.dao.impl.ReportDAOImpl;
import com.cnj11.model.RevenueItem;
import com.cnj11.service.ReportService;
import java.util.List;

public class ReportServiceImpl implements ReportService {
    private final ReportDAO reportDAO = new ReportDAOImpl();

    @Override
    public List<RevenueItem> getRevenueByLastDays(int days) {
        return reportDAO.getRevenueByLastDays(days);
    }

    @Override
    public List<RevenueItem> getRevenueByLastMonths(int months) {
        return reportDAO.getRevenueByLastMonths(months);
    }

    @Override
    public List<RevenueItem> getRevenueByChannel() {
        return reportDAO.getRevenueByChannel();
    }
}