package com.cnj11.service;

import com.cnj11.model.Product;
import java.util.List;

public interface ProductService {
    Product findById(int id);
    List<Product> findAll();
    List<Product> search(String keyword);
    boolean addProduct(Product product);
    boolean updateProduct(Product product);
    boolean changeStatus(int id, boolean status);
    boolean deleteProduct(int maSP);
}