package com.cnj11.service;

import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import java.util.List;

public interface SaleService {
    // Thực thi Transaction: Tạo đơn -> Thêm Chi tiết -> Trừ kho -> Thanh toán
    // Trả về mã đơn hàng (maDH) nếu thành công, trả về -1 nếu thất bại
    int checkout(Order order, List<OrderDetail> cartItems, Payment payment);
}