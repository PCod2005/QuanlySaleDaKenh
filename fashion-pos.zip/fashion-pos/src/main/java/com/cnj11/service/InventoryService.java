package com.cnj11.service;
import com.cnj11.model.StockReceipt;
import com.cnj11.model.StockReceiptDetail;
import java.util.List;

public interface InventoryService {
    boolean completeImport(StockReceipt receipt, List<StockReceiptDetail> details);
    List<StockReceipt> getReceiptHistory();
    List<StockReceiptDetail> getReceiptDetails(int maPN);
}