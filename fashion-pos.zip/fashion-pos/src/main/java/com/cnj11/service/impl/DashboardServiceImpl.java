package com.cnj11.service.impl;

import com.cnj11.dao.DashboardDAO;
import com.cnj11.dao.impl.DashboardDAOImpl;
import com.cnj11.model.DashboardStats;
import com.cnj11.service.DashboardService;

public class DashboardServiceImpl implements DashboardService {
    private final DashboardDAO dashboardDAO = new DashboardDAOImpl();

    @Override
    public DashboardStats getDashboardStatistics() {
        return dashboardDAO.getDashboardStatistics();
    }
}