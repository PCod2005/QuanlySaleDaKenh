package com.cnj11.service.impl;
import com.cnj11.dao.OrderDAO;
import com.cnj11.dao.impl.OrderDAOImpl;
import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import com.cnj11.service.OrderService;
import java.util.List;

public class OrderServiceImpl implements OrderService {
    private final OrderDAO orderDAO = new OrderDAOImpl();

    @Override
    public List<Order> searchAndFilter(String keyword, String fromDate, String toDate, String status, String channel) {
        return orderDAO.searchAndFilter(keyword, fromDate, toDate, status, channel);
    }

    @Override
    public Order findById(int id) {
        // Có thể cần lấy tên NV và PTTT cho chi tiết, nhưng ta dùng truy vấn của danh sách cho tiện,
        // hoặc query lại. Để tiết kiệm thời gian, ở đây ta gọi search với mã DH.
        List<Order> list = orderDAO.searchAndFilter(String.valueOf(id), null, null, null, null);
        for (Order o : list) {
            if (o.getMaDH() == id) return o;
        }
        return null;
    }

    @Override
    public List<OrderDetail> findDetailsByOrderId(int maDH) {
        return orderDAO.findDetailsByOrderId(maDH);
    }

    @Override
    public Payment findPaymentByOrderId(int maDH) {
        return orderDAO.findPaymentByOrderId(maDH);
    }

    @Override
    public boolean updateStatus(int id, String status) {
        try {
            orderDAO.updateStatus(id, status);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}