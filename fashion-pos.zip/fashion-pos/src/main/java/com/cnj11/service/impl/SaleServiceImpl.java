package com.cnj11.service.impl;

import com.cnj11.dao.OrderDAO;
import com.cnj11.dao.ProductDAO;
import com.cnj11.dao.impl.OrderDAOImpl;
import com.cnj11.dao.impl.ProductDAOImpl;
import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import com.cnj11.model.Product;
import com.cnj11.service.SaleService;
import com.cnj11.util.DBConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class SaleServiceImpl implements SaleService {
    private final OrderDAO orderDAO = new OrderDAOImpl();
    private final ProductDAO productDAO = new ProductDAOImpl();

    @Override
    public int checkout(Order order, List<OrderDetail> cartItems, Payment payment) {
        Connection conn = null;
        int newOrderId = -1;
        try {
            conn = DBConnection.getConnection();
            // Bắt đầu Transaction
            conn.setAutoCommit(false); 

            // 1. Kiểm tra tồn kho trước khi tạo đơn
            for (OrderDetail item : cartItems) {
                Product p = productDAO.findById(item.getMaSP());
                if (p == null || !p.isTrangThai()) {
                    throw new SQLException("Sản phẩm không tồn tại hoặc đã ngừng kinh doanh: " + item.getMaSP());
                }
                if (p.getSoLuongTon() < item.getSoLuong()) {
                    throw new SQLException("Tồn kho không đủ cho sản phẩm: " + p.getTenSP());
                }
            }

            // 2. Insert Bảng DON_HANG
            newOrderId = orderDAO.insertOrder(conn, order);
            
            // 3. Xử lý Chi tiết Đơn hàng & Trừ kho
            for (OrderDetail item : cartItems) {
                item.setMaDH(newOrderId);
                
                // Insert CHI_TIET_DON_HANG
                orderDAO.insertOrderDetail(conn, item);
                
                // Update SAN_PHAM (Trừ số lượng tồn kho)
                // Số lượng truyền vào là âm (-) để trừ đi
                productDAO.updateStock(conn, item.getMaSP(), -item.getSoLuong()); 
            }

            // 4. Insert Bảng THANH_TOAN
            if (payment != null) {
                payment.setMaDH(newOrderId);
                orderDAO.insertPayment(conn, payment);
            }

            // Hoàn tất Transaction
            conn.commit(); 
            return newOrderId;

        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    // Nếu có bất kỳ lỗi gì, Rollback toàn bộ
                    conn.rollback(); 
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            return -1;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}