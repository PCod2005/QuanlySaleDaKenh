package com.cnj11.service;
import com.cnj11.model.RevenueItem;
import java.util.List;

public interface ReportService {
    List<RevenueItem> getRevenueByLastDays(int days);
    List<RevenueItem> getRevenueByLastMonths(int months);
    List<RevenueItem> getRevenueByChannel();
}