package com.cnj11.service;

import com.cnj11.model.User;
import java.util.List;

public interface UserService {
    User login(String username, String rawPassword);
    User findByUsername(String username);
    User findById(int id);
    List<User> findAll();
    boolean addUser(User user);
    boolean updateUser(User user);
    boolean lockUnlockUser(int id, boolean status);
}