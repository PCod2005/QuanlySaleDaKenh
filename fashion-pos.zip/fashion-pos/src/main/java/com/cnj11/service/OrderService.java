package com.cnj11.service;
import com.cnj11.model.Order;
import com.cnj11.model.OrderDetail;
import com.cnj11.model.Payment;
import java.util.List;

public interface OrderService {
    List<Order> searchAndFilter(String keyword, String fromDate, String toDate, String status, String channel);
    Order findById(int id);
    List<OrderDetail> findDetailsByOrderId(int maDH);
    Payment findPaymentByOrderId(int maDH);
    boolean updateStatus(int id, String status);
}