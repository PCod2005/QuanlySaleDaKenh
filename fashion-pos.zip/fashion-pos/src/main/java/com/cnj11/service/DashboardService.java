package com.cnj11.service;

import com.cnj11.model.DashboardStats;

public interface DashboardService {
    DashboardStats getDashboardStatistics();
}