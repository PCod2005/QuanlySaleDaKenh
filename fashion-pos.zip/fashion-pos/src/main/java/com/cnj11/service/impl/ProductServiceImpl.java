package com.cnj11.service.impl;

import com.cnj11.dao.ProductDAO;
import com.cnj11.dao.impl.ProductDAOImpl;
import com.cnj11.model.Product;
import com.cnj11.service.ProductService;
import java.util.List;

public class ProductServiceImpl implements ProductService {
    private final ProductDAO productDAO = new ProductDAOImpl();

    @Override
    public Product findById(int id) {
        return productDAO.findById(id);
    }

    @Override
    public List<Product> findAll() {
        return productDAO.findAll();
    }

    @Override
    public List<Product> search(String keyword) {
        return productDAO.search(keyword);
    }

    @Override
    public boolean addProduct(Product product) {
        return productDAO.insert(product);
    }

    @Override
    public boolean updateProduct(Product product) {
        return productDAO.update(product);
    }

    @Override
    public boolean changeStatus(int id, boolean status) {
        return productDAO.updateStatus(id, status);
    }
    @Override
    public boolean deleteProduct(int maSP) {
        return productDAO.deleteProduct(maSP);
    }
}