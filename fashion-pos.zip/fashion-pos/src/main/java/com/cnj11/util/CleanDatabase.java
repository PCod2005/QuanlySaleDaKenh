package com.cnj11.util;

import java.sql.Connection;
import java.sql.Statement;

public class CleanDatabase {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            
            System.out.println("⏳ Đang tiến hành dọn dẹp Database...");

            // 1. Tạm tắt kiểm tra Khóa ngoại (để xóa không bị lỗi)
            stmt.execute("SET FOREIGN_KEY_CHECKS = 0;");
            
            // 2. Xóa sạch dữ liệu và Reset ID tự tăng về 1 cho các bảng giao dịch
            stmt.execute("TRUNCATE TABLE THANH_TOAN;");
            stmt.execute("TRUNCATE TABLE CHI_TIET_DON_HANG;"); // Hoặc tên là CHI_TIET_HOA_DON tùy schema của bạn
            stmt.execute("TRUNCATE TABLE DON_HANG;");
            
            stmt.execute("TRUNCATE TABLE CHI_TIET_PHIEU_NHAP;");
            stmt.execute("TRUNCATE TABLE PHIEU_NHAP;");
            
            stmt.execute("TRUNCATE TABLE SAN_PHAM;");
            
            // 3. Bật lại kiểm tra Khóa ngoại
            stmt.execute("SET FOREIGN_KEY_CHECKS = 1;");
            
            System.out.println("✅ HOÀN TẤT! Đã xóa sạch Sản phẩm, Đơn hàng và Lịch sử kho.");
            System.out.println("✅ Các ID đã được reset lại từ đầu (Bắt đầu từ số 1).");
            
        } catch (Exception e) {
            System.err.println("❌ CÓ LỖI XẢY RA: " + e.getMessage());
            e.printStackTrace();
        }
    }
}