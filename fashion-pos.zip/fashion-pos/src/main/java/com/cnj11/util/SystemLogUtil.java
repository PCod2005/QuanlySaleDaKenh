package com.cnj11.util;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class SystemLogUtil {
    public static void log(int maNV, String hanhDong, String chiTiet) {
        String sql = "INSERT INTO LICH_SU_HOAT_DONG (maNV, hanhDong, chiTiet, thoiGian) VALUES (?, ?, ?, NOW())";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, maNV);
            ps.setString(2, hanhDong);
            ps.setString(3, chiTiet);
            
            int rows = ps.executeUpdate();
            if (rows > 0) {
                // In ra Console để biết chắc chắn code đã chạy vào đây
                System.out.println("✅ [GHI LOG THÀNH CÔNG] - NV: " + maNV + " | Hành động: " + hanhDong);
            }
        } catch (Exception e) {
            // In rõ lỗi ra Console để bắt bệnh
            System.err.println("❌ [LỖI GHI LOG HỆ THỐNG]: " + e.getMessage());
            e.printStackTrace();
        }
    }
}