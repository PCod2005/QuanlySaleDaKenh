package com.cnj11.util;

import org.mindrot.jbcrypt.BCrypt;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdatePassword {
    public static void main(String[] args) {
        // 1. Mã hóa mật khẩu "123456" chuẩn bằng BCrypt
        String hashedPw = BCrypt.hashpw("123456", BCrypt.gensalt());
        System.out.println("Mã Hash mới tạo: " + hashedPw);
        
        // 2. Cập nhật mã Hash này xuống toàn bộ tài khoản trong Database
        String sql = "UPDATE NGUOI_DUNG SET password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, hashedPw);
            int rowsAffected = ps.executeUpdate();
            
            System.out.println("✅ Đã cập nhật thành công " + rowsAffected + " tài khoản về mật khẩu: 123456");
        } catch (Exception e) {
            System.err.println("❌ Lỗi khi cập nhật DB: " + e.getMessage());
            e.printStackTrace();
        }
    }
}