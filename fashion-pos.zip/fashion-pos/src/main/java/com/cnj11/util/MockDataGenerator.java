package com.cnj11.util;

import java.sql.Connection;
import java.sql.Statement;

public class MockDataGenerator {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            
            System.out.println("⏳ Đang dọn dẹp và tạo dữ liệu mẫu siêu to khổng lồ...");

            // 1. Tắt khóa ngoại và dọn sạch dữ liệu cũ
            stmt.execute("SET FOREIGN_KEY_CHECKS = 0;");
            stmt.execute("TRUNCATE TABLE CHI_TIET_PHIEU_NHAP;");
            stmt.execute("TRUNCATE TABLE CHI_TIET_DON_HANG;");
            stmt.execute("TRUNCATE TABLE PHIEU_NHAP;");
            stmt.execute("TRUNCATE TABLE DON_HANG;");
            stmt.execute("TRUNCATE TABLE SAN_PHAM;");
            stmt.execute("TRUNCATE TABLE DANH_MUC;");
            
            // 2. Thêm 6 Danh mục mẫu
            String insertCategories = "INSERT INTO DANH_MUC (tenDM, moTa, trangThai) VALUES "
                    + "('Áo Nam', 'Các loại áo thun, sơ mi, khoác nam', 1), "
                    + "('Quần Nam', 'Quần jean, âu, short nam', 1), "
                    + "('Áo Nữ', 'Áo croptop, áo kiểu, áo thun nữ', 1), "
                    + "('Quần Nữ', 'Quần ống rộng, chân váy, jean nữ', 1), "
                    + "('Giày Dép', 'Sneaker, giày da, cao gót', 1), "
                    + "('Phụ Kiện', 'Đồng hồ, túi, ví, thắt lưng, kính', 1);";
            stmt.execute(insertCategories);

            // 3. Khởi tạo StringBuilder để chứa hàng trăm biến thể
            StringBuilder insertProducts = new StringBuilder();
            insertProducts.append("INSERT INTO SAN_PHAM (maDM, tenSP, giaNhap, giaBan, soLuongTon, moTa, trangThai, anh) VALUES ");
            
            // --- HÀM PHỤ TRỢ NỐI CHUỖI ---
            // ================== DANH MỤC 1: ÁO NAM ==================
            String imgPolo = "'https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=300&q=80'";
            String imgSoMi = "'https://images.unsplash.com/photo-1596755094514-f87e32f85e23?w=300&q=80'";
            String imgBomber = "'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=300&q=80'";
            String imgThun = "'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&q=80'";
            for (String s : new String[]{"S", "M", "L", "XL"}) {
                insertProducts.append(String.format("(1, 'Áo Polo Basic - Trắng - Size %s', 150000, 250000, 0, 'Cotton 100%%', 1, %s),", s, imgPolo));
                insertProducts.append(String.format("(1, 'Áo Polo Basic - Đen - Size %s', 150000, 250000, 0, 'Cotton 100%%', 1, %s),", s, imgPolo));
                insertProducts.append(String.format("(1, 'Áo Thun Graphic - Be - Size %s', 120000, 199000, 0, 'In họa tiết', 1, %s),", s, imgThun));
                insertProducts.append(String.format("(1, 'Áo Khoác Bomber - Rêu - Size %s', 280000, 490000, 0, 'Chống nước', 1, %s),", s, imgBomber));
            }
            for (String s : new String[]{"M", "L", "XL", "XXL"}) {
                insertProducts.append(String.format("(1, 'Áo Sơ Mi Oxford - Xanh Nhạt - Size %s', 180000, 320000, 0, 'Vải lụa nến ít nhăn', 1, %s),", s, imgSoMi));
            }

            // ================== DANH MỤC 2: QUẦN NAM ==================
            String imgJean = "'https://images.unsplash.com/photo-1542272604-780c40fb06e6?w=300&q=80'";
            String imgQuanAu = "'https://images.unsplash.com/photo-1594938298596-03fd62996471?w=300&q=80'";
            String imgShort = "'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=300&q=80'";
            for (String s : new String[]{"29", "30", "31", "32"}) {
                insertProducts.append(String.format("(2, 'Quần Jean Slimfit - Xanh - Size %s', 200000, 380000, 0, 'Co giãn tốt', 1, %s),", s, imgJean));
                insertProducts.append(String.format("(2, 'Quần Jean Slimfit - Đen - Size %s', 200000, 380000, 0, 'Co giãn tốt', 1, %s),", s, imgJean));
                insertProducts.append(String.format("(2, 'Quần Tây Âu - Đen - Size %s', 220000, 420000, 0, 'Dáng ôm vừa', 1, %s),", s, imgQuanAu));
                insertProducts.append(String.format("(2, 'Quần Short Khaki - Kem - Size %s', 140000, 250000, 0, 'Thoáng mát', 1, %s),", s, imgShort));
            }

            // ================== DANH MỤC 3: ÁO NỮ ==================
            String imgCroptop = "'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=300&q=80'";
            String imgLen = "'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=300&q=80'";
            for (String s : new String[]{"XS", "S", "M"}) {
                insertProducts.append(String.format("(3, 'Áo Croptop Năng Động - Trắng - Size %s', 90000, 150000, 0, 'Kiểu dáng Hàn Quốc', 1, %s),", s, imgCroptop));
                insertProducts.append(String.format("(3, 'Áo Croptop Năng Động - Hồng - Size %s', 90000, 150000, 0, 'Kiểu dáng Hàn Quốc', 1, %s),", s, imgCroptop));
                insertProducts.append(String.format("(3, 'Áo Len Tăm Nữ - Be - Size %s', 130000, 220000, 0, 'Chất len mềm mịn', 1, %s),", s, imgLen));
            }

            // ================== DANH MỤC 4: QUẦN NỮ ==================
            String imgOngRong = "'https://images.unsplash.com/photo-1604176354204-9268737828e4?w=300&q=80'";
            String imgVay = "'https://images.unsplash.com/photo-1583496661160-c5dcb4c0ce3e?w=300&q=80'";
            for (String s : new String[]{"S", "M", "L"}) {
                insertProducts.append(String.format("(4, 'Quần Ống Rộng Nữ - Đen - Size %s', 180000, 320000, 0, 'Hack dáng cực đỉnh', 1, %s),", s, imgOngRong));
                insertProducts.append(String.format("(4, 'Chân Váy Xếp Ly - Caro - Size %s', 150000, 280000, 0, 'Dễ thương', 1, %s),", s, imgVay));
            }

            // ================== DANH MỤC 5: GIÀY DÉP ==================
            String imgSneaker = "'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&q=80'";
            String imgGiayDa = "'https://images.unsplash.com/photo-1614252339460-e17f354728d7?w=300&q=80'";
            String imgCaoGot = "'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=300&q=80'";
            for (String s : new String[]{"39", "40", "41", "42"}) {
                insertProducts.append(String.format("(5, 'Sneaker X-Max - Đỏ - Size %s', 350000, 650000, 0, 'Đế mút siêu nhẹ', 1, %s),", s, imgSneaker));
                insertProducts.append(String.format("(5, 'Sneaker X-Max - Trắng - Size %s', 350000, 650000, 0, 'Đế mút siêu nhẹ', 1, %s),", s, imgSneaker));
                insertProducts.append(String.format("(5, 'Giày Lười Da Bò - Nâu - Size %s', 450000, 850000, 0, 'Da bò dập vân', 1, %s),", s, imgGiayDa));
            }
            for (String s : new String[]{"36", "37", "38"}) {
                insertProducts.append(String.format("(5, 'Giày Cao Gót Mũi Nhọn - Đen - Size %s', 280000, 450000, 0, 'Gót cao 7cm', 1, %s),", s, imgCaoGot));
            }

            // ================== DANH MỤC 6: PHỤ KIỆN (KHÔNG CÓ SIZE) ==================
            String imgDongHo = "'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300&q=80'";
            String imgTui = "'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=300&q=80'";
            String imgThatLung = "'https://images.unsplash.com/photo-1624222247344-550fb60583dc?w=300&q=80'";
            String imgKinh = "'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=300&q=80'";
            
            insertProducts.append(String.format("(6, 'Đồng hồ Classic - Bạc', 800000, 1500000, 0, 'Dây thép không gỉ', 1, %s),", imgDongHo));
            insertProducts.append(String.format("(6, 'Đồng hồ Classic - Vàng', 850000, 1600000, 0, 'Dây thép mạ vàng', 1, %s),", imgDongHo));
            insertProducts.append(String.format("(6, 'Túi Đeo Chéo Da - Đen', 120000, 250000, 0, 'Da PU chống nước', 1, %s),", imgTui));
            insertProducts.append(String.format("(6, 'Thắt Lưng Da Thật - Đen', 180000, 350000, 0, 'Khóa kim loại tự động', 1, %s),", imgThatLung));
            insertProducts.append(String.format("(6, 'Kính Râm Thời Trang - Đen', 150000, 290000, 0, 'Chống tia UV', 1, %s)", imgKinh)); // Dòng cuối cùng KHÔNG có dấu phẩy ở cuối

            // Thực thi chèn toàn bộ dữ liệu
            stmt.execute(insertProducts.toString());
            
            // 4. Bật lại Khóa ngoại
            stmt.execute("SET FOREIGN_KEY_CHECKS = 1;");
            
            System.out.println("✅ HOÀN TẤT! Đã tạo thành công 6 Danh mục và 110 Mã SKU Biến thể (Với Tồn kho = 0).");
            System.out.println("Hãy truy cập trang Sản phẩm để xem giao diện Gom Nhóm tuyệt đẹp!");
            
        } catch (Exception e) {
            System.err.println("❌ CÓ LỖI XẢY RA: " + e.getMessage());
            e.printStackTrace();
        }
    }
}